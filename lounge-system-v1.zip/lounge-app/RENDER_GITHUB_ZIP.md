# Subir o Lounge System no Render via GitHub (ZIP)

Você vai: baixar o ZIP → criar repo no GitHub com o conteúdo do ZIP → conectar no Render.

---

## 1) Baixe e descompacte o ZIP

Arquivo: `lounge-system-v1.zip`

Dentro dele existe a pasta:

```text
lounge-app/
```

Descompacte. Você precisa da pasta **`lounge-app`** (é a raiz do Laravel).

---

## 2) Crie o repositório no GitHub

1. Acesse https://github.com/new  
2. Nome sugerido: `lounge-system`  
3. **Public** ou Private  
4. **Não** marque README / .gitignore / license  
5. Create repository  

---

## 3) Envie o código (com o conteúdo do ZIP)

No computador, no terminal:

### Windows (PowerShell) / Mac / Linux

```bash
# entre na pasta descompactada
cd caminho/para/lounge-app

git init
git add .
git commit -m "Lounge System V1"

git branch -M main
git remote add origin https://github.com/SEU_USUARIO/lounge-system.git
git push -u origin main
```

### Se o GitHub pedir login
- Use **Personal Access Token** como senha, ou  
- GitHub CLI / SSH  

### Importante
A **raiz do repositório** deve conter:

- `artisan`
- `composer.json`
- `Dockerfile`
- `render.yaml`
- `docker/start.sh`
- `app/`
- `routes/`

Ou seja: suba o **conteúdo de `lounge-app`**, não a pasta pai com o zip.

Se você subiu errado (repo com `lounge-app/` dentro):

```bash
# opção simples: mova tudo para a raiz do repo
```

No Render, se a raiz for `lounge-app/`, configure **Root Directory** = `lounge-app`.

---

## 4) Crie o banco no Render

1. Render Dashboard → **New +** → **MySQL** (ou PostgreSQL **não** — o app está em MySQL/MariaDB)  
2. Nome: `lounge-mysql`  
3. Crie e aguarde ficar **Available**  
4. Anote (ou use “Connect”):
   - Host  
   - Port  
   - Database  
   - User  
   - Password  

> Se MySQL não estiver disponível no seu plano, use um MySQL externo (PlanetScale, Railway, Aiven, etc.) e preencha as mesmas variáveis.

---

## 5) Crie o Web Service no Render

### Opção A — Blueprint (mais fácil se o `render.yaml` estiver na raiz)

1. **New +** → **Blueprint**  
2. Conecte o repositório GitHub  
3. Aplique o `render.yaml`  
4. Ajuste as env vars do banco se o blueprint não linkar sozinho  

### Opção B — Web Service manual (Docker)

1. **New +** → **Web Service**  
2. Conecte o repo `lounge-system`  
3. Configuração:

| Campo | Valor |
|--------|--------|
| Runtime | **Docker** |
| Branch | `main` |
| Root Directory | vazio (se `Dockerfile` na raiz) **ou** `lounge-app` |
| Instance | Free / Starter |

4. O Render usa o `Dockerfile` automaticamente.

---

## 6) Variáveis de ambiente (obrigatórias)

No Web Service → **Environment**:

```env
APP_NAME=Lounge System
APP_ENV=production
APP_DEBUG=false
APP_URL=https://SEU-SERVICO.onrender.com
APP_KEY=

APP_TIMEZONE=America/Sao_Paulo

DB_CONNECTION=mysql
DB_HOST=...          # do MySQL Render
DB_PORT=3306
DB_DATABASE=...
DB_USERNAME=...
DB_PASSWORD=...

LOG_CHANNEL=stderr
SESSION_DRIVER=database
CACHE_STORE=database
QUEUE_CONNECTION=database
FILESYSTEM_DISK=public
BROADCAST_CONNECTION=log

ALLOW_NEGATIVE_STOCK=false
PAYMENT_GATEWAY=manual

# Só no PRIMEIRO deploy:
RUN_MIGRATIONS=true
```

### Gerar APP_KEY
No seu PC (com PHP) ou localmente no projeto:

```bash
php artisan key:generate --show
```

Cole o valor em `APP_KEY` (formato `base64:...`).

Se não tiver PHP local, no primeiro deploy você pode gerar no **Shell** do Render depois (ver passo 8) e colocar na env.

---

## 7) Deploy

1. Clique **Create Web Service** / **Deploy**  
2. Aguarde o build Docker  
3. Health check: `/up`  

No primeiro boot, com `RUN_MIGRATIONS=true`, roda:

```bash
php artisan migrate --force
```

---

## 8) Seed + storage (depois do 1º deploy)

No Render → seu serviço → **Shell**:

```bash
php artisan db:seed --force
php artisan storage:link
php artisan config:cache
```

Se ainda não tiver `APP_KEY`:

```bash
php artisan key:generate
# copie a key do .env gerado e cole nas Environment Variables do painel
```

Depois volte a env:

```env
RUN_MIGRATIONS=false
```

e salve (evita migrate a cada restart desnecessário — migrate é seguro, mas seed **não** deve rodar sozinho).

---

## 9) Teste no ar

Abra:

| URL | O que é |
|-----|---------|
| `https://SEU-SERVICO.onrender.com/up` | Health |
| `https://SEU-SERVICO.onrender.com/menu` | Cardápio |
| `https://SEU-SERVICO.onrender.com/menu/table/08` | Mesa 08 |
| `https://SEU-SERVICO.onrender.com/admin/login` | Login |

### Credenciais demo (após seed)
- Admin: `admin@lounge.local` / `password`  
- Atendente: `atendente@lounge.local` / `password`  

**Troque as senhas** depois do piloto.

---

## 10) QR Code e APP_URL

1. Confirme `APP_URL=https://SEU-SERVICO.onrender.com` (sem barra no final)  
2. No admin → Mesas → **Regenerar QR** de cada mesa  
3. Os QR antigos com `localhost` **não** servem em produção  

---

## 11) Storage (fotos / QR) no Render Free

No plano free o disco é **efêmero**: redeploy pode apagar imagens/QR.

Para piloto:
- regenere QR após redeploy, ou  
- anexe **Persistent Disk** montado em `/var/www/html/storage`

---

## 12) Atualizar o sistema depois

1. Altere o código no PC  
2. `git add . && git commit -m "..." && git push`  
3. Render faz deploy automático  

**Não** precisa mandar ZIP de novo (a menos que queira outro repo do zero).

---

## 13) Problemas comuns

| Problema | Solução |
|----------|---------|
| Build falha no Composer | Veja logs; `composer.lock` já está no zip |
| 500 após deploy | `APP_KEY` vazio ou DB errado |
| Página em branco | `APP_DEBUG=true` temporário só para ver erro, depois `false` |
| QR abre localhost | `APP_URL` + regenerar QR |
| CSS/JS ok, imagens 404 | `php artisan storage:link` + disco |
| Migrate não rodou | `RUN_MIGRATIONS=true` e redeploy, ou rode no Shell |
| Repo com pasta `lounge-app/` dentro | Root Directory = `lounge-app` no Render |

---

## Checklist rápido

- [ ] ZIP descompactado  
- [ ] Conteúdo de `lounge-app` no GitHub (raiz do repo)  
- [ ] MySQL no Render  
- [ ] Web Service Docker  
- [ ] Env vars preenchidas  
- [ ] `APP_KEY` + `APP_URL`  
- [ ] `RUN_MIGRATIONS=true` no 1º deploy  
- [ ] Seed + storage:link  
- [ ] `RUN_MIGRATIONS=false`  
- [ ] Login admin funciona  
- [ ] Regenerar QRs  

Pronto: sistema no ar via GitHub a partir do ZIP.
