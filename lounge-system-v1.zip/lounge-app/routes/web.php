<?php

use App\Http\Controllers\Admin\AuditController;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\CashController;
use App\Http\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\IntegrationsController;
use App\Http\Controllers\Admin\NotificationController as AdminNotificationController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Admin\ReportController as AdminReportController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\StockController as AdminStockController;
use App\Http\Controllers\Admin\TableController as AdminTableController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\Api\V1\Admin\RealtimeController;
use App\Http\Controllers\Attendant\DashboardController as AttendantDashboardController;
use App\Http\Controllers\MenuController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('menu.index'));

// Public menu (customer)
Route::get('/menu', [MenuController::class, 'index'])->name('menu.index');
Route::get('/menu/table/{number}', [MenuController::class, 'tableByNumber'])->name('menu.table');
Route::get('/menu/t/{token}', [MenuController::class, 'tableByToken'])->name('menu.token');
Route::get('/menu/product/{slug}', [MenuController::class, 'product'])->name('menu.product');
Route::get('/menu/cart', [MenuController::class, 'cartPage'])->name('menu.cart');
Route::post('/menu/cart/add', [MenuController::class, 'addToCart'])->name('menu.cart.add');
Route::post('/menu/cart/update', [MenuController::class, 'updateCart'])->name('menu.cart.update');
Route::get('/menu/checkout', [MenuController::class, 'checkoutForm'])->name('menu.checkout');
Route::post('/menu/checkout', [MenuController::class, 'checkout'])->name('menu.checkout.submit');
Route::get('/menu/order/{orderNumber}', [MenuController::class, 'orderStatus'])->name('menu.order');
Route::get('/menu/order/{orderNumber}/status.json', [MenuController::class, 'orderStatusJson'])->name('menu.order.json');

// Shared staff auth
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [AdminAuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AdminAuthController::class, 'login'])->name('login.submit')->middleware('throttle:login');
});

// Attendant experience
Route::prefix('attendant')->name('attendant.')->middleware(['auth', 'active', 'admin'])->group(function () {
    Route::post('logout', [AdminAuthController::class, 'logout'])->name('logout');
    Route::get('/', [AttendantDashboardController::class, 'index'])->name('dashboard')->middleware('permission:orders.view');
    Route::get('dashboard', [AttendantDashboardController::class, 'index'])->middleware('permission:orders.view');
    Route::post('orders/{order}/{action}', [AttendantDashboardController::class, 'action'])
        ->where('action', 'confirm|prepare|ready|deliver|complete|cancel|confirm-payment')
        ->name('orders.action')
        ->middleware('permission:orders.manage');
    Route::get('tables', [AttendantDashboardController::class, 'tables'])->name('tables')->middleware('permission:tables.view');
    Route::get('tables/{table}', [AttendantDashboardController::class, 'tableShow'])->name('tables.show')->middleware('permission:tables.view');
    Route::post('tables/{table}/sessions/open', [AttendantDashboardController::class, 'openSession'])->name('tables.open')->middleware('permission:orders.manage');
    Route::post('tables/{table}/sessions/close', [AttendantDashboardController::class, 'closeSession'])->name('tables.close')->middleware('permission:orders.manage');
    Route::get('realtime/orders-stream', [RealtimeController::class, 'ordersStream'])->name('realtime')->middleware('permission:orders.view');
});

// Admin experience
Route::prefix('admin')->name('admin.')->middleware(['auth', 'active', 'admin'])->group(function () {
    Route::post('logout', [AdminAuthController::class, 'logout'])->name('logout');

    Route::get('/', [AdminDashboardController::class, 'index'])->name('dashboard')->middleware('permission:dashboard.view');
    Route::get('dashboard', [AdminDashboardController::class, 'index'])->middleware('permission:dashboard.view');

    Route::get('realtime/orders-stream', [RealtimeController::class, 'ordersStream'])
        ->name('realtime.orders')
        ->middleware('permission:orders.view');

    Route::get('orders', [AdminOrderController::class, 'index'])->name('orders.index')->middleware('permission:orders.view');
    Route::get('orders/{order}', [AdminOrderController::class, 'show'])->name('orders.show')->middleware('permission:orders.view');
    Route::post('orders/{order}/{action}', [AdminOrderController::class, 'transition'])
        ->where('action', 'confirm|prepare|ready|deliver|complete|cancel|confirm-payment')
        ->name('orders.action')
        ->middleware('permission:orders.manage');

    Route::middleware('permission:categories.view')->group(function () {
        Route::get('categories', [AdminCategoryController::class, 'index'])->name('categories.index');
    });
    Route::middleware('permission:categories.manage')->group(function () {
        Route::get('categories/create', [AdminCategoryController::class, 'create'])->name('categories.create');
        Route::post('categories', [AdminCategoryController::class, 'store'])->name('categories.store');
        Route::get('categories/{category}/edit', [AdminCategoryController::class, 'edit'])->name('categories.edit');
        Route::put('categories/{category}', [AdminCategoryController::class, 'update'])->name('categories.update');
        Route::delete('categories/{category}', [AdminCategoryController::class, 'destroy'])->name('categories.destroy');
    });

    Route::middleware('permission:products.view')->group(function () {
        Route::get('products', [AdminProductController::class, 'index'])->name('products.index');
    });
    Route::middleware('permission:products.manage')->group(function () {
        Route::get('products/create', [AdminProductController::class, 'create'])->name('products.create');
        Route::post('products', [AdminProductController::class, 'store'])->name('products.store');
        Route::get('products/{product}/edit', [AdminProductController::class, 'edit'])->name('products.edit');
        Route::put('products/{product}', [AdminProductController::class, 'update'])->name('products.update');
        Route::delete('products/{product}', [AdminProductController::class, 'destroy'])->name('products.destroy');
    });

    Route::middleware('permission:tables.view')->group(function () {
        Route::get('tables', [AdminTableController::class, 'index'])->name('tables.index');
        Route::get('tables/{table}', [AdminTableController::class, 'show'])->name('tables.show');
        Route::get('tables/{table}/qrcode', [AdminTableController::class, 'qrcode'])->name('tables.qrcode');
    });
    Route::middleware('permission:tables.manage')->group(function () {
        Route::get('tables/create', [AdminTableController::class, 'create'])->name('tables.create');
        Route::post('tables', [AdminTableController::class, 'store'])->name('tables.store');
        Route::get('tables/{table}/edit', [AdminTableController::class, 'edit'])->name('tables.edit');
        Route::put('tables/{table}', [AdminTableController::class, 'update'])->name('tables.update');
        Route::post('tables/{table}/qrcode/regenerate', [AdminTableController::class, 'regenerateQr'])->name('tables.qrcode.regenerate');
        Route::post('tables/{table}/sessions/open', [AdminTableController::class, 'openSession'])->name('tables.sessions.open');
        Route::post('tables/{table}/sessions/close', [AdminTableController::class, 'closeSession'])->name('tables.sessions.close');
    });

    Route::get('stock', [AdminStockController::class, 'index'])->name('stock.index')->middleware('permission:stock.view');
    Route::post('stock/move', [AdminStockController::class, 'move'])->name('stock.move')->middleware('permission:stock.manage');

    Route::get('cash', [CashController::class, 'index'])->name('cash.index')->middleware('permission:cash.view');
    Route::post('cash/open', [CashController::class, 'open'])->name('cash.open')->middleware('permission:cash.manage');
    Route::post('cash/close', [CashController::class, 'close'])->name('cash.close')->middleware('permission:cash.manage');
    Route::post('cash/movement', [CashController::class, 'movement'])->name('cash.movement')->middleware('permission:cash.manage');

    Route::get('reports', [AdminReportController::class, 'index'])->name('reports.index')->middleware('permission:reports.view');

    Route::get('users', [AdminUserController::class, 'index'])->name('users.index')->middleware('permission:users.view');
    Route::post('users', [AdminUserController::class, 'store'])->name('users.store')->middleware('permission:users.manage');
    Route::put('users/{user}', [AdminUserController::class, 'update'])->name('users.update')->middleware('permission:users.manage');

    Route::get('audit', [AuditController::class, 'index'])->name('audit.index')->middleware('permission:audit.view');
    Route::get('settings', [SettingController::class, 'index'])->name('settings.index')->middleware('permission:settings.manage');
    Route::post('settings', [SettingController::class, 'update'])->name('settings.update')->middleware('permission:settings.manage');
    Route::get('integrations', [IntegrationsController::class, 'index'])->name('integrations.index')->middleware('permission:settings.manage');

    Route::get('notifications', [AdminNotificationController::class, 'index'])->name('notifications.index')->middleware('permission:reports.view');
    Route::post('notifications/read-all', [AdminNotificationController::class, 'markAllRead'])->name('notifications.read-all')->middleware('permission:reports.view');
    Route::post('notifications/{notification}/read', [AdminNotificationController::class, 'markRead'])->name('notifications.read')->middleware('permission:reports.view');

});
