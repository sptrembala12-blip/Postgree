<?php

use App\Http\Controllers\Api\V1\Admin\AuditLogController;
use App\Http\Controllers\Api\V1\Admin\CashRegisterController;
use App\Http\Controllers\Api\V1\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Api\V1\Admin\DashboardController;
use App\Http\Controllers\Api\V1\Admin\NotificationController as ApiNotificationController;
use App\Http\Controllers\Api\V1\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Api\V1\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Api\V1\Admin\ReportController;
use App\Http\Controllers\Api\V1\Admin\StockController;
use App\Http\Controllers\Api\V1\Admin\TableController as AdminTableController;
use App\Http\Controllers\Api\V1\Admin\RealtimeController;
use App\Http\Controllers\Api\V1\Admin\UserController;
use App\Http\Controllers\Api\V1\Auth\AuthController;
use App\Http\Controllers\Api\V1\Customer\CartController;
use App\Http\Controllers\Api\V1\Customer\OrderController as CustomerOrderController;
use App\Http\Controllers\Api\V1\Public\MenuController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    // Auth
    Route::prefix('auth')->group(function () {
        Route::post('login', [AuthController::class, 'login'])->middleware('throttle:login');
        Route::middleware(['auth:sanctum', 'active'])->group(function () {
            Route::get('me', [AuthController::class, 'me']);
            Route::post('logout', [AuthController::class, 'logout']);
        });
    });

    // Public menu
    Route::prefix('public')->group(function () {
        Route::get('menu', [MenuController::class, 'menu']);
        Route::get('categories', [MenuController::class, 'categories']);
        Route::get('categories/{slug}', [MenuController::class, 'category']);
        Route::get('products', [MenuController::class, 'products']);
        Route::get('products/{slug}', [MenuController::class, 'product']);
        Route::get('tables/number/{number}', [MenuController::class, 'tableByNumber']);
        Route::get('tables/token/{token}', [MenuController::class, 'tableByToken']);
    });

    // Customer (public with rate limit)
    Route::prefix('customer')->middleware('throttle:public-orders')->group(function () {
        Route::get('cart', [CartController::class, 'show']);
        Route::post('cart/items', [CartController::class, 'add']);
        Route::patch('cart/items', [CartController::class, 'updateItem']);
        Route::delete('cart/items', [CartController::class, 'removeItem']);
        Route::delete('cart', [CartController::class, 'clear']);
        Route::post('orders', [CustomerOrderController::class, 'store']);
        Route::get('orders/{orderNumber}', [CustomerOrderController::class, 'show']);
    });

    // Admin API
    Route::prefix('admin')->middleware(['auth:sanctum', 'active', 'admin'])->group(function () {
        Route::get('dashboard', DashboardController::class)->middleware('permission:dashboard.view');

        Route::get('dashboard/sales', [DashboardController::class, 'sales'])->middleware('permission:dashboard.view');
        Route::get('dashboard/products', [DashboardController::class, 'products'])->middleware('permission:dashboard.view');

        Route::get('notifications', [ApiNotificationController::class, 'index'])->middleware('permission:reports.view');
        Route::get('notifications/unread', [ApiNotificationController::class, 'unread'])->middleware('permission:reports.view');
        Route::post('notifications/read-all', [ApiNotificationController::class, 'markAllRead'])->middleware('permission:reports.view');
        Route::post('notifications/{notification}/read', [ApiNotificationController::class, 'markRead'])->middleware('permission:reports.view');


        Route::middleware('permission:orders.view')->group(function () {
            Route::get('orders', [AdminOrderController::class, 'index']);
            Route::get('orders/{order}', [AdminOrderController::class, 'show']);
        });

        Route::middleware('permission:orders.manage')->group(function () {
            Route::post('orders/{order}/status', [AdminOrderController::class, 'updateStatus']);
            Route::post('orders/{order}/confirm', [AdminOrderController::class, 'confirm']);
            Route::post('orders/{order}/prepare', [AdminOrderController::class, 'prepare']);
            Route::post('orders/{order}/ready', [AdminOrderController::class, 'ready']);
            Route::post('orders/{order}/deliver', [AdminOrderController::class, 'deliver']);
            Route::post('orders/{order}/complete', [AdminOrderController::class, 'complete']);
            Route::post('orders/{order}/confirm-payment', [AdminOrderController::class, 'confirmPayment'])
                ->middleware('permission:payments.confirm');
        });

        Route::post('orders/{order}/cancel', [AdminOrderController::class, 'cancel'])
            ->middleware('permission:orders.cancel');

        Route::get('categories', [AdminCategoryController::class, 'index'])->middleware('permission:categories.view');
        Route::get('categories/{category}', [AdminCategoryController::class, 'show'])->middleware('permission:categories.view');
        Route::post('categories', [AdminCategoryController::class, 'store'])->middleware('permission:categories.manage');
        Route::put('categories/{category}', [AdminCategoryController::class, 'update'])->middleware('permission:categories.manage');
        Route::delete('categories/{category}', [AdminCategoryController::class, 'destroy'])->middleware('permission:categories.manage');

        Route::get('products', [AdminProductController::class, 'index'])->middleware('permission:products.view');
        Route::get('products/{product}', [AdminProductController::class, 'show'])->middleware('permission:products.view');
        Route::post('products', [AdminProductController::class, 'store'])->middleware('permission:products.manage');
        Route::put('products/{product}', [AdminProductController::class, 'update'])->middleware('permission:products.manage');
        Route::delete('products/{product}', [AdminProductController::class, 'destroy'])->middleware('permission:products.manage');

        Route::get('tables', [AdminTableController::class, 'index'])->middleware('permission:tables.view');
        Route::get('tables/{table}', [AdminTableController::class, 'show'])->middleware('permission:tables.view');
        Route::get('tables/{table}/qrcode', [AdminTableController::class, 'qrCode'])->middleware('permission:tables.view');
        Route::post('tables', [AdminTableController::class, 'store'])->middleware('permission:tables.manage');
        Route::put('tables/{table}', [AdminTableController::class, 'update'])->middleware('permission:tables.manage');
        Route::post('tables/{table}/qrcode/regenerate', [AdminTableController::class, 'regenerateQr'])->middleware('permission:tables.manage');
        Route::post('tables/{table}/sessions/open', [AdminTableController::class, 'openSession'])->middleware('permission:tables.manage');
        Route::post('tables/{table}/sessions/close', [AdminTableController::class, 'closeSession'])->middleware('permission:tables.manage');

        Route::get('stock', [StockController::class, 'index'])->middleware('permission:stock.view');
        Route::get('stock/low', [StockController::class, 'lowStock'])->middleware('permission:stock.view');
        Route::get('stock/movements', [StockController::class, 'movements'])->middleware('permission:stock.view');
        Route::post('stock/movements', [StockController::class, 'move'])->middleware('permission:stock.manage');

        Route::get('cash/current', [CashRegisterController::class, 'current'])->middleware('permission:cash.view');
        Route::get('cash/history', [CashRegisterController::class, 'history'])->middleware('permission:cash.view');
        Route::post('cash/open', [CashRegisterController::class, 'open'])->middleware('permission:cash.manage');
        Route::post('cash/close', [CashRegisterController::class, 'close'])->middleware('permission:cash.manage');
        Route::post('cash/movements', [CashRegisterController::class, 'movement'])->middleware('permission:cash.manage');

        Route::prefix('reports')->middleware('permission:reports.view')->group(function () {
            Route::get('products', [ReportController::class, 'products']);
            Route::get('categories', [ReportController::class, 'categories']);
            Route::get('payments', [ReportController::class, 'payments']);
            Route::get('tables', [ReportController::class, 'tables']);
        });

        Route::get('users', [UserController::class, 'index'])->middleware('permission:users.view');
        Route::post('users', [UserController::class, 'store'])->middleware('permission:users.manage');
        Route::put('users/{user}', [UserController::class, 'update'])->middleware('permission:users.manage');
        Route::delete('users/{user}', [UserController::class, 'destroy'])->middleware('permission:users.manage');

        Route::get('audit-logs', [AuditLogController::class, 'index'])->middleware('permission:audit.view');

        // Near-realtime feeds (SSE/poll). Full WebSocket requires Reverb/Pusher — see docs/REALTIME.md
        Route::get('realtime/orders', [RealtimeController::class, 'ordersPoll'])
            ->middleware('permission:orders.view');
        Route::get('realtime/orders/stream', [RealtimeController::class, 'ordersStream'])
            ->middleware('permission:orders.view');
    });
});
