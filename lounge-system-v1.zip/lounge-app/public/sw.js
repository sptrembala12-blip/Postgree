/* Lounge Admin Mini PWA — cache shell only. No offline finance.
 * Does NOT force page reload on update. User opts in via UI message.
 */
const CACHE = 'lounge-admin-shell-v2';
const SHELL = [
  '/css/lounge.css',
  '/css/admin-pwa.css',
  '/js/admin-pwa.js',
  '/js/attendant-board.js',
  '/pwa/icon-192.png',
  '/pwa/icon-512.png',
  '/manifest.webmanifest',
  '/offline.html',
];

self.addEventListener('install', (event) => {
  // Cache new shell but do NOT skipWaiting — keep current session stable
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(SHELL)));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
  );
  // Do not clients.claim() aggressively — avoids taking over open tabs mid-session
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);

  // Never cache API or realtime
  if (url.pathname.startsWith('/api/') || url.pathname.includes('/realtime/')) {
    return;
  }

  // Network-first for HTML navigations; offline fallback page only
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
    event.respondWith(
      fetch(req)
        .then((res) => res)
        .catch(() => caches.match('/offline.html'))
    );
    return;
  }

  // Cache-first for static assets
  if (
    url.pathname.startsWith('/css/') ||
    url.pathname.startsWith('/js/') ||
    url.pathname.startsWith('/pwa/') ||
    url.pathname === '/manifest.webmanifest'
  ) {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fetched = fetch(req)
          .then((res) => {
            const clone = res.clone();
            caches.open(CACHE).then((c) => c.put(req, clone));
            return res;
          })
          .catch(() => cached);
        return cached || fetched;
      })
    );
  }
});
