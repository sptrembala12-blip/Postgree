/**
 * Attendant board realtime — DOM updates only. Never reloads the page.
 */
(function () {
  const cfg = window.LOUNGE_ATTENDANT || {};
  let lastId = cfg.lastOrderId || 0;
  let backoff = 2000;
  const maxBackoff = 30000;
  let es = null;
  let pollTimer = null;

  const csrf = () => document.querySelector('meta[name="csrf-token"]')?.content || '';

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function money(cents) {
    const n = (Number(cents) || 0) / 100;
    return 'R$ ' + n.toFixed(2).replace('.', ',');
  }

  function beep() {
    try {
      const sound = document.getElementById('alert-sound');
      if (sound) {
        sound.currentTime = 0;
        sound.play().catch(() => {});
      }
    } catch (e) {}
  }

  function bumpCount(displayNumber) {
    const countEl = document.getElementById('new-count');
    if (!countEl) return;
    const label = displayNumber ? 'Novo ' + displayNumber : 'Novo pedido';
    countEl.innerHTML =
      '<span class="pulse-dot"></span><span data-att-count-label>' + escapeHtml(label) + '</span>';
  }

  function toastLite(text) {
    let stack = document.getElementById('att-toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.id = 'att-toast-stack';
      stack.className = 'toast-stack';
      document.body.appendChild(stack);
    }
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML =
      '<div class="t-title">Novo pedido</div><div class="t-msg">' + escapeHtml(text) + '</div>';
    stack.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity .25s';
      setTimeout(() => el.remove(), 280);
    }, 5000);
  }

  function col(status) {
    return document.querySelector('.att-col[data-col="' + status + '"]');
  }

  function ensureColHost(status) {
    const c = col(status);
    if (!c) return null;
    let host = c.querySelector('[data-cards]');
    if (!host) {
      host = document.createElement('div');
      host.setAttribute('data-cards', '1');
      // move existing cards into host once
      Array.from(c.children).forEach((ch) => {
        if (ch.matches && ch.matches('.order-card')) host.appendChild(ch);
      });
      // remove empty placeholders
      c.querySelectorAll('.empty').forEach((e) => e.remove());
      c.appendChild(host);
    }
    return host;
  }

  function updateColTitles() {
    document.querySelectorAll('.att-col[data-col]').forEach((c) => {
      const status = c.getAttribute('data-col');
      const n = c.querySelectorAll('.order-card').length;
      const title = c.querySelector('h3 span');
      if (!title) return;
      const labels = {
        PENDING: 'Novos',
        CONFIRMED: 'Confirmados',
        PREPARING: 'Preparando',
        READY: 'Prontos',
        DELIVERED: 'Entregues',
      };
      title.textContent = (labels[status] || status) + ' (' + n + ')';
    });
  }

  function buildCard(o) {
    const method = o.payment_method || '';
    const payStatus = o.payment_status || '';
    const items = (o.items || [])
      .map((i) => '<div>' + escapeHtml(i.quantity) + '× ' + escapeHtml(i.name) + '</div>')
      .join('');
    const id = o.order_id;
    const actionBase = (cfg.actionBase || '/attendant/orders/') + id + '/';
    const token = csrf();

    let payBlock = '';
    if (method === 'CASH') {
      payBlock =
        '<div class="money-alert">DINHEIRO<br>Receber: ' +
        escapeHtml(o.amount_received_formatted || money(o.amount_received)) +
        '<br>TROCO: ' +
        escapeHtml(o.change_amount_formatted || money(o.change_amount)) +
        '</div>';
    } else if (payStatus === 'AWAITING_CONFIRMATION') {
      payBlock =
        '<div class="pay-alert">' + escapeHtml(method) + ' — AGUARDANDO CONFIRMAÇÃO</div>';
    }

    const actions = [];
    if (payStatus === 'AWAITING_CONFIRMATION') {
      actions.push(btnForm(actionBase + 'confirm-payment', token, 'Confirmar pagamento', 'btn-info'));
    }
    if ((o.status || 'PENDING') === 'PENDING') {
      actions.push(btnForm(actionBase + 'confirm', token, 'Confirmar pedido', ''));
    }

    const el = document.createElement('div');
    el.className = 'order-card new';
    el.setAttribute('data-order-id', String(id));
    el.innerHTML =
      '<div class="title"><div><strong>' +
      escapeHtml(o.display_number || '#' + o.order_number) +
      '</strong><div class="muted" style="font-weight:600">Mesa ' +
      escapeHtml(o.table || '—') +
      '</div></div>' +
      '<span class="badge badge-' +
      escapeHtml(o.status || 'PENDING') +
      '">' +
      escapeHtml(o.status || 'PENDING') +
      '</span></div>' +
      '<div class="items">' +
      items +
      '</div>' +
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:.5rem">' +
      '<strong class="price">' +
      escapeHtml(o.total_formatted || money(o.total)) +
      '</strong>' +
      '<span class="badge">' +
      escapeHtml(method || '—') +
      '</span></div>' +
      payBlock +
      '<div class="actions">' +
      actions.join('') +
      '</div>';
    return el;
  }

  function btnForm(action, token, label, cls) {
    return (
      '<form method="POST" action="' +
      escapeHtml(action) +
      '">' +
      '<input type="hidden" name="_token" value="' +
      escapeHtml(token) +
      '">' +
      '<button class="btn btn-sm ' +
      escapeHtml(cls || '') +
      '" type="submit">' +
      escapeHtml(label) +
      '</button></form>'
    );
  }

  function onOrderCreated(o) {
    if (!o || !o.order_id) return;
    if (document.querySelector('.order-card[data-order-id="' + o.order_id + '"]')) {
      lastId = Math.max(lastId, o.order_id);
      return;
    }
    lastId = Math.max(lastId, o.order_id);
    const host = ensureColHost(o.status || 'PENDING') || ensureColHost('PENDING');
    if (!host) return;
    const card = buildCard(o);
    host.prepend(card);
    updateColTitles();
    bumpCount(o.display_number || '#' + o.order_number);
    beep();
    toastLite((o.display_number || '#' + o.order_number) + ' · Mesa ' + (o.table || '—'));
  }

  function scheduleReconnect(fn) {
    setTimeout(fn, backoff);
    backoff = Math.min(maxBackoff, Math.floor(backoff * 1.7));
  }

  function connectSse() {
    if (!cfg.sseUrl || !window.EventSource) {
      startPoll();
      return;
    }
    try {
      if (es) es.close();
    } catch (e) {}

    const url = cfg.sseUrl + (cfg.sseUrl.includes('?') ? '&' : '?') + 'last_id=' + lastId;
    es = new EventSource(url);

    es.addEventListener('connected', () => {
      backoff = 2000;
    });

    es.addEventListener('order.created', (ev) => {
      try {
        onOrderCreated(JSON.parse(ev.data));
        backoff = 2000;
      } catch (e) {}
    });

    es.addEventListener('reconnect', () => {
      try {
        es.close();
      } catch (e) {}
      scheduleReconnect(connectSse);
    });

    es.onerror = () => {
      try {
        es.close();
      } catch (e) {}
      scheduleReconnect(connectSse);
    };
  }

  function startPoll() {
    if (pollTimer) return;
    pollTimer = setInterval(async () => {
      if (!cfg.pollUrl) return;
      try {
        const u = cfg.pollUrl + (cfg.pollUrl.includes('?') ? '&' : '?') + 'last_id=' + lastId;
        const r = await fetch(u, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
        if (!r.ok) return;
        const j = await r.json();
        (j.data || []).forEach(onOrderCreated);
        if (j.last_id) lastId = j.last_id;
      } catch (e) {}
    }, 5000);
  }

  // Wrap existing static cards
  document.addEventListener('DOMContentLoaded', () => {
    ['PENDING', 'CONFIRMED', 'PREPARING', 'READY', 'DELIVERED'].forEach(ensureColHost);
    updateColTitles();
    connectSse();
  });
})();
