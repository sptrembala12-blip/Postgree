/**
 * Lounge Admin Mini PWA client
 * - SSE payment.confirmed + order.created
 * - toasts, badge, optional sound
 * - dashboard soft refresh from API (backend is source of truth)
 * - offline banner (no finance offline)
 * - NEVER reloads the page automatically
 */
(function () {
  const cfg = window.LOUNGE_ADMIN || {};
  const state = {
    lastOrderId: cfg.lastOrderId || 0,
    lastNotificationId: cfg.lastNotificationId || 0,
    soundEnabled: localStorage.getItem('lounge.sound') !== '0',
    volume: localStorage.getItem('lounge.volume') || 'med',
    audioUnlocked: false,
    es: null,
    pollTimer: null,
    backoff: 2000,
    maxBackoff: 30000,
    waitingSw: null,
  };

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  function iconSvg(name) {
    const icons = {
      bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
      check: '<path d="M20 6 9 17l-5-5"/>',
      wallet: '<path d="M19 7V6a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h12a2 2 0 0 1 0 4H5a2 2 0 0 0 0 4h12a2 2 0 0 0 2-2v-1"/><path d="M3 5v14"/>',
    };
    return `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.bell}</svg>`;
  }

  function setBadge(n) {
    $$('[data-unread-badge]').forEach((el) => {
      const v = Math.max(0, parseInt(n, 10) || 0);
      el.textContent = v > 99 ? '99+' : String(v);
      el.classList.toggle('is-zero', v === 0);
    });
  }

  function toast(payload) {
    const stack = $('#toast-stack') || createToastStack();
    const n = payload.notification || payload;
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `
      <div class="t-title">${iconSvg('check')} Pagamento aprovado</div>
      <div class="t-msg">${escapeHtml(n.message || payload.message || '')}</div>
      <div class="t-meta">${escapeHtml([n.display_number || (n.order_number ? '#' + n.order_number : ''), n.table_number ? 'Mesa ' + n.table_number : ''].filter(Boolean).join(' · '))} · agora</div>
    `;
    // Intentional navigation only on user click
    el.style.cursor = 'pointer';
    el.addEventListener('click', () => {
      if (n.url) window.location.assign(n.url);
      else if (n.order_id) window.location.assign('/admin/orders/' + n.order_id);
    });
    stack.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity .25s';
      setTimeout(() => el.remove(), 280);
    }, 6500);
  }

  function createToastStack() {
    const s = document.createElement('div');
    s.id = 'toast-stack';
    s.className = 'toast-stack';
    document.body.appendChild(s);
    return s;
  }

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  let audioCtx = null;
  function unlockAudio() {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      state.audioUnlocked = true;
    } catch (e) {}
  }

  function playSound() {
    if (!state.soundEnabled || !state.audioUnlocked) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      const vol = state.volume === 'high' ? 0.08 : state.volume === 'low' ? 0.02 : 0.045;
      o.type = 'sine';
      o.frequency.value = 880;
      g.gain.value = vol;
      o.connect(g);
      g.connect(audioCtx.destination);
      o.start();
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.18);
      o.stop(audioCtx.currentTime + 0.2);
    } catch (e) {}
  }

  async function refreshUnread() {
    if (!cfg.unreadUrl) return;
    try {
      const r = await fetch(cfg.unreadUrl, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
      if (!r.ok) return;
      const j = await r.json();
      setBadge(j.unread ?? 0);
    } catch (e) {}
  }

  async function refreshDashboard() {
    if (!cfg.dashboardUrl || !document.body.dataset.dashboardLive) return;
    // Never touch open forms
    if (document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
      // still update non-focused KPI nodes is ok; we only set textContent on [data-kpi]
    }
    try {
      const period = document.body.dataset.period || 'today';
      const url = cfg.dashboardUrl + (cfg.dashboardUrl.includes('?') ? '&' : '?') + 'period=' + encodeURIComponent(period);
      const r = await fetch(url, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
      if (!r.ok) return;
      const j = await r.json();
      const d = j.data || {};
      const map = {
        received: d.received_formatted,
        sales: d.sales_formatted,
        awaiting: d.awaiting_formatted,
        orders: d.orders_count,
        ticket: d.average_ticket_formatted,
        'snap-today': d.snapshots?.today?.received_formatted,
        'snap-month': d.snapshots?.month?.received_formatted,
        'snap-30d': d.snapshots?.['30d']?.received_formatted,
        'snap-3m': d.snapshots?.['3m']?.received_formatted,
        'method-PIX': d.payments_formatted?.PIX,
        'method-CREDIT_CARD': d.payments_formatted?.CREDIT_CARD,
        'method-DEBIT_CARD': d.payments_formatted?.DEBIT_CARD,
        'method-CASH': d.payments_formatted?.CASH,
      };
      Object.keys(map).forEach((k) => {
        const el = document.querySelector('[data-kpi="' + k + '"]');
        if (el && map[k] !== undefined && map[k] !== null) el.textContent = map[k];
      });
      if (Array.isArray(d.series)) renderChart(d.series);
    } catch (e) {}
  }

  function renderChart(series) {
    const root = document.querySelector('[data-chart]');
    if (!root || !series.length) return;
    const max = Math.max(1, ...series.map((s) => s.received || 0));
    root.innerHTML = series
      .map((s) => {
        const h = Math.max(4, Math.round(((s.received || 0) / max) * 140));
        return `<div class="chart-bar" title="${escapeHtml(s.received_formatted || '')}"><div class="bar" style="height:${h}px"></div><div class="lbl">${escapeHtml(s.label || '')}</div></div>`;
      })
      .join('');
  }

  function onPaymentConfirmed(payload) {
    const n = payload.notification || payload;
    if (n && n.id) state.lastNotificationId = Math.max(state.lastNotificationId, n.id);
    toast(payload);
    playSound();
    refreshUnread();
    refreshDashboard();
  }

  function onOrderCreated(payload) {
    if (payload.order_id) state.lastOrderId = Math.max(state.lastOrderId, payload.order_id);
  }

  function scheduleReconnect() {
    setTimeout(connectSse, state.backoff);
    state.backoff = Math.min(state.maxBackoff, Math.floor(state.backoff * 1.8));
  }

  function startPollFallback() {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(async () => {
      if (!cfg.pollUrl) return;
      try {
        const u =
          cfg.pollUrl +
          (cfg.pollUrl.includes('?') ? '&' : '?') +
          'last_id=' +
          state.lastOrderId +
          '&last_notification_id=' +
          state.lastNotificationId;
        const r = await fetch(u, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
        if (!r.ok) return;
        const j = await r.json();
        (j.notifications || []).forEach((n) => onPaymentConfirmed({ notification: n, type: 'payment.confirmed' }));
        (j.data || []).forEach(onOrderCreated);
        if (j.last_id) state.lastOrderId = j.last_id;
        if (j.last_notification_id) state.lastNotificationId = j.last_notification_id;
      } catch (e) {}
    }, 5000);
  }

  function connectSse() {
    if (!cfg.sseUrl || !window.EventSource) {
      startPollFallback();
      return;
    }

    const url =
      cfg.sseUrl +
      (cfg.sseUrl.includes('?') ? '&' : '?') +
      'last_id=' +
      state.lastOrderId +
      '&last_notification_id=' +
      state.lastNotificationId;

    try {
      if (state.es) state.es.close();
    } catch (e) {}

    const es = new EventSource(url);
    state.es = es;

    es.addEventListener('connected', () => {
      setOnline(true);
      state.backoff = 2000;
    });
    es.addEventListener('order.created', (ev) => {
      try {
        onOrderCreated(JSON.parse(ev.data));
      } catch (e) {}
    });
    es.addEventListener('payment.confirmed', (ev) => {
      try {
        onPaymentConfirmed(JSON.parse(ev.data));
      } catch (e) {}
    });
    es.addEventListener('reconnect', (ev) => {
      try {
        const d = JSON.parse(ev.data || '{}');
        if (d.last_id) state.lastOrderId = d.last_id;
        if (d.last_notification_id) state.lastNotificationId = d.last_notification_id;
      } catch (e) {}
      try {
        es.close();
      } catch (e) {}
      scheduleReconnect();
    });
    es.onerror = () => {
      setOnline(navigator.onLine);
      try {
        es.close();
      } catch (e) {}
      scheduleReconnect();
    };
  }

  function setOnline(on) {
    const b = document.querySelector('[data-conn-banner]');
    if (b) b.classList.toggle('show', !on);
    document.body.classList.toggle('is-offline', !on);
  }

  function bindSoundControls() {
    const en = document.querySelector('[data-sound-enabled]');
    const vol = document.querySelector('[data-sound-volume]');
    if (en) {
      en.checked = state.soundEnabled;
      en.addEventListener('change', () => {
        unlockAudio();
        state.soundEnabled = en.checked;
        localStorage.setItem('lounge.sound', state.soundEnabled ? '1' : '0');
      });
    }
    if (vol) {
      vol.value = state.volume;
      vol.addEventListener('change', () => {
        unlockAudio();
        state.volume = vol.value;
        localStorage.setItem('lounge.volume', state.volume);
        playSound();
      });
    }
  }

  function showSwUpdateBanner(reg) {
    if (document.getElementById('sw-update-banner')) return;
    const bar = document.createElement('div');
    bar.id = 'sw-update-banner';
    bar.setAttribute('role', 'status');
    bar.style.cssText =
      'position:fixed;left:12px;right:12px;bottom:calc(72px + env(safe-area-inset-bottom,0px));z-index:120;background:#1e2533;border:1px solid #2a3344;border-radius:14px;padding:.75rem 1rem;display:flex;gap:.75rem;align-items:center;justify-content:space-between;box-shadow:0 12px 40px rgba(0,0,0,.4)';
    bar.innerHTML =
      '<span style="font-size:.9rem;font-weight:700">Nova versão disponível</span>' +
      '<button type="button" class="btn btn-sm" id="sw-update-btn">Atualizar</button>';
    document.body.appendChild(bar);
    document.getElementById('sw-update-btn').addEventListener('click', () => {
      // User-initiated only
      if (state.waitingSw) {
        state.waitingSw.postMessage({ type: 'SKIP_WAITING' });
      }
      // After controller change, user chose to refresh
      navigator.serviceWorker.addEventListener(
        'controllerchange',
        () => {
          window.location.reload();
        },
        { once: true }
      );
    });
  }

  function registerSw() {
    if (!('serviceWorker' in navigator)) return;
    navigator.serviceWorker
      .register('/sw.js', { scope: '/admin' })
      .then((reg) => {
        if (reg.waiting) {
          state.waitingSw = reg.waiting;
          showSwUpdateBanner(reg);
        }
        reg.addEventListener('updatefound', () => {
          const sw = reg.installing;
          if (!sw) return;
          sw.addEventListener('statechange', () => {
            if (sw.state === 'installed' && navigator.serviceWorker.controller) {
              state.waitingSw = sw;
              showSwUpdateBanner(reg);
            }
          });
        });
      })
      .catch(() => {});
  }

  document.addEventListener('DOMContentLoaded', () => {
    setBadge(cfg.unread || 0);
    bindSoundControls();
    document.body.addEventListener('pointerdown', unlockAudio, { once: true });
    window.addEventListener('online', () => {
      setOnline(true);
      state.backoff = 2000;
      connectSse();
      refreshDashboard();
      refreshUnread();
    });
    window.addEventListener('offline', () => setOnline(false));
    setOnline(navigator.onLine);
    connectSse();
    registerSw();

    const seriesEl = document.querySelector('[data-series-json]');
    if (seriesEl) {
      try {
        renderChart(JSON.parse(seriesEl.textContent));
      } catch (e) {}
    }
  });
})();
