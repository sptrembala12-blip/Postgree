# Lounge System V1

Sistema de atendimento, pedidos, estoque e admin para lounge/bar.

**Pagamentos V1: MANUAIS** (PIX/crédito/débito aguardam confirmação do atendente; dinheiro com troco). Gateway automático = **Em breve**.

## Stack
- PHP 8.3+/8.4 · Laravel 12 · MySQL/MariaDB
- Sanctum API · Blade UI (cliente / atendente / admin)
- Dinheiro em centavos (`App\Support\Money`)
- Timezone: `America/Sao_Paulo`

## Subir local
```bash
composer install
cp .env.example .env && php artisan key:generate
# configure DB_* MySQL
php artisan migrate --seed
php artisan storage:link
php artisan serve --host=0.0.0.0 --port=8000
php artisan test
```

## URLs
| Tela | URL |
|------|-----|
| Cardápio | `/menu` |
| Mesa 08 | `/menu/table/08` |
| QR token | `/menu/t/{token}` |
| Login staff | `/admin/login` |
| Admin | `/admin` |
| Atendente | `/attendant` |
| Integrações | `/admin/integrations` |
| API | `/api/v1/...` |
| Health | `/up` |

## Credenciais demo
- Admin: `admin@lounge.local` / `password`
- Atendente: `atendente@lounge.local` / `password`

## Docs
`docs/ARCHITECTURE.md` · `API.md` · `DATABASE.md` · `DEPLOY.md` · `REALTIME.md` · `PERMISSIONS.md` · `BUSINESS_RULES.md` · `STORAGE.md`
