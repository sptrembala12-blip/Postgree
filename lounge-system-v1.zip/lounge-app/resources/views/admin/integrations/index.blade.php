@extends('admin.layouts.app')
@section('title', 'Integrações')
@section('content')
<p class="muted">Recursos futuros. Nesta V1 os pagamentos são <strong>manuais</strong> (confirmação pelo atendente).</p>
<div class="grid grid-3">
@foreach($integrations as $item)
    <div class="soon-card">
        <div style="color:var(--muted);margin-bottom:.35rem"><x-icon name="puzzle" size="xl" /></div>
        <h3 style="margin:.35rem 0">{{ $item['title'] }}</h3>
        <span class="badge badge-await">{{ $item['status'] }}</span>
        <p class="muted" style="margin:.75rem 0 0">{{ $item['description'] }}</p>
        <button class="btn btn-secondary btn-sm" type="button" disabled style="margin-top:1rem;opacity:.6">Indisponível</button>
    </div>
@endforeach
</div>
@endsection
