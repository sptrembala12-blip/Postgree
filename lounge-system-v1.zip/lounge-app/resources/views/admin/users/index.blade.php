@extends('admin.layouts.app')
@section('title', 'Usuários')
@section('content')
<div class="grid grid-2">
<div class="card">
<table>
<thead><tr><th>Nome</th><th>E-mail</th><th>Papéis</th><th>Status</th></tr></thead>
<tbody>
@foreach($users as $user)
<tr>
    <td>{{ $user->name }}</td>
    <td>{{ $user->email }}</td>
    <td>{{ $user->roles->pluck('slug')->join(', ') }}</td>
    <td>{{ $user->is_active ? 'Ativo' : 'Inativo' }}</td>
</tr>
@endforeach
</tbody>
</table>
</div>
<div class="card">
    <h3 style="margin-top:0">Novo usuário</h3>
    <form method="POST" action="{{ route('admin.users.store') }}">
        @csrf
        <label>Nome</label>
        <input name="name" required>
        <label>E-mail</label>
        <input type="email" name="email" required>
        <label>Senha</label>
        <input type="password" name="password" required minlength="8">
        <label>Papel</label>
        <select name="role" required>
            @foreach($roles as $role)
                <option value="{{ $role->slug }}">{{ $role->name }}</option>
            @endforeach
        </select>
        <button class="btn" type="submit">Criar</button>
    </form>
</div>
</div>
@endsection
