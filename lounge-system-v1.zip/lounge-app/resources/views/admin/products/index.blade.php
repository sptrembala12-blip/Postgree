@extends('admin.layouts.app')
@section('title', 'Produtos')
@section('actions')
<a class="btn" href="{{ route('admin.products.create') }}">Novo produto</a>
@endsection
@section('content')
<form class="filters card" method="GET">
    <div><label>Busca</label><input name="q" value="{{ request('q') }}"></div>
    <div>
        <label>Categoria</label>
        <select name="category_id">
            <option value="">Todas</option>
            @foreach($categories as $c)
                <option value="{{ $c->id }}" @selected(request('category_id')==$c->id)>{{ $c->name }}</option>
            @endforeach
        </select>
    </div>
    <div><button class="btn" type="submit">Filtrar</button></div>
</form>
<div class="card">
<table>
    <thead><tr><th>Nome</th><th>Categoria</th><th>Preço</th><th>Estoque</th><th>Status</th><th></th></tr></thead>
    <tbody>
    @foreach($products as $product)
        <tr>
            <td>{{ $product->name }} @if($product->is_featured)<span style="color:var(--accent);display:inline-flex;vertical-align:middle"><x-icon name="star" size="sm" /></span>@endif</td>
            <td>{{ $product->category?->name }}</td>
            <td>{{ $product->formattedPrice() }}</td>
            <td>{{ $product->stock_control_enabled ? $product->current_stock : '—' }}
                @if($product->isLowStock()) <span class="badge badge-CANCELLED">baixo</span> @endif
            </td>
            <td>{{ $product->is_active ? 'Ativo' : 'Inativo' }}</td>
            <td class="actions">
                <a class="btn btn-sm btn-secondary" href="{{ route('admin.products.edit', $product) }}">Editar</a>
                <form method="POST" action="{{ route('admin.products.destroy', $product) }}" onsubmit="return confirm('Excluir/desativar?')">
                    @csrf @method('DELETE')
                    <button class="btn btn-sm btn-danger" type="submit">Excluir</button>
                </form>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>
{{ $products->links() }}
</div>
@endsection
