@extends('admin.layouts.app')
@section('title', $product->exists ? 'Editar produto' : 'Novo produto')
@section('content')
@php
  $priceReais = old('price', $product->exists ? number_format(((int)$product->price)/100, 2, ',', '.') : '');
  $promoReais = old('promotional_price', $product->promotional_price !== null ? number_format(((int)$product->promotional_price)/100, 2, ',', '.') : '');
@endphp
<div class="card" style="max-width:760px">
<form method="POST" enctype="multipart/form-data"
      action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}">
    @csrf
    @if($product->exists) @method('PUT') @endif

    <label>Nome</label>
    <input name="name" value="{{ old('name', $product->name) }}" required>

    <label>Categoria</label>
    <select name="category_id" required>
        @foreach($categories as $c)
            <option value="{{ $c->id }}" @selected(old('category_id', $product->category_id)==$c->id)>{{ $c->name }}</option>
        @endforeach
    </select>

    <label>Descrição</label>
    <textarea name="description" rows="3">{{ old('description', $product->description) }}</textarea>

    <div class="grid grid-2">
        <div>
            <label>Preço (R$)</label>
            <input name="price" value="{{ $priceReais }}" placeholder="58,00" required>
            <div class="muted">Ex.: 58,00</div>
        </div>
        <div>
            <label>Preço promocional (R$)</label>
            <input name="promotional_price" value="{{ $promoReais }}" placeholder="opcional">
        </div>
    </div>

    <div class="grid grid-2">
        <div>
            <label>Estoque atual</label>
            <input type="number" name="current_stock" value="{{ old('current_stock', $product->current_stock ?? 0) }}" min="0" @disabled($product->exists)>
            @if($product->exists)<div class="muted">Use Estoque para movimentar.</div>@endif
        </div>
        <div>
            <label>Estoque mínimo</label>
            <input type="number" name="minimum_stock" value="{{ old('minimum_stock', $product->minimum_stock ?? 0) }}" min="0">
        </div>
    </div>

    <div class="grid grid-2">
        <div>
            <label>Estoque máximo</label>
            <input type="number" name="maximum_stock" value="{{ old('maximum_stock', $product->maximum_stock) }}" min="0">
        </div>
        <div>
            <label>Ordem</label>
            <input type="number" name="sort_order" value="{{ old('sort_order', $product->sort_order ?? 0) }}" min="0">
        </div>
    </div>

    <input type="hidden" name="stock_control_enabled" value="0">
    <label><input type="checkbox" name="stock_control_enabled" value="1" @checked(old('stock_control_enabled', $product->stock_control_enabled ?? true))> Controlar estoque</label>
    <input type="hidden" name="is_active" value="0">
    <label><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $product->is_active ?? true))> Ativo</label>
    <input type="hidden" name="is_featured" value="0">
    <label><input type="checkbox" name="is_featured" value="1" @checked(old('is_featured', $product->is_featured ?? false))> Destaque</label>

    <label>Imagem principal</label>
    <input type="file" name="image" accept="image/*">
    @if($product->exists && $product->primaryImage)
        <img src="{{ asset('storage/'.$product->primaryImage->path) }}" alt="" style="width:120px;border-radius:12px;margin:.5rem 0 1rem">
    @endif

    <button class="btn" type="submit">Salvar</button>
    <a class="btn btn-secondary" href="{{ route('admin.products.index') }}">Voltar</a>
</form>
</div>
@endsection
