@extends('admin.layouts.app')
@section('title', 'Configurações')
@section('content')
<div class="card" style="max-width:640px">
<form method="POST" action="{{ route('admin.settings.update') }}">
    @csrf
    @foreach($settings as $setting)
        <label>{{ $setting->key }} <span class="muted">({{ $setting->group }})</span></label>
        @if($setting->type === 'boolean')
            <select name="settings[{{ $setting->key }}]">
                <option value="1" @selected(filter_var($setting->value, FILTER_VALIDATE_BOOLEAN))>Sim</option>
                <option value="0" @selected(!filter_var($setting->value, FILTER_VALIDATE_BOOLEAN))>Não</option>
            </select>
        @else
            <input name="settings[{{ $setting->key }}]" value="{{ $setting->value }}">
        @endif
        @if($setting->description)<div class="muted" style="margin-top:-.5rem;margin-bottom:.75rem">{{ $setting->description }}</div>@endif
    @endforeach
    <button class="btn" type="submit">Salvar</button>
</form>
</div>
@endsection
