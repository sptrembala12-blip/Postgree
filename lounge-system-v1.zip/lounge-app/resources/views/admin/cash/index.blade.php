@extends('admin.layouts.app')
@section('title', 'Caixa')
@section('content')
<div class="grid grid-2">
    <div class="card">
        @if($register)
            <h3 style="margin-top:0">Caixa ABERTO</h3>
            <p>Aberto em {{ $register->opened_at?->format('d/m/Y H:i') }} por {{ $register->openedBy?->name }}</p>
            <p>Abertura: <strong>{{ \App\Support\Money::format((int)$register->opening_amount) }}</strong></p>
            @if($summary)
                <table>
                    <tr><td>Vendas</td><td>{{ \App\Support\Money::format($summary['sales_total']) }}</td></tr>
                    <tr><td>PIX</td><td>{{ \App\Support\Money::format($summary['pix']) }}</td></tr>
                    <tr><td>Crédito</td><td>{{ \App\Support\Money::format($summary['credit_card']) }}</td></tr>
                    <tr><td>Débito</td><td>{{ \App\Support\Money::format($summary['debit_card']) }}</td></tr>
                    <tr><td>Dinheiro (vendas)</td><td>{{ \App\Support\Money::format($summary['cash']) }}</td></tr>
                    <tr><td>Despesas</td><td>{{ \App\Support\Money::format($summary['expenses_total']) }}</td></tr>
                    <tr><td>Sangrias</td><td>{{ \App\Support\Money::format($summary['withdrawals_total']) }}</td></tr>
                    <tr><td><strong>Dinheiro esperado</strong></td><td><strong>{{ \App\Support\Money::format($summary['expected_cash']) }}</strong></td></tr>
                </table>
            @endif

            <h4>Fechar caixa</h4>
            <form method="POST" action="{{ route('admin.cash.close') }}">
                @csrf
                <label>Valor informado em dinheiro (centavos)</label>
                <input type="number" name="closing_amount" required min="0" value="{{ $summary['expected_cash'] ?? 0 }}">
                <label>Observações</label>
                <input name="notes">
                <button class="btn btn-danger" type="submit">Fechar caixa</button>
            </form>
        @else
            <h3 style="margin-top:0">Nenhum caixa aberto</h3>
            <form method="POST" action="{{ route('admin.cash.open') }}">
                @csrf
                <label>Valor de abertura (centavos)</label>
                <input type="number" name="opening_amount" value="0" min="0" required>
                <label>Observações</label>
                <input name="notes">
                <button class="btn btn-ok" type="submit">Abrir caixa</button>
            </form>
        @endif
    </div>

    <div class="card">
        <h3 style="margin-top:0">Movimentação manual</h3>
        <form method="POST" action="{{ route('admin.cash.movement') }}">
            @csrf
            <label>Tipo</label>
            <select name="type">
                <option value="DEPOSIT">Suprimento</option>
                <option value="WITHDRAWAL">Sangria</option>
                <option value="EXPENSE">Despesa</option>
                <option value="ADJUSTMENT">Ajuste</option>
            </select>
            <label>Valor (centavos)</label>
            <input type="number" name="amount" required>
            <label>Descrição</label>
            <input name="description">
            <button class="btn" type="submit">Registrar</button>
        </form>

        <h3>Histórico</h3>
        @foreach($history as $h)
            <div style="padding:.4rem 0;border-bottom:1px solid var(--border)">
                #{{ $h->id }} · {{ $h->status->value }} · {{ $h->opened_at?->format('d/m H:i') }}
                @if($h->closed_at)
                    <x-icon name="arrow-right" size="sm" /> {{ $h->closed_at->format('d/m H:i') }}
                    · Diff: {{ \App\Support\Money::format((int)$h->difference) }}
                @endif
            </div>
        @endforeach
    </div>
</div>
@endsection
