@php
  $unreadCount = $unreadCount ?? app(\App\Services\Notifications\AdminNotificationService::class)->unreadCount(auth()->user());
  $canSeeNotifications = auth()->user()->isAdmin() || auth()->user()->hasPermission('reports.view');
  $nav = [
    ['route' => 'admin.dashboard', 'match' => 'admin.dashboard', 'label' => 'Dashboard', 'icon' => 'layout-dashboard', 'bottom' => true],
    ['route' => 'admin.orders.index', 'match' => 'admin.orders.*', 'label' => 'Pedidos', 'icon' => 'shopping-bag', 'bottom' => true],
    ['route' => 'admin.cash.index', 'match' => 'admin.cash.*', 'label' => 'Caixa', 'icon' => 'wallet', 'bottom' => true],
    ['route' => 'admin.notifications.index', 'match' => 'admin.notifications.*', 'label' => 'Alertas', 'icon' => 'bell', 'bottom' => true],
    ['route' => 'admin.products.index', 'match' => 'admin.products.*', 'label' => 'Produtos', 'icon' => 'package', 'bottom' => false],
    ['route' => 'admin.categories.index', 'match' => 'admin.categories.*', 'label' => 'Categorias', 'icon' => 'tags', 'bottom' => false],
    ['route' => 'admin.stock.index', 'match' => 'admin.stock.*', 'label' => 'Estoque', 'icon' => 'boxes', 'bottom' => false],
    ['route' => 'admin.tables.index', 'match' => 'admin.tables.*', 'label' => 'Mesas', 'icon' => 'table', 'bottom' => false],
    ['route' => 'admin.reports.index', 'match' => 'admin.reports.*', 'label' => 'Relatórios', 'icon' => 'bar-chart-3', 'bottom' => false],
    ['route' => 'admin.users.index', 'match' => 'admin.users.*', 'label' => 'Usuários', 'icon' => 'users', 'bottom' => false],
    ['route' => 'admin.audit.index', 'match' => 'admin.audit.*', 'label' => 'Auditoria', 'icon' => 'scroll-text', 'bottom' => false],
    ['route' => 'admin.settings.index', 'match' => 'admin.settings.*', 'label' => 'Ajustes', 'icon' => 'settings', 'bottom' => false],
    ['route' => 'admin.integrations.index', 'match' => 'admin.integrations.*', 'label' => 'Integrações', 'icon' => 'puzzle', 'bottom' => false],
  ];
  if (!($canSeeNotifications ?? false)) {
    $nav = array_values(array_filter($nav, fn ($i) => ($i['route'] ?? '') !== 'admin.notifications.index'));
  }
  $moreActive = request()->routeIs('admin.products.*','admin.categories.*','admin.stock.*','admin.tables.*','admin.reports.*','admin.users.*','admin.audit.*','admin.settings.*','admin.integrations.*');
@endphp
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="theme-color" content="#12161f">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Lounge">
    <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
    <link rel="apple-touch-icon" href="{{ asset('pwa/icon-180.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('pwa/icon-32.png') }}">
    <title>@yield('title', 'Admin') — {{ config('app.name') }}</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
    <link rel="stylesheet" href="{{ asset('css/admin-pwa.css') }}">
    @stack('head')
</head>
<body class="pwa-body" @yield('body_attrs')>
<div class="conn-banner" data-conn-banner>Sem conexão — operações financeiras indisponíveis offline</div>

<div class="pwa-shell">
    <aside class="pwa-sidebar">
        <div class="pwa-brand">
            <x-icon name="layout-dashboard" size="lg" />
            <span>{{ config('app.name') }}</span>
        </div>
        @foreach($nav as $item)
            <a href="{{ route($item['route']) }}" class="pwa-nav-link {{ request()->routeIs($item['match']) ? 'active' : '' }}">
                <x-icon :name="$item['icon']" size="md" />
                <span>{{ $item['label'] }}</span>
                @if($item['route'] === 'admin.notifications.index')
                    <span class="badge-count {{ $unreadCount ? '' : 'is-zero' }}" data-unread-badge style="position:static;margin-left:auto">{{ $unreadCount }}</span>
                @endif
            </a>
        @endforeach
        <a href="{{ route('attendant.dashboard') }}" class="pwa-nav-link">
            <x-icon name="smartphone" size="md" />
            <span>Operação</span>
        </a>
        <div style="margin-top:auto;padding-top:1.25rem;border-top:1px solid var(--border)">
            <div class="muted" style="font-size:.8rem;padding:0 .5rem .5rem">{{ auth()->user()->name }}</div>
            <form method="POST" action="{{ route('admin.logout') }}">@csrf
                <button class="pwa-nav-link" type="submit" style="width:100%;background:transparent;border:0;cursor:pointer;text-align:left">
                    <x-icon name="log-out" size="md" />
                    <span>Sair</span>
                </button>
            </form>
        </div>
    </aside>

    <div>
        <header class="pwa-header">
            <div>
                <h1>@yield('title', 'Admin')</h1>
                <div class="sub">{{ auth()->user()->name }}</div>
            </div>
            <div style="display:flex;gap:.45rem;align-items:center">
                <a class="icon-btn" href="{{ route('admin.notifications.index') }}" aria-label="Notificações">
                    <x-icon name="bell" size="md" />
                    <span class="badge-count {{ $unreadCount ? '' : 'is-zero' }}" data-unread-badge>{{ $unreadCount }}</span>
                </a>
                <a class="icon-btn" href="{{ route('admin.settings.index') }}" aria-label="Ajustes"><x-icon name="settings" size="md" /></a>
            </div>
        </header>

        <main class="pwa-main @yield('main_class')">
            <div class="staff-top hide-mobile" style="margin-bottom:1rem">
                <h1 style="margin:0;font-size:1.35rem">@yield('title')</h1>
                <div>@yield('actions')</div>
            </div>
            <div class="hide-desktop" style="margin-bottom:.75rem">@yield('actions')</div>

            @if(session('success'))<div class="flash flash-ok">{{ session('success') }}</div>@endif
            @if($errors->any())
                <div class="flash flash-err">
                    <ul style="margin:0;padding-left:1.1rem">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
                </div>
            @endif

            @yield('content')
        </main>
    </div>
</div>

<nav class="pwa-bottom" aria-label="Navegação principal">
    <a href="{{ route('admin.dashboard') }}" class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
        <x-icon name="layout-dashboard" size="lg" />
        <span>Início</span>
    </a>
    <a href="{{ route('admin.orders.index') }}" class="{{ request()->routeIs('admin.orders.*') ? 'active' : '' }}">
        <x-icon name="shopping-bag" size="lg" />
        <span>Pedidos</span>
    </a>
    <a href="{{ route('admin.cash.index') }}" class="{{ request()->routeIs('admin.cash.*') ? 'active' : '' }}">
        <x-icon name="wallet" size="lg" />
        <span>Caixa</span>
    </a>
    <a href="{{ route('admin.notifications.index') }}" class="{{ request()->routeIs('admin.notifications.*') ? 'active' : '' }}">
        <x-icon name="bell" size="lg" />
        <span>Alertas</span>
        <span class="badge-count {{ $unreadCount ? '' : 'is-zero' }}" data-unread-badge>{{ $unreadCount }}</span>
    </a>
    <a href="{{ route('admin.products.index') }}" class="{{ $moreActive ? 'active' : '' }}">
        <x-icon name="more-horizontal" size="lg" />
        <span>Mais</span>
    </a>
</nav>

<script>
window.LOUNGE_ADMIN = {
  sseUrl: @json(url('/admin/realtime/orders-stream')),
  pollUrl: @json(url('/api/v1/admin/realtime/orders')),
  dashboardUrl: @json(url('/api/v1/admin/dashboard')),
  unreadUrl: @json(url('/api/v1/admin/notifications/unread')),
  lastOrderId: {{ (int) (\App\Models\Order::max('id') ?? 0) }},
  lastNotificationId: {{ (int) (\App\Models\AdminNotification::max('id') ?? 0) }},
  unread: {{ (int) $unreadCount }},
};
</script>
<script src="{{ asset('js/admin-pwa.js') }}" defer></script>
@stack('scripts')
<style>
@media (max-width:900px){ .hide-desktop{display:block} .hide-mobile{display:none!important} }
@media (min-width:901px){ .hide-desktop{display:none!important} }
</style>
</body>
</html>
