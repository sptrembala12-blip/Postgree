@extends('admin.layouts.app')
@section('title', 'Notificações')
@section('actions')
<form method="POST" action="{{ route('admin.notifications.read-all') }}">@csrf
    <button class="btn btn-secondary btn-sm" type="submit">Marcar todas como lidas</button>
</form>
@endsection
@section('content')
<div class="period-pills" style="margin-bottom:1rem">
    <a href="{{ route('admin.notifications.index') }}" class="{{ !$type || $type==='all' ? 'active' : '' }}">Todas</a>
    <a href="{{ route('admin.notifications.index', ['type' => 'payments']) }}" class="{{ $type==='payments' ? 'active' : '' }}">Pagamentos</a>
</div>

<div class="panel" style="margin-top:0;padding-top:.35rem">
    <div class="muted" style="padding:.5rem 0">{{ $unread }} não lidas</div>
    @forelse($notifications as $n)
        <a class="notif-item {{ $n->isRead() ? '' : 'unread' }}"
           href="{{ $n->order_id ? route('admin.orders.show', $n->order_id) : route('admin.notifications.index') }}"
           data-mark-read="{{ route('admin.notifications.read', $n) }}"
           onclick="(function(a,e){var u=a.getAttribute('data-mark-read'); if(!u) return; e.preventDefault(); var go=a.getAttribute('href'); fetch(u,{method:'POST',headers:{'X-CSRF-TOKEN':document.querySelector('meta[name=csrf-token]').content,'Accept':'application/json'},credentials:'same-origin'}).finally(function(){ window.location.assign(go); });})(this,event)">
            <div class="notif-ico"><x-icon :name="$n->type === 'payment_confirmed' ? 'circle-check' : 'bell'" size="md" /></div>
            <div>
                <div class="notif-title">{{ $n->title }}</div>
                <div class="notif-msg">{{ $n->message }}</div>
                <div class="notif-meta">
                    @if($n->order_number) Pedido #{{ $n->order_number }} @endif
                    @if($n->table_number) · Mesa {{ $n->table_number }} @endif
                    · {{ $n->created_at?->diffForHumans() }}
                </div>
            </div>
            <div>@if(!$n->isRead())<span class="dot-unread" title="Não lida"></span>@endif</div>
        </a>
    @empty
        <div class="empty">Nenhuma notificação.</div>
    @endforelse
    <div style="margin-top:1rem">{{ $notifications->links() }}</div>
</div>
@endsection
