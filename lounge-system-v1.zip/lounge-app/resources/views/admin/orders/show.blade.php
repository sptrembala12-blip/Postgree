@extends('admin.layouts.app')
@section('title', 'Pedido '.$order->displayNumber())
@section('content')
<div class="grid grid-2">
    <div class="card">
        <p><strong>Status:</strong> <span class="badge badge-{{ $order->status->value }}">{{ $order->status->label() }}</span></p>
        <p><strong>Mesa:</strong> {{ $order->table?->number ?? '—' }} {{ $order->table?->name }}</p>
        <p><strong>Cliente:</strong> {{ $order->customer_name ?? '—' }}</p>
        <p><strong>Criado:</strong> {{ $order->created_at?->format('d/m/Y H:i:s') }}</p>
        <table class="data">
            <thead><tr><th>Produto</th><th>Qtd</th><th>Unit.</th><th>Subtotal</th></tr></thead>
            <tbody>
            @foreach($order->items as $item)
                <tr>
                    <td>{{ $item->product_name_snapshot }}</td>
                    <td>{{ $item->quantity }}</td>
                    <td>{{ $item->formattedUnitPrice() }}</td>
                    <td>{{ $item->formattedSubtotal() }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <p style="margin-top:1rem"><strong>Total:</strong> {{ $order->formattedTotal() }}</p>
    </div>
    <div class="card">
        <h3 style="margin-top:0">Pagamento</h3>
        @if($order->payment)
            <p>{{ $order->payment->method->label() }} · {{ $order->payment->status->label() }}</p>
            <p>{{ $order->payment->formattedAmount() }}</p>
            @if($order->payment->method->value === 'CASH')
                <div class="money-alert">
                    RECEBER: {{ \App\Support\Money::format((int)$order->payment->amount_received) }}<br>
                    TROCO: {{ \App\Support\Money::format((int)$order->payment->change_amount) }}
                </div>
            @elseif($order->payment->status->value === 'AWAITING_CONFIRMATION')
                <div class="pay-alert">Aguardando confirmação manual do atendente/caixa.</div>
            @endif
        @endif
        <h3>Ações</h3>
        <div class="actions">
            @foreach(['confirm'=>'Confirmar','prepare'=>'Preparo','ready'=>'Pronto','deliver'=>'Entregar','complete'=>'Finalizar'] as $action => $label)
                <form method="POST" action="{{ route('admin.orders.action', [$order, $action]) }}">@csrf
                    <button class="btn btn-sm" type="submit">{{ $label }}</button>
                </form>
            @endforeach
            <form method="POST" action="{{ route('admin.orders.action', [$order, 'confirm-payment']) }}">@csrf
                <button class="btn btn-sm btn-ok" type="submit">Confirmar pagamento</button>
            </form>
            <form method="POST" action="{{ route('admin.orders.action', [$order, 'cancel']) }}" onsubmit="return confirm('Cancelar?')">@csrf
                <input type="hidden" name="reason" value="Cancelado no admin">
                <button class="btn btn-sm btn-danger" type="submit">Cancelar</button>
            </form>
        </div>
    </div>
</div>
@endsection
