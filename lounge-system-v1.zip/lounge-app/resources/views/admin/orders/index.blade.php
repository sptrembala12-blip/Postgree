@extends('admin.layouts.app')
@section('title', 'Pedidos')
@section('content')
<form method="GET" class="card" style="display:flex;flex-wrap:wrap;gap:.75rem;align-items:end">
    <div><label>Status</label>
        <select name="status"><option value="">Todos</option>
            @foreach($statuses as $s)<option value="{{ $s->value }}" @selected(request('status')===$s->value)>{{ $s->label() }}</option>@endforeach
        </select>
    </div>
    <div><label>Mesa</label>
        <select name="table_id"><option value="">Todas</option>
            @foreach($tables as $t)<option value="{{ $t->id }}" @selected(request('table_id')==$t->id)>{{ $t->number }}</option>@endforeach
        </select>
    </div>
    <div><label>Pagamento</label>
        <select name="payment_method"><option value="">Todos</option>
            @foreach(['PIX','CREDIT_CARD','DEBIT_CARD','CASH'] as $m)
                <option value="{{ $m }}" @selected(request('payment_method')===$m)>{{ $m }}</option>
            @endforeach
        </select>
    </div>
    <div><label>Nº</label><input type="number" name="order_number" value="{{ request('order_number') }}"></div>
    <button class="btn" type="submit">Filtrar</button>
</form>
<div class="card" style="margin-top:1rem">
<table class="data">
<thead><tr><th>#</th><th>Mesa</th><th>Itens</th><th>Total</th><th>Pagamento</th><th>Status</th><th></th></tr></thead>
<tbody>
@forelse($orders as $order)
<tr>
    <td><strong>{{ $order->displayNumber() }}</strong><div class="muted">{{ $order->created_at?->format('d/m H:i') }}</div></td>
    <td>{{ $order->table?->number ?? '—' }}</td>
    <td>@foreach($order->items as $item)<div class="muted">{{ $item->quantity }}x {{ $item->product_name_snapshot }}</div>@endforeach</td>
    <td>{{ $order->formattedTotal() }}</td>
    <td>
        {{ $order->payment?->method?->label() }} · {{ $order->payment?->status?->label() }}
        @if($order->payment?->method?->value === 'CASH')
            <div class="money-alert" style="margin-top:.35rem">
                Receber {{ \App\Support\Money::format((int)$order->payment->amount_received) }}
                · Troco {{ \App\Support\Money::format((int)$order->payment->change_amount) }}
            </div>
        @endif
    </td>
    <td><span class="badge badge-{{ $order->status->value }}">{{ $order->status->label() }}</span></td>
    <td><a class="btn btn-sm btn-secondary" href="{{ route('admin.orders.show', $order) }}">Ver</a></td>
</tr>
@empty
<tr><td colspan="7" class="empty">Nenhum pedido.</td></tr>
@endforelse
</tbody>
</table>
<div style="margin-top:1rem">{{ $orders->links() }}</div>
</div>
@endsection
