@extends('admin.layouts.app')

@section('title', 'Dashboard')
@section('body_attrs')
data-dashboard-live="1" data-period="{{ $period }}"
@endsection

@section('actions')
<div class="period-pills">
    @foreach(['today'=>'Hoje','7d'=>'7 dias','30d'=>'30 dias','month'=>'Este mês','3m'=>'3 meses'] as $k => $label)
        <a href="{{ route('admin.dashboard', ['period' => $k]) }}" class="{{ $period === $k ? 'active' : '' }}">{{ $label }}</a>
    @endforeach
</div>
@endsection

@section('content')
@php
  $snap = $data['snapshots'] ?? [];
  $today = $snap['today'] ?? [];
  $month = $snap['month'] ?? [];
  $d30 = $snap['30d'] ?? [];
  $d3m = $snap['3m'] ?? [];
@endphp

<div class="hello-row">
    <div>
        <h2>Olá, {{ explode(' ', auth()->user()->name)[0] }}</h2>
        <div class="muted">{{ $data['server_date_label'] ?? now()->translatedFormat('d \d\e F \d\e Y') }}</div>
    </div>
    <div class="sound-bar">
        <label><input type="checkbox" data-sound-enabled> Som</label>
        <select data-sound-volume>
            <option value="low">Baixo</option>
            <option value="med" selected>Médio</option>
            <option value="high">Alto</option>
        </select>
    </div>
</div>

<div class="kpi-grid">
    <div class="kpi accent">
        <div class="kpi-label"><x-icon name="banknote" size="sm" /> Recebido (período)</div>
        <div class="kpi-value" data-kpi="received">{{ $data['received_formatted'] }}</div>
        <div class="kpi-meta">Somente pagamentos confirmados</div>
    </div>
    <div class="kpi">
        <div class="kpi-label"><x-icon name="trending-up" size="sm" /> Vendas (pedidos)</div>
        <div class="kpi-value" data-kpi="sales">{{ $data['sales_formatted'] }}</div>
        <div class="kpi-meta"><span data-kpi="orders">{{ $data['orders_count'] }}</span> pedidos · ticket <span data-kpi="ticket">{{ $data['average_ticket_formatted'] }}</span></div>
    </div>
    <div class="kpi warn">
        <div class="kpi-label"><x-icon name="clock" size="sm" /> Aguardando</div>
        <div class="kpi-value" data-kpi="awaiting">{{ $data['awaiting_formatted'] }}</div>
        <div class="kpi-meta">{{ $data['awaiting_count'] ?? 0 }} pagamentos</div>
    </div>
    <div class="kpi ok">
        <div class="kpi-label"><x-icon name="receipt" size="sm" /> Vendas hoje</div>
        <div class="kpi-value" data-kpi="snap-today">{{ $today['received_formatted'] ?? 'R$ 0,00' }}</div>
        <div class="kpi-meta">{{ $today['orders_count'] ?? 0 }} pedidos · recebido confirmado</div>
    </div>
</div>

<div class="kpi-grid" style="margin-top:.75rem">
    <div class="kpi">
        <div class="kpi-label">Este mês</div>
        <div class="kpi-value" data-kpi="snap-month" style="font-size:1.15rem">{{ $month['received_formatted'] ?? 'R$ 0,00' }}</div>
        <div class="kpi-meta">{{ $month['orders_count'] ?? 0 }} pedidos</div>
    </div>
    <div class="kpi">
        <div class="kpi-label">Últimos 30 dias</div>
        <div class="kpi-value" data-kpi="snap-30d" style="font-size:1.15rem">{{ $d30['received_formatted'] ?? 'R$ 0,00' }}</div>
        <div class="kpi-meta">{{ $d30['orders_count'] ?? 0 }} pedidos</div>
    </div>
    <div class="kpi">
        <div class="kpi-label">Últimos 3 meses</div>
        <div class="kpi-value" data-kpi="snap-3m" style="font-size:1.15rem">{{ $d3m['received_formatted'] ?? 'R$ 0,00' }}</div>
        <div class="kpi-meta">{{ $d3m['orders_count'] ?? 0 }} pedidos</div>
    </div>
    <div class="kpi">
        <div class="kpi-label">Mesas / Estoque</div>
        <div class="kpi-value" style="font-size:1.15rem">{{ $data['tables']['occupied'] }} / {{ $data['low_stock_products'] }}</div>
        <div class="kpi-meta">ocupadas · alertas de estoque</div>
    </div>
</div>

<div class="panel">
    <h3><x-icon name="credit-card" size="md" /> Recebido por método</h3>
    <div class="method-grid">
        @foreach(['PIX'=>'PIX','CREDIT_CARD'=>'Crédito','DEBIT_CARD'=>'Débito','CASH'=>'Dinheiro'] as $k => $label)
            <div class="method-card">
                <div class="m-label">{{ $label }}</div>
                <div class="m-value" data-kpi="method-{{ $k }}">{{ $data['payments_formatted'][$k] ?? 'R$ 0,00' }}</div>
            </div>
        @endforeach
    </div>
</div>

<div class="panel">
    <h3><x-icon name="bar-chart-3" size="md" /> Evolução do recebido</h3>
    <div class="chart-wrap">
        <div class="chart" data-chart></div>
    </div>
    <script type="application/json" data-series-json>@json($data['series'] ?? [])</script>
</div>

<div class="grid grid-2" style="gap:1rem">
    <div class="panel" style="margin-top:0">
        <h3><x-icon name="package" size="md" /> Mais vendidos</h3>
        @forelse($topProducts as $i => $row)
            <div class="rank-row">
                <div class="rank-left">
                    <div class="rank-num">{{ $i+1 }}</div>
                    <div style="min-width:0">
                        <div class="rank-name">{{ $row['product_name'] }}</div>
                        <div class="rank-meta">{{ $row['quantity_sold'] }} un.</div>
                    </div>
                </div>
                <div class="rank-val">{{ $row['revenue_formatted'] }}</div>
            </div>
        @empty
            <div class="empty">Sem vendas no período.</div>
        @endforelse
    </div>

    <div class="panel" style="margin-top:0">
        <h3><x-icon name="shopping-bag" size="md" /> Pedidos recentes</h3>
        <table class="data">
            <thead><tr><th>Pedido</th><th>Mesa</th><th>Total</th><th>Pag.</th></tr></thead>
            <tbody>
            @foreach($recentOrders as $order)
                <tr>
                    <td><a href="{{ route('admin.orders.show', $order) }}">{{ $order->displayNumber() }}</a></td>
                    <td>{{ $order->table?->number ?? '—' }}</td>
                    <td>{{ $order->formattedTotal() }}</td>
                    <td class="muted" style="font-size:.8rem">{{ $order->payment?->method?->label() }} · {{ $order->payment?->status?->label() }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>

@if($lowStock->isNotEmpty())
<div class="panel">
    <h3><x-icon name="boxes" size="md" /> Estoque baixo</h3>
    @foreach($lowStock as $p)
        <div class="rank-row">
            <div class="rank-name">{{ $p->name }}</div>
            <div class="rank-meta">{{ $p->current_stock }} / min {{ $p->minimum_stock }}</div>
        </div>
    @endforeach
</div>
@endif
@endsection
