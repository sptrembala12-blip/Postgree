<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#12161f">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
    <link rel="apple-touch-icon" href="{{ asset('pwa/icon-180.png') }}">
    <title>Login — {{ config('app.name') }}</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
    <link rel="stylesheet" href="{{ asset('css/admin-pwa.css') }}">
    <style>body{min-height:100vh;display:grid;place-items:center;padding:1rem;background:radial-gradient(800px 400px at 20% 0%, #1a1408, var(--bg));}</style>
</head>
<body>
<div class="card" style="width:min(420px,100%)">
    <h1 style="margin:0 0 .35rem;font-size:1.4rem">Lounge Admin</h1>
    <p class="muted" style="margin-top:0">Acesso staff (admin / atendente). Pode instalar como app na tela inicial.</p>
    @if($errors->any())<div class="flash flash-err">{{ $errors->first() }}</div>@endif
    <form method="POST" action="{{ route('admin.login.submit') }}">
        @csrf
        <label>E-mail</label>
        <input type="email" name="email" value="{{ old('email', 'admin@lounge.local') }}" required autofocus>
        <label>Senha</label>
        <input type="password" name="password" value="password" required>
        <label style="display:flex;align-items:center;gap:.45rem;margin-bottom:1rem">
            <input type="checkbox" name="remember" value="1" style="width:auto;margin:0"> Lembrar
        </label>
        <button class="btn btn-block btn-lg" type="submit">Entrar</button>
    </form>
    <p class="muted" style="font-size:.8rem;margin-top:1rem">Demo: admin@lounge.local / password · atendente@lounge.local / password</p>
</div>
</body>
</html>
