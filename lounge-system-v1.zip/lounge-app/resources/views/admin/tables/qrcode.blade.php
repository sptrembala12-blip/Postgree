@extends('admin.layouts.app')
@section('title', 'QR Code — Mesa '.$table->number)
@section('actions')
<button class="btn btn-secondary no-print" onclick="window.print()">Imprimir</button>
<form method="POST" action="{{ route('admin.tables.qrcode.regenerate', $table) }}" class="no-print">
    @csrf
    <button class="btn btn-secondary" type="submit">Regenerar QR</button>
</form>
@endsection
@section('content')
<div class="card" style="max-width:420px;text-align:center">
    <h2 style="margin-top:0">Mesa {{ $table->number }}</h2>
    <p class="muted">{{ $table->name }} · {{ $table->type->label() }}</p>
    @if($table->qr_code_path)
        <img src="{{ asset('storage/'.$table->qr_code_path) }}" alt="QR Code" style="width:260px;height:260px;background:#fff;padding:12px;border-radius:12px">
    @endif
    <p style="word-break:break-all">{{ $table->publicTokenUrl() }}</p>
    <p class="muted">Aponte a câmera para abrir o cardápio da mesa.</p>
</div>
@endsection
