@extends('admin.layouts.app')
@section('title', 'Mesa '.$table->number)
@section('actions')
<a class="btn btn-secondary" href="{{ route('admin.tables.qrcode', $table) }}">QR Code</a>
@endsection
@section('content')
<div class="grid grid-2">
    <div class="card">
        <p><strong>Status:</strong> <span class="badge badge-{{ $table->status->value }}">{{ $table->status->label() }}</span></p>
        <p class="muted">{{ $table->name }} · {{ $table->location }} · {{ $table->capacity }} lugares</p>
        @if($session)
            <div class="price" style="font-size:1.8rem">{{ \App\Support\Money::format((int)$session->total_amount) }}</div>
            <div class="muted">Sessão #{{ $session->id }} · aberta {{ $session->opened_at?->format('d/m/Y H:i') }}</div>
            <form method="POST" action="{{ route('admin.tables.sessions.close', $table) }}" style="margin-top:1rem" onsubmit="return confirm('Encerrar sessão?')">
                @csrf
                <button class="btn btn-danger" type="submit">Encerrar sessão</button>
            </form>
        @else
            <form method="POST" action="{{ route('admin.tables.sessions.open', $table) }}">@csrf
                <button class="btn" type="submit">Abrir sessão</button>
            </form>
        @endif
    </div>
    <div class="card">
        <h3 style="margin-top:0">Pedidos da sessão atual</h3>
        @forelse($orders as $order)
            <div style="padding:.55rem 0;border-bottom:1px solid var(--border)">
                <a href="{{ route('admin.orders.show', $order) }}"><strong>{{ $order->displayNumber() }}</strong></a>
                · {{ $order->formattedTotal() }}
                · <span class="badge badge-{{ $order->status->value }}">{{ $order->status->label() }}</span>
                <div class="muted">{{ $order->payment?->method?->label() }} · {{ $order->payment?->status?->label() }}</div>
            </div>
        @empty
            <div class="empty">Nenhum pedido.</div>
        @endforelse
    </div>
</div>
@endsection
