@extends('admin.layouts.app')
@section('title', $table->exists ? 'Editar mesa' : 'Nova mesa')
@section('content')
<div class="card" style="max-width:640px">
<form method="POST" action="{{ $table->exists ? route('admin.tables.update', $table) : route('admin.tables.store') }}">
    @csrf
    @if($table->exists) @method('PUT') @endif
    <div class="form-row">
        <div>
            <label>Número</label>
            <input name="number" value="{{ old('number', $table->number) }}" required>
        </div>
        <div>
            <label>Nome</label>
            <input name="name" value="{{ old('name', $table->name) }}">
        </div>
    </div>
    <div class="form-row">
        <div>
            <label>Tipo</label>
            <select name="type" required>
                <option value="TABLE" @selected(old('type', $table->type?->value)==='TABLE')>Mesa</option>
                <option value="LOUNGE" @selected(old('type', $table->type?->value)==='LOUNGE')>Lounge</option>
            </select>
        </div>
        <div>
            <label>Capacidade</label>
            <input type="number" name="capacity" value="{{ old('capacity', $table->capacity ?? 4) }}" min="1">
        </div>
    </div>
    <label>Localização</label>
    <input name="location" value="{{ old('location', $table->location) }}">
    <label>Status</label>
    <select name="status">
        @foreach(\App\Enums\TableStatus::cases() as $s)
            <option value="{{ $s->value }}" @selected(old('status', $table->status?->value ?? 'AVAILABLE')===$s->value)>{{ $s->label() }}</option>
        @endforeach
    </select>
    <input type="hidden" name="is_active" value="0">
    <label><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $table->is_active ?? true))> Ativa</label>
    <button class="btn" type="submit">Salvar</button>
</form>
</div>
@endsection
