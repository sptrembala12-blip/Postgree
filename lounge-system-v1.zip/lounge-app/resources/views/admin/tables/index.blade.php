@extends('admin.layouts.app')
@section('title', 'Mesas')
@section('actions')
<a class="btn" href="{{ route('admin.tables.create') }}">Nova mesa</a>
@endsection
@section('content')
<div class="grid grid-3">
@foreach($tables as $table)
    @php $session = $table->currentSession; @endphp
    <div class="table-tile {{ $table->status->value }}">
        <div style="display:flex;justify-content:space-between;gap:.5rem">
            <div>
                <strong>{{ $table->type->label() }} {{ $table->number }}</strong>
                <div class="muted">{{ $table->name }}</div>
            </div>
            <span class="badge badge-{{ $table->status->value }}">{{ $table->status->label() }}</span>
        </div>
        @if($session)
            <div class="price" style="margin-top:.75rem">{{ \App\Support\Money::format((int)$session->total_amount) }}</div>
            <div class="muted">Sessão aberta desde {{ $session->opened_at?->format('H:i') }}</div>
        @endif
        <div class="actions" style="margin-top:.8rem">
            <a class="btn btn-sm btn-secondary" href="{{ route('admin.tables.show', $table) }}">Consumo</a>
            <a class="btn btn-sm btn-secondary" href="{{ route('admin.tables.edit', $table) }}">Editar</a>
            <a class="btn btn-sm" href="{{ route('admin.tables.qrcode', $table) }}">QR</a>
        </div>
    </div>
@endforeach
</div>
@endsection
