@extends('admin.layouts.app')
@section('title', 'Auditoria')
@section('content')
<form method="GET" class="filters card">
    <div><label>Ação</label><input name="action" value="{{ request('action') }}"></div>
    <div><button class="btn" type="submit">Filtrar</button></div>
</form>
<div class="card">
<table>
<thead><tr><th>Quando</th><th>Usuário</th><th>Ação</th><th>Entidade</th><th>IP</th></tr></thead>
<tbody>
@foreach($logs as $log)
<tr>
    <td class="muted">{{ $log->created_at?->format('d/m/Y H:i:s') }}</td>
    <td>{{ $log->user?->name ?? '—' }}</td>
    <td><span class="badge">{{ $log->action }}</span></td>
    <td class="muted">{{ class_basename((string)$log->entity_type) }} #{{ $log->entity_id }}</td>
    <td class="muted">{{ $log->ip_address }}</td>
</tr>
@endforeach
</tbody>
</table>
{{ $logs->links() }}
</div>
@endsection
