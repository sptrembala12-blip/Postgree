@extends('admin.layouts.app')
@section('title', 'Relatórios')
@section('content')
<form method="GET" class="filters card">
    <div><label>De</label><input type="date" name="from" value="{{ $from }}"></div>
    <div><label>Até</label><input type="date" name="to" value="{{ $to }}"></div>
    <div><button class="btn" type="submit">Aplicar</button></div>
</form>

<div class="grid grid-2">
    <div class="card">
        <h3 style="margin-top:0">Por produto</h3>
        <table>
            <thead><tr><th>Produto</th><th>Qtd</th><th>Faturamento</th></tr></thead>
            <tbody>
            @foreach($products as $row)
                <tr>
                    <td>{{ $row['product_name'] }}</td>
                    <td>{{ $row['quantity_sold'] }}</td>
                    <td>{{ $row['revenue_formatted'] }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    <div class="card">
        <h3 style="margin-top:0">Por categoria</h3>
        <table>
            <thead><tr><th>Categoria</th><th>Qtd</th><th>Faturamento</th></tr></thead>
            <tbody>
            @foreach($categories as $row)
                <tr>
                    <td>{{ $row['category_name'] }}</td>
                    <td>{{ $row['quantity_sold'] }}</td>
                    <td>{{ $row['revenue_formatted'] }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    <div class="card">
        <h3 style="margin-top:0">Por pagamento</h3>
        <table>
            @foreach($payments['methods'] as $m)
                <tr><td>{{ $m['method'] }}</td><td>{{ $m['count'] }}x</td><td>{{ $m['total_formatted'] }}</td></tr>
            @endforeach
            <tr><td colspan="2"><strong>Total</strong></td><td><strong>{{ $payments['total_formatted'] }}</strong></td></tr>
        </table>
    </div>
    <div class="card">
        <h3 style="margin-top:0">Por mesa</h3>
        <table>
            <thead><tr><th>Mesa</th><th>Pedidos</th><th>Consumo</th></tr></thead>
            <tbody>
            @foreach($tables as $row)
                <tr>
                    <td>{{ $row['table_number'] }}</td>
                    <td>{{ $row['orders_count'] }}</td>
                    <td>{{ $row['consumption_formatted'] }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
