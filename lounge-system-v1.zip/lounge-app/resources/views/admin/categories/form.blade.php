@extends('admin.layouts.app')
@section('title', $category->exists ? 'Editar categoria' : 'Nova categoria')
@section('content')
<div class="card" style="max-width:640px">
<form method="POST" action="{{ $category->exists ? route('admin.categories.update', $category) : route('admin.categories.store') }}">
    @csrf
    @if($category->exists) @method('PUT') @endif
    <label>Nome</label>
    <input name="name" value="{{ old('name', $category->name) }}" required>
    <label>Descrição</label>
    <textarea name="description" rows="3">{{ old('description', $category->description) }}</textarea>
    <label>Ordem</label>
    <input type="number" name="sort_order" value="{{ old('sort_order', $category->sort_order ?? 0) }}">
    <input type="hidden" name="is_active" value="0">
    <label><input type="checkbox" name="is_active" value="1" @checked(old('is_active', $category->is_active ?? true))> Ativa</label>
    <button class="btn" type="submit">Salvar</button>
</form>
</div>
@endsection
