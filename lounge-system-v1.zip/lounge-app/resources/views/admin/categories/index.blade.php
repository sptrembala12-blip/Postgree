@extends('admin.layouts.app')
@section('title', 'Categorias')
@section('actions')
<a class="btn" href="{{ route('admin.categories.create') }}">Nova categoria</a>
@endsection
@section('content')
<div class="card">
<table>
<thead><tr><th>Nome</th><th>Slug</th><th>Produtos</th><th>Ordem</th><th>Status</th><th></th></tr></thead>
<tbody>
@foreach($categories as $category)
<tr>
    <td>{{ $category->name }}</td>
    <td class="muted">{{ $category->slug }}</td>
    <td>{{ $category->products_count }}</td>
    <td>{{ $category->sort_order }}</td>
    <td>{{ $category->is_active ? 'Ativa' : 'Inativa' }}</td>
    <td class="actions">
        <a class="btn btn-sm btn-secondary" href="{{ route('admin.categories.edit', $category) }}">Editar</a>
        <form method="POST" action="{{ route('admin.categories.destroy', $category) }}" onsubmit="return confirm('Excluir?')">
            @csrf @method('DELETE')
            <button class="btn btn-sm btn-danger" type="submit">Excluir</button>
        </form>
    </td>
</tr>
@endforeach
</tbody>
</table>
</div>
@endsection
