@extends('admin.layouts.app')
@section('title', 'Estoque')
@section('content')
<div class="grid grid-2">
<div class="card">
    <h3 style="margin-top:0">Produtos</h3>
    <form method="GET" class="filters">
        <label><input type="checkbox" name="low_stock" value="1" @checked(request('low_stock')) onchange="this.form.submit()"> Somente baixos</label>
    </form>
    <table>
        <thead><tr><th>Produto</th><th>Atual</th><th>Mín</th><th>Máx</th><th>Status</th></tr></thead>
        <tbody>
        @foreach($products as $p)
            <tr>
                <td>{{ $p->name }}</td>
                <td>{{ $p->current_stock }}</td>
                <td>{{ $p->minimum_stock }}</td>
                <td>{{ $p->maximum_stock ?? '—' }}</td>
                <td>@if($p->isLowStock())<span class="badge badge-CANCELLED">Baixo</span>@else<span class="badge badge-COMPLETED">OK</span>@endif</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    {{ $products->links() }}
</div>
<div>
    <div class="card">
        <h3 style="margin-top:0">Nova movimentação</h3>
        <form method="POST" action="{{ route('admin.stock.move') }}">
            @csrf
            <label>Produto</label>
            <select name="product_id" required>
                @foreach(\App\Models\Product::where('stock_control_enabled',true)->orderBy('name')->get() as $p)
                    <option value="{{ $p->id }}">{{ $p->name }} ({{ $p->current_stock }})</option>
                @endforeach
            </select>
            <label>Tipo</label>
            <select name="type" required>
                <option value="PURCHASE">Entrada / Compra</option>
                <option value="LOSS">Perda</option>
                <option value="RETURN">Devolução</option>
                <option value="ADJUSTMENT">Ajuste (+/-)</option>
            </select>
            <label>Quantidade</label>
            <input type="number" name="quantity" required>
            <label>Motivo</label>
            <input name="reason">
            <button class="btn" type="submit">Registrar</button>
        </form>
    </div>
    <div class="card">
        <h3 style="margin-top:0">Últimas movimentações</h3>
        @foreach($movements as $m)
            <div style="padding:.4rem 0;border-bottom:1px solid var(--border)">
                <strong>{{ $m->product?->name }}</strong>
                <span class="badge">{{ $m->type->value }}</span>
                <div class="muted">{{ $m->quantity > 0 ? '+' : '' }}{{ $m->quantity }} · {{ $m->previous_stock }} <x-icon name="arrow-right" size="sm" /> {{ $m->new_stock }} · {{ $m->created_at?->format('d/m H:i') }}</div>
            </div>
        @endforeach
    </div>
</div>
</div>
@endsection
