<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Carrinho</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
</head>
<body class="menu-body" style="padding-bottom:2rem">
<header class="menu-top">
    <a class="btn btn-ghost btn-sm icon-inline" href="{{ $table ? route('menu.table', $table->number) : route('menu.index') }}">
        <x-icon name="arrow-left" size="sm" />
        <span>Cardápio</span>
    </a>
    <strong class="icon-inline"><x-icon name="shopping-cart" size="sm" /> <span>Carrinho</span></strong>
</header>
@if(session('success'))<div class="container flash flash-ok">{{ session('success') }}</div>@endif
@if($errors->any())<div class="container flash flash-err">{{ $errors->first() }}</div>@endif

<main class="container" style="padding:1rem">
    @if(empty($summary['items']))
        <div class="empty">
            <div style="margin-bottom:.75rem;color:var(--muted)"><x-icon name="shopping-cart" size="xl" /></div>
            Seu carrinho está vazio.
        </div>
        <a class="btn btn-block" href="{{ $table ? route('menu.table', $table->number) : route('menu.index') }}">Voltar ao cardápio</a>
    @else
        <div class="card">
            @foreach($summary['items'] as $item)
                <div style="display:flex;justify-content:space-between;gap:1rem;padding:.7rem 0;border-bottom:1px solid var(--border)">
                    <div>
                        <strong>{{ $item['name'] }}</strong>
                        <div class="muted">{{ $item['unit_price_formatted'] }} cada</div>
                        <form method="POST" action="{{ route('menu.cart.update') }}" style="margin-top:.45rem">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $item['product_id'] }}">
                            <div class="qty-ctrl">
                                <button type="submit" name="quantity" value="{{ max(0, $item['quantity']-1) }}" aria-label="Diminuir"><x-icon name="minus" size="sm" /></button>
                                <span style="min-width:1.5rem;text-align:center">{{ $item['quantity'] }}</span>
                                <button type="submit" name="quantity" value="{{ $item['quantity']+1 }}" aria-label="Aumentar"><x-icon name="plus" size="sm" /></button>
                            </div>
                        </form>
                    </div>
                    <div style="text-align:right">
                        <div class="price">{{ $item['subtotal_formatted'] }}</div>
                        <form method="POST" action="{{ route('menu.cart.update') }}" style="margin-top:.4rem">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $item['product_id'] }}">
                            <button class="btn btn-ghost btn-sm icon-inline" name="quantity" value="0" type="submit">
                                <x-icon name="trash-2" size="sm" />
                                <span>Remover</span>
                            </button>
                        </form>
                    </div>
                </div>
            @endforeach
            <div style="display:flex;justify-content:space-between;margin-top:1rem;font-size:1.2rem">
                <strong>Total</strong>
                <strong class="price">{{ $summary['total_formatted'] }}</strong>
            </div>
        </div>
        <a class="btn btn-block btn-lg icon-inline" style="margin-top:1rem;gap:.5rem" href="{{ route('menu.checkout') }}">
            <x-icon name="arrow-right" size="sm" />
            <span>Continuar</span>
        </a>
        <a class="btn btn-block btn-secondary" style="margin-top:.5rem" href="{{ $table ? route('menu.table', $table->number) : route('menu.index') }}">Adicionar mais itens</a>
    @endif
</main>
</body>
</html>
