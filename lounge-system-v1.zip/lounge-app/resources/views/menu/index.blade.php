@php
  $catIcon = [
    'Bebidas' => 'coffee',
    'Cervejas' => 'beer',
    'Whisky' => 'wine',
    'Drinks' => 'glass-water',
    'Narguilé' => 'flame',
    'Essências' => 'leaf',
    'Cigarros' => 'cigarette',
    'Snacks' => 'candy',
  ];
@endphp
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Cardápio @if($table)— Mesa {{ $table->number }}@endif</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
</head>
<body class="menu-body">
<header class="menu-top">
    <div class="menu-brand">
        Lounge
        <small>
            @if($table) Mesa {{ $table->number }} · {{ $table->name }} @else Bem-vindo @endif
        </small>
    </div>
    <a class="btn btn-sm icon-inline" href="{{ route('menu.cart') }}">
        <x-icon name="shopping-cart" size="sm" />
        <span>{{ $summary['items_count'] }}</span>
    </a>
</header>

@if(session('success'))<div class="container flash flash-ok">{{ session('success') }}</div>@endif
@if($errors->any())<div class="container flash flash-err">{{ $errors->first() }}</div>@endif

<div class="container" style="padding:1rem 1rem 0">
    <div style="font-size:1.35rem;font-weight:900;margin-bottom:.15rem">Bem-vindo</div>
    <div class="muted">@if($table)Você está na <strong style="color:var(--text)">Mesa {{ $table->number }}</strong>. @endif Escolha e peça pelo celular.</div>
</div>

<nav class="chip-row">
    @foreach($categories as $category)
        @if($category->products->isEmpty()) @continue @endif
        <a class="chip icon-inline" href="#cat-{{ $category->id }}">
            <x-icon :name="$catIcon[$category->name] ?? 'sparkles'" size="sm" />
            <span>{{ $category->name }}</span>
        </a>
    @endforeach
</nav>

@foreach($categories as $category)
    @if($category->products->isEmpty()) @continue @endif
    <section class="menu-section" id="cat-{{ $category->id }}">
        <h2 class="icon-inline">
            <x-icon :name="$catIcon[$category->name] ?? 'sparkles'" size="md" />
            <span>{{ $category->name }}</span>
        </h2>
        @foreach($category->products as $product)
            @php
                $url = route('menu.product', $product->slug) . ($table ? '?table='.$table->number : '');
                $img = $product->primaryImage;
            @endphp
            <a class="product-card" href="{{ $url }}" style="color:inherit">
                @if($img)
                    <img class="thumb" src="{{ asset('storage/'.$img->path) }}" alt="">
                @else
                    <div class="thumb-icon"><x-icon :name="$catIcon[$category->name] ?? 'package'" size="lg" /></div>
                @endif
                <div>
                    <h3>{{ $product->name }}</h3>
                    <p>{{ $product->description }}</p>
                    <div class="price" style="margin-top:.35rem">{{ $product->formattedPrice() }}</div>
                </div>
                <div>
                    @if($product->isAvailableForSale())
                        <span class="btn btn-sm" aria-label="Ver produto"><x-icon name="plus" size="sm" /></span>
                    @else
                        <span class="badge badge-danger">Esgotado</span>
                    @endif
                </div>
            </a>
        @endforeach
    </section>
@endforeach

<div class="menu-dock">
    <div>
        <div class="muted" style="font-size:.8rem">Total do carrinho</div>
        <strong style="font-size:1.15rem">{{ $summary['total_formatted'] }}</strong>
    </div>
    <a class="btn icon-inline" href="{{ route('menu.cart') }}">
        <x-icon name="shopping-bag" size="sm" />
        <span>Ver carrinho ({{ $summary['items_count'] }})</span>
    </a>
</div>
</body>
</html>
