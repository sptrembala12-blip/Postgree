<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Pedido {{ $order->displayNumber() }}</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
</head>
<body class="menu-body" style="padding-bottom:2rem"
      data-order-status="{{ $order->status->value }}"
      data-pay-status="{{ $order->payment?->status?->value }}"
      data-pay-method="{{ $order->payment?->method?->value }}">
<header class="menu-top">
    <div class="menu-brand">Pedido {{ $order->displayNumber() }}
        <small>Mesa {{ $order->table?->number ?? '—' }}</small>
    </div>
</header>
<main class="container" style="padding:1rem">
    <div class="card">
        <div class="flash flash-ok icon-inline" style="margin-top:0;gap:.45rem">
            <x-icon name="circle-check" size="sm" />
            <span>Pedido enviado com sucesso</span>
        </div>
        <div style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap">
            <div>
                <div class="muted">Total</div>
                <div class="price" style="font-size:1.4rem">{{ $order->formattedTotal() }}</div>
            </div>
            <div>
                <div class="muted">Pagamento</div>
                <div class="icon-inline" style="gap:.35rem">
                    @php $m = $order->payment?->method?->value; @endphp
                    <x-icon :name="$m === 'CASH' ? 'banknote' : ($m === 'PIX' ? 'qr-code' : 'credit-card')" size="sm" />
                    <span class="badge badge-{{ $m === 'CASH' ? 'CASH' : ($m === 'PIX' ? 'PIX' : 'CARD') }}">{{ $order->payment?->method?->label() }}</span>
                </div>
                <div style="margin-top:.35rem"><span class="badge" id="pay-status">{{ $order->payment?->status?->label() }}</span></div>
            </div>
        </div>

        @if($order->payment?->method?->value === 'CASH')
            <div class="money-alert" style="margin-top:1rem">
                Receber: {{ \App\Support\Money::format((int)$order->payment->amount_received) }}<br>
                Troco: {{ \App\Support\Money::format((int)$order->payment->change_amount) }}
            </div>
        @elseif(in_array($order->payment?->method?->value, ['PIX','CREDIT_CARD','DEBIT_CARD'], true))
            <div class="pay-alert" id="await-pay-note" style="margin-top:1rem">
                Após pagar, aguarde o atendente confirmar. Não há confirmação automática nesta versão.
            </div>
        @endif

        <h3 style="margin:1.25rem 0 .5rem">Acompanhamento</h3>
        @php
            $status = $order->status->value;
            $pay = $order->payment?->status?->value;
            $steps = [
                ['key' => 'RECEIVED', 'label' => 'Pedido recebido'],
                ['key' => 'PAID', 'label' => 'Pagamento confirmado'],
                ['key' => 'PREPARING', 'label' => 'Preparando'],
                ['key' => 'READY', 'label' => 'Pronto'],
                ['key' => 'DELIVERED', 'label' => 'Entregue'],
            ];
        @endphp
        <div class="timeline" id="timeline">
            @foreach($steps as $step)
                <div class="tl-item" data-step="{{ $step['key'] }}">
                    <div class="tl-dot"><x-icon name="circle" size="sm" /></div>
                    <div><strong>{{ $step['label'] }}</strong></div>
                </div>
            @endforeach
        </div>
        <div class="muted" style="margin-top:1rem">Status do pedido: <strong id="order-status">{{ $order->status->label() }}</strong></div>

        <h3 style="margin-top:1.25rem">Itens</h3>
        @foreach($order->items as $item)
            <div style="display:flex;justify-content:space-between;padding:.3rem 0;border-bottom:1px solid var(--border)">
                <span>{{ $item->quantity }}× {{ $item->product_name_snapshot }}</span>
                <span>{{ $item->formattedSubtotal() }}</span>
            </div>
        @endforeach
    </div>
    <a class="btn btn-block btn-secondary icon-inline" style="margin-top:1rem;gap:.45rem" href="{{ $order->table ? route('menu.table', $order->table->number) : route('menu.index') }}">
        <x-icon name="arrow-left" size="sm" />
        <span>Voltar ao cardápio</span>
    </a>
</main>
<script>
(function(){
  const url = @json(route('menu.order.json', $order->order_number));
  const method = document.body.dataset.payMethod || '';

  function compute(status, pay) {
    const paid = pay === 'PAID' || method === 'CASH';
    const done = {
      RECEIVED: true,
      PAID: paid,
      PREPARING: ['PREPARING','READY','DELIVERED','COMPLETED','CONFIRMED'].includes(status) || (paid && status !== 'PENDING' && status !== 'CANCELLED'),
      READY: ['READY','DELIVERED','COMPLETED'].includes(status),
      DELIVERED: ['DELIVERED','COMPLETED'].includes(status),
    };
    // CONFIRMED counts toward preparing pipeline visually
    if (status === 'CONFIRMED') done.PREPARING = true;
    if (status === 'PENDING' && paid) done.PAID = true;

    let current = 'RECEIVED';
    if (status === 'CANCELLED') current = 'CANCELLED';
    else if (done.DELIVERED) current = 'DELIVERED';
    else if (done.READY) current = 'READY';
    else if (done.PREPARING) current = 'PREPARING';
    else if (done.PAID) current = 'PAID';
    return { done, current };
  }

  function paint(status, statusLabel, pay, payLabel) {
    document.getElementById('order-status').textContent = statusLabel || status;
    document.getElementById('pay-status').textContent = payLabel || pay || '';
    const note = document.getElementById('await-pay-note');
    if (note && pay === 'PAID') note.style.display = 'none';

    const { done, current } = compute(status, pay);
    document.querySelectorAll('#timeline .tl-item').forEach((el) => {
      const key = el.getAttribute('data-step');
      el.classList.toggle('done', !!done[key]);
      el.classList.toggle('current', current === key);
      const dot = el.querySelector('.tl-dot');
      if (dot) {
        // keep simple check mark via CSS class; text fallback
        dot.innerHTML = done[key]
          ? '<svg class="ui-icon ui-icon-sm" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>'
          : '<svg class="ui-icon ui-icon-sm" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/></svg>';
      }
    });
    document.body.dataset.orderStatus = status;
    document.body.dataset.payStatus = pay || '';
  }

  // initial paint from server state
  paint(
    document.body.dataset.orderStatus,
    document.getElementById('order-status').textContent,
    document.body.dataset.payStatus,
    document.getElementById('pay-status').textContent
  );

  async function tick(){
    try {
      const r = await fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' });
      if (!r.ok) return;
      const d = await r.json();
      // DOM-only update — never reload the document
      paint(d.status, d.status_label, d.payment_status, d.payment_status_label);
    } catch (e) {}
  }
  setInterval(tick, 4000);
})();
</script>
</body>
</html>
