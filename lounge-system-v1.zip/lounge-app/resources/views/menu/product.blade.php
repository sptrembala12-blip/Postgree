<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>{{ $product->name }}</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
</head>
<body class="menu-body">
<header class="menu-top">
    <a class="btn btn-ghost btn-sm icon-inline" href="{{ $table ? route('menu.table', $table->number) : route('menu.index') }}">
        <x-icon name="arrow-left" size="sm" />
        <span>Voltar</span>
    </a>
    <a class="btn btn-sm icon-inline" href="{{ route('menu.cart') }}">
        <x-icon name="shopping-cart" size="sm" />
        <span>{{ $summary['items_count'] }}</span>
    </a>
</header>

@if($errors->any())<div class="container flash flash-err">{{ $errors->first() }}</div>@endif

<main class="hero-product container">
    @if($product->primaryImage)
        <img class="cover" src="{{ asset('storage/'.$product->primaryImage->path) }}" alt="">
    @else
        <div class="cover-icon"><x-icon name="package" size="xl" /></div>
    @endif
    <h1 style="margin:1rem 0 .35rem;font-size:1.5rem">{{ $product->name }}</h1>
    <div class="price" style="font-size:1.35rem">{{ $product->formattedPrice() }}</div>
    <p class="muted" style="margin-top:.75rem">{{ $product->description }}</p>
    @if(!$product->isAvailableForSale())
        <div class="flash flash-err icon-inline"><x-icon name="circle-alert" size="sm" /> <span>Produto indisponível no momento.</span></div>
    @endif

    <form method="POST" action="{{ route('menu.cart.add') }}" class="card" style="margin-top:1.25rem">
        @csrf
        <input type="hidden" name="product_id" value="{{ $product->id }}">
        @if($table)<input type="hidden" name="table_id" value="{{ $table->id }}">@endif
        <label>Quantidade</label>
        <div class="qty-ctrl" style="margin-bottom:1rem">
            <button type="button" aria-label="Diminuir" onclick="const i=this.parentNode.querySelector('input'); i.value=Math.max(1,+i.value-1)"><x-icon name="minus" size="sm" /></button>
            <input type="number" name="quantity" value="1" min="1" max="99" style="width:56px;text-align:center;margin:0;border:0;background:transparent">
            <button type="button" aria-label="Aumentar" onclick="const i=this.parentNode.querySelector('input'); i.value=Math.min(99,+i.value+1)"><x-icon name="plus" size="sm" /></button>
        </div>
        <button class="btn btn-block btn-lg icon-inline" type="submit" @disabled(!$product->isAvailableForSale()) style="gap:.5rem">
            <x-icon name="shopping-bag" size="sm" />
            <span>Adicionar ao carrinho</span>
        </button>
        <button class="btn btn-block btn-secondary" style="margin-top:.5rem" name="go_cart" value="1" type="submit" @disabled(!$product->isAvailableForSale())>Adicionar e ver carrinho</button>
    </form>
</main>
</body>
</html>
