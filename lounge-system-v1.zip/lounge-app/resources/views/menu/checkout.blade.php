<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Checkout</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
</head>
<body class="menu-body" style="padding-bottom:2rem">
<header class="menu-top">
    <a class="btn btn-ghost btn-sm icon-inline" href="{{ route('menu.cart') }}">
        <x-icon name="arrow-left" size="sm" />
        <span>Carrinho</span>
    </a>
    <strong>Finalizar</strong>
</header>
@if($errors->any())
    <div class="container flash flash-err">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>
@endif

<main class="container" style="padding:1rem">
    <div class="card" style="margin-bottom:1rem">
        <div class="muted">Mesa</div>
        <strong>{{ $table?->number ? 'Mesa '.$table->number : 'Selecione abaixo' }}</strong>
        <div style="margin-top:.75rem">
            @foreach($summary['items'] as $item)
                <div style="display:flex;justify-content:space-between;padding:.35rem 0;border-bottom:1px solid var(--border)">
                    <span>{{ $item['quantity'] }}× {{ $item['name'] }}</span>
                    <span>{{ $item['subtotal_formatted'] }}</span>
                </div>
            @endforeach
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:.85rem;font-size:1.15rem">
            <strong>Total</strong>
            <strong class="price" id="total" data-cents="{{ $summary['total'] }}">{{ $summary['total_formatted'] }}</strong>
        </div>
    </div>

    <form method="POST" action="{{ route('menu.checkout.submit') }}" class="card">
        @csrf
        @if(!$table)
            <label>Mesa</label>
            <select name="table_id">
                <option value="">—</option>
                @foreach($tables as $t)
                    <option value="{{ $t->id }}" @selected(old('table_id', $cart->table_id)==$t->id)>Mesa {{ $t->number }}</option>
                @endforeach
            </select>
        @else
            <input type="hidden" name="table_id" value="{{ $table->id }}">
        @endif

        <label>Seu nome (opcional)</label>
        <input name="customer_name" value="{{ old('customer_name') }}" placeholder="Como te chamamos?">

        <label>Observações</label>
        <textarea name="notes" rows="2" placeholder="Ex: sem gelo">{{ old('notes') }}</textarea>

        <label>Forma de pagamento</label>
        <label class="pay-option">
            <input type="radio" name="payment_method" value="PIX" checked>
            <span class="icon-inline"><x-icon name="qr-code" size="sm" /> <strong>PIX</strong></span>
            <div class="muted">Confirmação manual pelo atendente</div>
        </label>
        <label class="pay-option">
            <input type="radio" name="payment_method" value="CREDIT_CARD">
            <span class="icon-inline"><x-icon name="credit-card" size="sm" /> <strong>Crédito</strong></span>
            <div class="muted">Confirmado pelo atendente na maquininha</div>
        </label>
        <label class="pay-option">
            <input type="radio" name="payment_method" value="DEBIT_CARD">
            <span class="icon-inline"><x-icon name="credit-card" size="sm" /> <strong>Débito</strong></span>
            <div class="muted">Confirmado pelo atendente na maquininha</div>
        </label>
        <label class="pay-option">
            <input type="radio" name="payment_method" value="CASH">
            <span class="icon-inline"><x-icon name="banknote" size="sm" /> <strong>Dinheiro</strong></span>
            <div class="muted">Informe se precisa de troco</div>
        </label>

        <div id="manual-note" class="card-soft" style="margin:.75rem 0">
            Após enviar o pedido, o atendente confirmará o pagamento. <strong>Não há cobrança automática nesta versão.</strong>
        </div>

        <div id="cash-box" class="cash-box hidden">
            <label style="color:#bbf7d0"><input type="checkbox" name="need_change" id="need_change" value="1"> Vai precisar de troco?</label>
            <div id="change-for" class="hidden" style="margin-top:.75rem">
                <label style="color:#bbf7d0">Troco para quanto? (ex: 100,00)</label>
                <input type="text" name="amount_received_reais" id="amount_received_reais" inputmode="decimal" placeholder="100,00" style="margin-bottom:.35rem">
                <div id="change-preview" class="muted"></div>
            </div>
        </div>

        <button class="btn btn-block btn-lg icon-inline" style="margin-top:1rem;gap:.5rem" type="submit">
            <x-icon name="check" size="sm" />
            <span>Confirmar pedido</span>
        </button>
    </form>
</main>
<script>
const radios = document.querySelectorAll('input[name=payment_method]');
const cashBox = document.getElementById('cash-box');
const manualNote = document.getElementById('manual-note');
const needChange = document.getElementById('need_change');
const changeFor = document.getElementById('change-for');
const amountEl = document.getElementById('amount_received_reais');
const totalCents = parseInt(document.getElementById('total').dataset.cents, 10);
const preview = document.getElementById('change-preview');
function parseReais(v){
  if(!v) return NaN;
  v = String(v).replace(/R\$|\s/g,'').replace(/\./g,'').replace(',', '.');
  return Math.round(parseFloat(v)*100);
}
function fmt(c){ return 'R$ ' + (c/100).toFixed(2).replace('.',','); }
function sync(){
  const method = document.querySelector('input[name=payment_method]:checked')?.value;
  const isCash = method === 'CASH';
  cashBox.classList.toggle('hidden', !isCash);
  manualNote.classList.toggle('hidden', isCash);
  changeFor.classList.toggle('hidden', !(isCash && needChange.checked));
  if(isCash && needChange.checked && amountEl.value){
    const rec = parseReais(amountEl.value);
    if(isNaN(rec)) preview.textContent = 'Valor inválido';
    else if(rec < totalCents) preview.textContent = 'Insuficiente. Total: ' + fmt(totalCents);
    else preview.innerHTML = '<strong style="color:#86efac">Troco: ' + fmt(rec - totalCents) + '</strong>';
  } else preview.textContent = '';
}
radios.forEach(r => r.addEventListener('change', sync));
needChange.addEventListener('change', sync);
amountEl.addEventListener('input', sync);
sync();
</script>
</body>
</html>
