<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Mesa {{ $table->number }}</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
</head>
<body class="att-body">
<header class="att-header">
    <a class="btn btn-ghost btn-sm icon-inline" href="{{ route('attendant.tables') }}">
        <x-icon name="arrow-left" size="sm" />
        <span>Mesas</span>
    </a>
    <strong>Mesa {{ $table->number }}</strong>
    <span class="badge badge-{{ $table->status->value }}">{{ $table->status->label() }}</span>
</header>
@if(session('success'))<div class="container flash flash-ok">{{ session('success') }}</div>@endif
@if($errors->any())<div class="container flash flash-err">{{ $errors->first() }}</div>@endif
<main class="container" style="padding:1rem">
    <div class="card" style="margin-bottom:1rem">
        <div class="muted">{{ $table->name }} · {{ $table->location }}</div>
        @if($session)
            <div class="price" style="font-size:1.8rem;margin:.5rem 0">{{ \App\Support\Money::format((int)$session->total_amount) }}</div>
            <div class="muted">Sessão #{{ $session->id }} · aberta {{ $session->opened_at?->format('d/m H:i') }}</div>
            <form method="POST" action="{{ route('attendant.tables.close', $table) }}" style="margin-top:1rem" onsubmit="return confirm('Encerrar sessão da mesa?')">
                @csrf
                <button class="btn btn-danger icon-inline" type="submit"><x-icon name="x" size="sm" /> <span>Encerrar sessão</span></button>
            </form>
        @else
            <div class="muted" style="margin:.75rem 0">Nenhuma sessão aberta.</div>
            <form method="POST" action="{{ route('attendant.tables.open', $table) }}">@csrf
                <button class="btn icon-inline" type="submit"><x-icon name="plus" size="sm" /> <span>Abrir sessão</span></button>
            </form>
        @endif
    </div>

    <h2 style="font-size:1rem">Pedidos da sessão</h2>
    @forelse($orders as $order)
        @include('attendant.partials.order-card', ['order' => $order, 'highlightPay' => false])
    @empty
        <div class="empty">Nenhum pedido nesta sessão.</div>
    @endforelse
</main>
</body>
</html>
