<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Atendente — Operação</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
    <link rel="stylesheet" href="{{ asset('css/admin-pwa.css') }}">
</head>
<body class="att-body">
<header class="att-header">
    <div>
        <strong style="font-size:1.1rem" class="icon-inline"><x-icon name="clipboard-list" size="sm" /> <span>Operação</span></strong>
        <div class="muted" style="font-size:.85rem">{{ auth()->user()->name }}</div>
    </div>
    <div style="display:flex;gap:.5rem;align-items:center">
        <span class="badge badge-danger icon-inline" id="new-count" style="gap:.35rem">
            <span class="pulse-dot"></span>
            <x-icon name="bell-ring" size="sm" />
            <span>{{ $newCount }} novos</span>
        </span>
        <a class="btn btn-secondary btn-sm icon-inline" href="{{ route('attendant.tables') }}"><x-icon name="table" size="sm" /> <span>Mesas</span></a>
        @if(auth()->user()->isAdmin() || auth()->user()->hasPermission('dashboard.view'))
            <a class="btn btn-ghost btn-sm icon-inline" href="{{ route('admin.dashboard') }}"><x-icon name="layout-dashboard" size="sm" /> <span>Admin</span></a>
        @endif
        <form method="POST" action="{{ route('attendant.logout') }}">@csrf
            <button class="btn btn-ghost btn-sm icon-inline" type="submit" aria-label="Sair"><x-icon name="log-out" size="sm" /></button>
        </form>
    </div>
</header>

@if(session('success'))<div class="container flash flash-ok icon-inline" style="gap:.4rem"><x-icon name="circle-check" size="sm" /> <span>{{ session('success') }}</span></div>@endif
@if($errors->any())<div class="container flash flash-err icon-inline" style="gap:.4rem"><x-icon name="circle-alert" size="sm" /> <span>{{ $errors->first() }}</span></div>@endif

@if($awaitingPayment->isNotEmpty())
<section class="container" style="padding:1rem 1rem 0" id="awaiting-section">
    <h2 style="margin:0 0 .65rem;font-size:1rem;color:var(--accent)" class="icon-inline">
        <x-icon name="clock" size="sm" />
        <span>Aguardando confirmação de pagamento</span>
    </h2>
    <div class="grid grid-2" data-awaiting-cards>
        @foreach($awaitingPayment as $order)
            @include('attendant.partials.order-card', ['order' => $order, 'highlightPay' => true])
        @endforeach
    </div>
</section>
@endif

<div class="att-cols" id="board">
    @foreach([
        'PENDING' => ['Novos', 'bell'],
        'CONFIRMED' => ['Confirmados', 'circle-check'],
        'PREPARING' => ['Preparando', 'chef-hat'],
        'READY' => ['Prontos', 'package-check'],
        'DELIVERED' => ['Entregues', 'utensils'],
    ] as $key => $meta)
        <div class="att-col" data-col="{{ $key }}">
            <h3 class="icon-inline" style="gap:.35rem">
                <x-icon :name="$meta[1]" size="sm" />
                <span>{{ $meta[0] }} ({{ $byStatus[$key]->count() }})</span>
            </h3>
            <div data-cards>
                @forelse($byStatus[$key] as $order)
                    @include('attendant.partials.order-card', ['order' => $order, 'highlightPay' => false])
                @empty
                    <div class="empty" style="padding:1rem .5rem">Nenhum</div>
                @endforelse
            </div>
        </div>
    @endforeach
</div>

<audio id="alert-sound" preload="auto">
    <source src="data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2teleQwAQp3a1r+GGQ1FotnUv4UZDUWi2dS/hRkNRaLZ1L+FGQ1FotnUv4UZDUWi2dS/hRkNRaLZ1L+FGQ1FotnUv4UZDUWi2dS/hRkNRaLZ1L+FGQ1FotnUv4UZDUWi2dS/hRkNRaLZ1L+FGQ1FotnUv4UZDUWi2dS/hRkNRaLZ1L+FGQ1FotnUv4UZDUWi2dS/hRkN" type="audio/wav">
</audio>
<script>
window.LOUNGE_ATTENDANT = {
  lastOrderId: {{ (int) (\App\Models\Order::max('id') ?? 0) }},
  sseUrl: @json(url('/attendant/realtime/orders-stream')),
  pollUrl: @json(url('/api/v1/admin/realtime/orders')),
  actionBase: @json(url('/attendant/orders')) + '/',
};
</script>
<script src="{{ asset('js/attendant-board.js') }}" defer></script>
</body>
</html>
