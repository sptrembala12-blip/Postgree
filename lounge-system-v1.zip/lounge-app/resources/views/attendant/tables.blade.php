<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Mesas — Atendente</title>
    <link rel="stylesheet" href="{{ asset('css/lounge.css') }}">
</head>
<body class="att-body">
<header class="att-header">
    <a class="btn btn-ghost btn-sm icon-inline" href="{{ route('attendant.dashboard') }}">
        <x-icon name="arrow-left" size="sm" />
        <span>Pedidos</span>
    </a>
    <strong class="icon-inline"><x-icon name="table" size="sm" /> <span>Mesas</span></strong>
    <span></span>
</header>
<main class="container" style="padding:1rem">
    <div class="grid grid-3">
        @foreach($tables as $table)
            @php $session = $table->currentSession; @endphp
            <a class="table-tile {{ $table->status->value }}" href="{{ route('attendant.tables.show', $table) }}" style="color:inherit">
                <div style="display:flex;justify-content:space-between;gap:.5rem">
                    <strong>Mesa {{ $table->number }}</strong>
                    <span class="badge badge-{{ $table->status->value }}">{{ $table->status->label() }}</span>
                </div>
                <div class="muted" style="margin-top:.35rem">{{ $table->name }} · {{ $table->capacity }} lugares</div>
                @if($session)
                    <div class="price" style="margin-top:.75rem;font-size:1.2rem">{{ \App\Support\Money::format((int)$session->total_amount) }}</div>
                    <div class="muted">Sessão aberta {{ $session->opened_at?->format('H:i') }}</div>
                @else
                    <div class="muted" style="margin-top:.75rem">Sem consumo</div>
                @endif
            </a>
        @endforeach
    </div>
</main>
</body>
</html>
