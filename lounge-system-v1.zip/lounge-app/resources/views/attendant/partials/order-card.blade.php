@php
  $pay = $order->payment;
  $method = $pay?->method?->value;
  $payStatus = $pay?->status?->value;
  $methodIcon = $method === 'CASH' ? 'banknote' : ($method === 'PIX' ? 'qr-code' : 'credit-card');
@endphp
<div class="order-card {{ $order->status->value === 'PENDING' ? 'new' : '' }}">
    <div class="title">
        <div>
            {{ $order->displayNumber() }}
            <div class="muted" style="font-weight:600">Mesa {{ $order->table?->number ?? '—' }} · {{ $order->created_at?->format('H:i') }}</div>
        </div>
        <span class="badge badge-{{ $order->status->value }}">{{ $order->status->label() }}</span>
    </div>
    <div class="items">
        @foreach($order->items as $item)
            <div>{{ $item->quantity }}× {{ $item->product_name_snapshot }}</div>
        @endforeach
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;gap:.5rem">
        <strong class="price">{{ $order->formattedTotal() }}</strong>
        <span class="badge badge-{{ $method === 'CASH' ? 'CASH' : ($method === 'PIX' ? 'PIX' : 'CARD') }} icon-inline" style="gap:.3rem">
            <x-icon :name="$methodIcon" size="sm" />
            <span>{{ $pay?->method?->label() }}</span>
        </span>
    </div>

    @if($method === 'CASH')
        <div class="money-alert">
            DINHEIRO<br>
            Receber: {{ \App\Support\Money::format((int)$pay->amount_received) }}<br>
            TROCO: {{ \App\Support\Money::format((int)$pay->change_amount) }}
        </div>
    @elseif($payStatus === 'AWAITING_CONFIRMATION')
        <div class="pay-alert icon-inline" style="gap:.35rem">
            <x-icon name="clock" size="sm" />
            <span>{{ $pay?->method?->label() }} — AGUARDANDO CONFIRMAÇÃO</span>
        </div>
    @elseif($payStatus === 'PAID')
        <div class="muted icon-inline" style="margin:.4rem 0;gap:.3rem">
            <x-icon name="circle-check" size="sm" />
            <span>Pagamento confirmado</span>
        </div>
    @endif

    <div class="actions">
        @if($payStatus === 'AWAITING_CONFIRMATION')
            <form method="POST" action="{{ route('attendant.orders.action', [$order, 'confirm-payment']) }}">@csrf
                <button class="btn btn-info btn-sm icon-inline" type="submit"><x-icon name="circle-check" size="sm" /> <span>Confirmar pagamento</span></button>
            </form>
        @endif
        @if($order->status->value === 'PENDING')
            <form method="POST" action="{{ route('attendant.orders.action', [$order, 'confirm']) }}">@csrf
                <button class="btn btn-sm icon-inline" type="submit"><x-icon name="check" size="sm" /> <span>Confirmar pedido</span></button>
            </form>
        @endif
        @if($order->status->value === 'CONFIRMED')
            <form method="POST" action="{{ route('attendant.orders.action', [$order, 'prepare']) }}">@csrf
                <button class="btn btn-sm icon-inline" type="submit"><x-icon name="chef-hat" size="sm" /> <span>Preparar</span></button>
            </form>
        @endif
        @if($order->status->value === 'PREPARING')
            <form method="POST" action="{{ route('attendant.orders.action', [$order, 'ready']) }}">@csrf
                <button class="btn btn-ok btn-sm icon-inline" type="submit"><x-icon name="package-check" size="sm" /> <span>Pronto</span></button>
            </form>
        @endif
        @if($order->status->value === 'READY')
            <form method="POST" action="{{ route('attendant.orders.action', [$order, 'deliver']) }}">@csrf
                <button class="btn btn-sm icon-inline" type="submit"><x-icon name="utensils" size="sm" /> <span>Entregar</span></button>
            </form>
        @endif
        @if($order->status->value === 'DELIVERED')
            <form method="POST" action="{{ route('attendant.orders.action', [$order, 'complete']) }}">@csrf
                <button class="btn btn-ok btn-sm icon-inline" type="submit"><x-icon name="circle-check" size="sm" /> <span>Finalizar</span></button>
            </form>
        @endif
        @if(!in_array($order->status->value, ['COMPLETED','CANCELLED'], true))
            <form method="POST" action="{{ route('attendant.orders.action', [$order, 'cancel']) }}" onsubmit="return confirm('Cancelar pedido?')">@csrf
                <button class="btn btn-danger btn-sm icon-inline" type="submit"><x-icon name="x" size="sm" /> <span>Cancelar</span></button>
            </form>
        @endif
    </div>
</div>
