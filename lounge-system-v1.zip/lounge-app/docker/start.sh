#!/usr/bin/env bash
set -euo pipefail

cd /var/www/html

php artisan storage:link 2>/dev/null || true

# If Render injects DATABASE_URL, map to Laravel when DB_HOST is empty
if [ -n "${DATABASE_URL:-}" ] && [ -z "${DB_HOST:-}" ]; then
  export DB_CONNECTION="${DB_CONNECTION:-pgsql}"
fi

if [ -n "${APP_KEY:-}" ] && [ "${APP_ENV:-local}" = "production" ]; then
  php artisan config:cache || true
  php artisan route:cache || true
  php artisan view:cache || true
fi

if [ "${RUN_MIGRATIONS:-false}" = "true" ]; then
  php artisan migrate --force --no-interaction
fi

PORT="${PORT:-10000}"
exec php artisan serve --host=0.0.0.0 --port="${PORT}"
