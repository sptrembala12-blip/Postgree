<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Models\Category;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use App\Services\Cash\CashService;
use App\Services\Orders\OrderService;
use App\Support\Money;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class OrderFlowTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private Product $product;

    private Table $table;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);

        $this->admin = User::factory()->create();
        $this->admin->assignRole('admin');

        $category = Category::factory()->create(['name' => 'Cervejas']);
        $this->product = Product::factory()->create([
            'category_id' => $category->id,
            'name' => 'Balde Heineken',
            'price' => 5800,
            'current_stock' => 20,
            'minimum_stock' => 5,
            'stock_control_enabled' => true,
            'is_active' => true,
        ]);
        $this->table = Table::factory()->create(['number' => '08', 'name' => 'Mesa 08']);
    }

    public function test_order_total_is_calculated_from_backend_price(): void
    {
        $order = app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'PIX',
            'items' => [
                // Client tries to send fake price — ignored because service only uses product_id/qty
                ['product_id' => $this->product->id, 'quantity' => 1],
            ],
        ], $this->admin);

        $this->assertSame(5800, $order->total);
        $this->assertSame(5800, $order->items->first()->unit_price);
        $this->assertSame('Balde Heineken', $order->items->first()->product_name_snapshot);
    }

    public function test_cash_payment_change_forty_two_reais(): void
    {
        $order = app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'CASH',
            'amount_received' => 10000,
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);

        $this->assertSame(5800, $order->total);
        $this->assertSame(10000, $order->payment->amount_received);
        $this->assertSame(4200, $order->payment->change_amount);
        $this->assertSame(PaymentStatus::Paid, $order->payment->status);
        $this->assertSame('R$ 42,00', Money::format((int) $order->payment->change_amount));
    }

    public function test_cash_payment_rejects_insufficient_received(): void
    {
        $this->expectException(\InvalidArgumentException::class);

        app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'CASH',
            'amount_received' => 5000,
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);
    }

    public function test_pix_and_card_await_confirmation(): void
    {
        $pix = app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'PIX',
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);
        $this->assertSame(PaymentStatus::AwaitingConfirmation, $pix->payment->status);

        $card = app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'CREDIT_CARD',
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);
        $this->assertSame(PaymentStatus::AwaitingConfirmation, $card->payment->status);
    }

    public function test_stock_deducted_on_confirm_and_restored_on_cancel(): void
    {
        $order = app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'CASH',
            'amount_received' => 5800,
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);

        $this->assertSame(20, $this->product->fresh()->current_stock);

        $order = app(OrderService::class)->confirm($order, $this->admin);
        $this->assertSame(19, $this->product->fresh()->current_stock);
        $this->assertTrue($order->stock_deducted);

        $order = app(OrderService::class)->cancel($order, $this->admin, 'teste');
        $this->assertSame(20, $this->product->fresh()->current_stock);
        $this->assertSame(OrderStatus::Cancelled, $order->status);
    }

    public function test_insufficient_stock_is_rejected(): void
    {
        $this->product->update(['current_stock' => 0]);

        $this->expectException(\RuntimeException::class);

        app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'PIX',
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);
    }

    public function test_invalid_status_transition_blocked(): void
    {
        $order = app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'PIX',
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);

        $order = app(OrderService::class)->confirm($order, $this->admin);
        $order = app(OrderService::class)->startPreparing($order, $this->admin);
        $order = app(OrderService::class)->markReady($order, $this->admin);
        $order = app(OrderService::class)->markDelivered($order, $this->admin);
        $order = app(OrderService::class)->complete($order, $this->admin);

        $this->expectException(\RuntimeException::class);
        app(OrderService::class)->startPreparing($order, $this->admin);
    }

    public function test_full_happy_path_via_api(): void
    {
        Sanctum::actingAs($this->admin);
        app(CashService::class)->open(0, $this->admin);

        $create = $this->postJson('/api/v1/customer/orders', [
            'table_id' => $this->table->id,
            'payment_method' => 'CASH',
            'amount_received' => 10000,
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ])->assertCreated();

        $orderId = $create->json('data.id');
        $this->assertSame(4200, $create->json('data.payment.change_amount'));

        $this->postJson("/api/v1/admin/orders/{$orderId}/confirm")->assertOk();
        $this->assertSame(19, $this->product->fresh()->current_stock);

        $this->postJson("/api/v1/admin/orders/{$orderId}/prepare")->assertOk();
        $this->postJson("/api/v1/admin/orders/{$orderId}/ready")->assertOk();
        $this->postJson("/api/v1/admin/orders/{$orderId}/deliver")->assertOk();
        $this->postJson("/api/v1/admin/orders/{$orderId}/complete")->assertOk()
            ->assertJsonPath('data.status', 'COMPLETED');

        $this->getJson('/api/v1/admin/dashboard')->assertOk()
            ->assertJsonPath('data.revenue', 5800);

        $this->getJson('/api/v1/admin/reports/products')->assertOk();
        $this->getJson('/api/v1/admin/reports/payments')->assertOk()
            ->assertJsonPath('data.methods.CASH.total', 5800);

        $this->assertDatabaseHas('audit_logs', ['action' => 'ORDER_CREATED']);
        $this->assertDatabaseHas('inventory_movements', [
            'product_id' => $this->product->id,
            'type' => 'SALE',
            'quantity' => -1,
        ]);
    }

    public function test_price_change_does_not_affect_old_orders(): void
    {
        $order = app(OrderService::class)->create([
            'table_id' => $this->table->id,
            'payment_method' => 'PIX',
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ], $this->admin);

        $this->product->update(['price' => 9900]);

        $order->refresh()->load('items');
        $this->assertSame(5800, $order->items->first()->unit_price);
        $this->assertSame(5800, $order->total);
    }
}
