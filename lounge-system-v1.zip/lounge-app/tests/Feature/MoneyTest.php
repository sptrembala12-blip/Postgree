<?php

namespace Tests\Feature;

use App\Support\Money;
use InvalidArgumentException;
use Tests\TestCase;

class MoneyTest extends TestCase
{
    public function test_formats_cents_as_reais(): void
    {
        $this->assertSame('R$ 58,00', Money::format(5800));
        $this->assertSame('R$ 100,00', Money::format(10000));
        $this->assertSame('-R$ 20,00', Money::format(-2000));
        $this->assertSame('R$ 0,01', Money::format(1));
        $this->assertSame('R$ 999.999,99', Money::format(99999999));
    }

    public function test_change_calculation_success(): void
    {
        $result = Money::calculateChange(5800, 10000);

        $this->assertSame(5800, $result['amount']);
        $this->assertSame(10000, $result['amount_received']);
        $this->assertSame(4200, $result['change_amount']);
    }

    public function test_exact_cash_zero_change(): void
    {
        $result = Money::calculateChange(5800, 5800);
        $this->assertSame(0, $result['change_amount']);
    }

    public function test_change_rejects_insufficient_amount(): void
    {
        $this->expectException(InvalidArgumentException::class);
        Money::calculateChange(5800, 5000);
    }

    public function test_change_rejects_zero_order(): void
    {
        $this->expectException(InvalidArgumentException::class);
        Money::calculateChange(0, 100);
    }

    public function test_change_rejects_negative(): void
    {
        $this->expectException(InvalidArgumentException::class);
        Money::calculateChange(5800, -1);
    }

    public function test_multiply_and_add(): void
    {
        $this->assertSame(11600, Money::multiply(5800, 2));
        $this->assertSame(15000, Money::add(10000, 5000));
        $this->assertSame('58.00', Money::toDecimalString(5800));
    }

    public function test_of_reais_parses_brazilian_format_without_float_path(): void
    {
        $this->assertSame(5800, Money::ofReais('58,00'));
        $this->assertSame(5800, Money::ofReais('R$ 58,00'));
        $this->assertSame(123456, Money::ofReais('1.234,56'));
        $this->assertSame(1, Money::ofReais('0,01'));
        $this->assertSame(99999999, Money::ofReais('999999,99'));
    }
}
