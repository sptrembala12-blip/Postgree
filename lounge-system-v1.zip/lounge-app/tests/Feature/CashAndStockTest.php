<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use App\Services\Cash\CashService;
use App\Services\Inventory\InventoryService;
use App\Services\Orders\OrderService;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CashAndStockTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
    }

    public function test_stock_purchase_and_loss(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'current_stock' => 10,
            'stock_control_enabled' => true,
        ]);

        $inv = app(InventoryService::class);
        $inv->purchase($product, 50, 'Compra', $admin);
        $this->assertSame(60, $product->fresh()->current_stock);

        $inv->loss($product, 5, 'Quebra', $admin);
        $this->assertSame(55, $product->fresh()->current_stock);

        $this->assertDatabaseHas('audit_logs', ['action' => 'STOCK_ADJUSTED']);
    }

    public function test_cash_register_open_close_with_difference(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $cash = app(CashService::class);

        $register = $cash->open(10000, $admin);
        $this->assertTrue($register->isOpen());

        $cat = Category::factory()->create();
        $product = Product::factory()->create([
            'category_id' => $cat->id,
            'price' => 5800,
            'current_stock' => 10,
            'stock_control_enabled' => true,
        ]);

        app(OrderService::class)->create([
            'payment_method' => 'CASH',
            'amount_received' => 5800,
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ], $admin);

        $closed = $cash->close(15600, $admin); // expected 10000+5800=15800, informed 15600 => -200
        $this->assertSame(15800, $closed->expected_amount);
        $this->assertSame(15600, $closed->closing_amount);
        $this->assertSame(-200, $closed->difference);
        $this->assertDatabaseHas('audit_logs', ['action' => 'CASH_REGISTER_CLOSED']);
    }

    public function test_cannot_open_two_registers(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $cash = app(CashService::class);
        $cash->open(0, $admin);

        $this->expectException(\RuntimeException::class);
        $cash->open(0, $admin);
    }
}
