<?php

namespace Tests\Feature;

use App\Enums\PaymentStatus;
use App\Models\AdminNotification;
use App\Models\Category;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use App\Services\Orders\OrderService;
use App\Services\Payments\PaymentService;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class PaymentNotificationTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private User $att;
    private Product $product;
    private Table $table;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
        $this->admin = User::factory()->create();
        $this->admin->assignRole('admin');
        $this->att = User::factory()->create();
        $this->att->assignRole('attendant');
        $this->product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'name' => 'Balde Heineken',
            'price' => 5800,
            'current_stock' => 50,
            'stock_control_enabled' => true,
            'is_active' => true,
        ]);
        $this->table = Table::factory()->create(['number' => '08']);
    }

    private function order(string $method, ?int $received = null)
    {
        $data = [
            'table_id' => $this->table->id,
            'payment_method' => $method,
            'items' => [['product_id' => $this->product->id, 'quantity' => 1]],
        ];
        if ($method === 'CASH') {
            $data['amount_received'] = $received ?? 5800;
        }
        return app(OrderService::class)->create($data, $this->admin);
    }

    public function test_pix_selection_does_not_create_payment_notification(): void
    {
        $order = $this->order('PIX');
        $this->assertSame(PaymentStatus::AwaitingConfirmation, $order->payment->status);
        $this->assertSame(0, AdminNotification::where('type', 'payment_confirmed')->count());
    }

    public function test_manual_confirm_creates_one_pix_notification(): void
    {
        $order = $this->order('PIX');
        app(PaymentService::class)->confirm($order->payment, $this->att);
        $this->assertSame(1, AdminNotification::where('type', 'payment_confirmed')->count());
        $n = AdminNotification::first();
        $this->assertSame('PIX', $n->payment_method);
        $this->assertSame(5800, $n->amount);
        $this->assertSame($order->id, $n->order_id);
        $this->assertSame('08', $n->table_number);
        $this->assertStringContainsString('PIX', $n->message);
        $this->assertStringContainsString('58,00', $n->message);

        // double confirm no duplicate
        app(PaymentService::class)->confirm($order->payment->fresh(), $this->att);
        $this->assertSame(1, AdminNotification::where('type', 'payment_confirmed')->count());
        $this->assertDatabaseHas('audit_logs', ['action' => 'PAYMENT_CONFIRMED']);
    }

    public function test_credit_debit_notifications(): void
    {
        foreach (['CREDIT_CARD' => 'crédito', 'DEBIT_CARD' => 'débito'] as $method => $label) {
            $order = $this->order($method);
            $this->assertSame(0, AdminNotification::where('payment_id', $order->payment->id)->count());
            app(PaymentService::class)->confirm($order->payment, $this->att);
            $n = AdminNotification::where('payment_id', $order->payment->id)->first();
            $this->assertNotNull($n);
            $this->assertStringContainsString($label, mb_strtolower($n->message));
        }
    }

    public function test_cash_notifies_on_create_with_change_copy(): void
    {
        $order = $this->order('CASH', 10000);
        $this->assertSame(PaymentStatus::Paid, $order->payment->status);
        $n = AdminNotification::where('payment_id', $order->payment->id)->first();
        $this->assertNotNull($n);
        $this->assertStringContainsString('dinheiro', mb_strtolower($n->message));
        $this->assertStringContainsString('100,00', $n->message);
        $this->assertStringContainsString('42,00', $n->message);
        $this->assertSame(4200, $n->change_amount);
    }

    public function test_admin_can_list_notifications_attendant_with_dashboard_cannot_if_no_perm(): void
    {
        $order = $this->order('PIX');
        app(PaymentService::class)->confirm($order->payment, $this->att);

        Sanctum::actingAs($this->admin);
        $this->getJson('/api/v1/admin/notifications')->assertOk()
            ->assertJsonPath('meta.unread', 1);

        // attendant has no reports.view — cannot access admin notifications
        Sanctum::actingAs($this->att);
        $this->getJson('/api/v1/admin/notifications')->assertForbidden();
    }

    public function test_dashboard_api_exposes_snapshots(): void
    {
        Sanctum::actingAs($this->admin);
        $this->getJson('/api/v1/admin/dashboard?period=today')->assertOk()
            ->assertJsonStructure(['data' => ['received', 'sales', 'awaiting', 'snapshots', 'series', 'top_products']]);
    }

    public function test_mark_read_and_read_all(): void
    {
        $order = $this->order('PIX');
        app(PaymentService::class)->confirm($order->payment, $this->admin);
        $n = AdminNotification::first();
        Sanctum::actingAs($this->admin);
        $this->postJson('/api/v1/admin/notifications/'.$n->id.'/read')->assertOk()
            ->assertJsonPath('data.is_read', true);
        $order2 = $this->order('CREDIT_CARD');
        app(PaymentService::class)->confirm($order2->payment, $this->admin);
        $this->postJson('/api/v1/admin/notifications/read-all')->assertOk()
            ->assertJsonPath('unread', 0);
    }
}
