<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AuthAndPermissionsTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
    }

    public function test_user_can_be_created_and_login_via_api(): void
    {
        $user = User::factory()->create([
            'email' => 'test@lounge.local',
            'password' => 'password',
        ]);
        $user->assignRole('admin');

        $response = $this->postJson('/api/v1/auth/login', [
            'email' => 'test@lounge.local',
            'password' => 'password',
        ]);

        $response->assertOk()
            ->assertJsonStructure(['token', 'user' => ['id', 'email', 'roles']]);
    }

    public function test_invalid_login_is_rejected(): void
    {
        User::factory()->create(['email' => 'x@lounge.local', 'password' => 'password']);

        $this->postJson('/api/v1/auth/login', [
            'email' => 'x@lounge.local',
            'password' => 'wrong',
        ])->assertStatus(422);
    }

    public function test_inactive_user_cannot_login(): void
    {
        $user = User::factory()->inactive()->create([
            'email' => 'off@lounge.local',
            'password' => 'password',
        ]);
        $user->assignRole('admin');

        $this->postJson('/api/v1/auth/login', [
            'email' => 'off@lounge.local',
            'password' => 'password',
        ])->assertStatus(422);
    }

    public function test_admin_has_all_permissions_attendant_is_limited(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $this->assertTrue($admin->hasPermission('users.manage'));
        $this->assertTrue($admin->isAdmin());

        $att = User::factory()->create();
        $att->assignRole('attendant');
        $this->assertTrue($att->hasPermission('orders.view'));
        $this->assertFalse($att->hasPermission('users.manage'));
    }

    public function test_admin_api_requires_auth(): void
    {
        $this->getJson('/api/v1/admin/dashboard')->assertUnauthorized();
    }
}
