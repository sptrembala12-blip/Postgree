<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use App\Services\Orders\CartService;
use App\Services\Orders\OrderService;
use App\Services\Tables\TableService;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class CartAndQrTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
    }

    public function test_cart_recalculates_price_from_backend(): void
    {
        $cat = Category::factory()->create(['is_active' => true]);
        $product = Product::factory()->create([
            'category_id' => $cat->id,
            'price' => 5800,
            'is_active' => true,
            'current_stock' => 10,
        ]);

        $carts = app(CartService::class);
        $cart = $carts->getOrCreate();
        $carts->addItem($cart, $product->id, 2);
        $summary = $carts->summarize($cart->fresh());

        $this->assertSame(11600, $summary['total']);
        $this->assertSame(5800, $summary['items'][0]['unit_price']);

        // price change while cart open
        $product->update(['price' => 7000]);
        $summary2 = $carts->summarize($cart->fresh());
        $this->assertSame(14000, $summary2['total']);
    }

    public function test_cart_rejects_inactive_and_out_of_stock(): void
    {
        $cat = Category::factory()->create();
        $inactive = Product::factory()->create([
            'category_id' => $cat->id,
            'is_active' => false,
            'current_stock' => 10,
        ]);
        $oos = Product::factory()->create([
            'category_id' => $cat->id,
            'is_active' => true,
            'current_stock' => 0,
            'stock_control_enabled' => true,
        ]);

        $carts = app(CartService::class);
        $cart = $carts->getOrCreate();

        $this->expectException(\Illuminate\Database\Eloquent\ModelNotFoundException::class);
        $carts->addItem($cart, $inactive->id, 1);
    }

    public function test_cart_out_of_stock_runtime(): void
    {
        $cat = Category::factory()->create();
        $oos = Product::factory()->create([
            'category_id' => $cat->id,
            'is_active' => true,
            'current_stock' => 0,
            'stock_control_enabled' => true,
        ]);
        $carts = app(CartService::class);
        $cart = $carts->getOrCreate();

        $this->expectException(\RuntimeException::class);
        $carts->addItem($cart, $oos->id, 1);
    }

    public function test_expired_cart_is_replaced(): void
    {
        $carts = app(CartService::class);
        $cart = $carts->getOrCreate();
        $cart->update(['expires_at' => now()->subHour()]);
        $token = $cart->token;

        $fresh = $carts->getOrCreate($token);
        $this->assertNotSame($token, $fresh->token);
        $this->assertFalse($fresh->isExpired());
    }

    public function test_qr_token_identifies_table_not_guessable_number_alone_for_token_route(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        Sanctum::actingAs($admin);

        $table = app(TableService::class)->create([
            'number' => '08',
            'name' => 'Mesa 08',
            'type' => 'TABLE',
            'capacity' => 4,
        ], $admin);

        $byToken = $this->getJson('/api/v1/public/tables/token/'.$table->qr_token)->assertOk();
        $this->assertSame('08', $byToken->json('data.number'));

        $this->getJson('/api/v1/public/tables/token/invalid-token-xyz')->assertNotFound();

        $menu = $this->get('/menu/t/'.$table->qr_token);
        $menu->assertOk();
        $menu->assertSee('Mesa 08');
    }

    public function test_order_from_cart_token_uses_live_prices(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'price' => 5800,
            'current_stock' => 10,
            'is_active' => true,
        ]);
        $table = Table::factory()->create(['number' => '01']);

        $carts = app(CartService::class);
        $cart = $carts->getOrCreate(null, $table);
        $carts->addItem($cart, $product->id, 1);

        $product->update(['price' => 6000]);

        $order = app(OrderService::class)->create([
            'table_id' => $table->id,
            'payment_method' => 'PIX',
            'cart_token' => $cart->token,
        ], $admin);

        $this->assertSame(6000, $order->total);
        $this->assertSame(6000, $order->items->first()->unit_price);
    }
}
