<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Models\Category;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use App\Services\Cash\CashService;
use App\Services\Orders\OrderService;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class ConcurrencyAndCancelTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
    }

    public function test_only_one_order_gets_last_stock_unit_under_serial_contention(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $cat = Category::factory()->create();
        $product = Product::factory()->create([
            'category_id' => $cat->id,
            'price' => 5800,
            'current_stock' => 1,
            'stock_control_enabled' => true,
            'is_active' => true,
        ]);
        $table = Table::factory()->create();
        $service = app(OrderService::class);

        $success = 0;
        $failures = 0;

        // Simulate two contending checkouts serially under lock semantics
        // (true parallel needs multi-process; lockForUpdate is covered by nested tx attempts)
        for ($i = 0; $i < 2; $i++) {
            try {
                DB::transaction(function () use ($service, $product, $table, $admin, &$success) {
                    $order = $service->create([
                        'table_id' => $table->id,
                        'payment_method' => 'PIX',
                        'items' => [['product_id' => $product->id, 'quantity' => 1]],
                    ], $admin);
                    $service->confirm($order, $admin);
                    $success++;
                });
            } catch (\Throwable) {
                $failures++;
            }
        }

        $this->assertSame(1, $success);
        $this->assertSame(1, $failures);
        $this->assertSame(0, $product->fresh()->current_stock);
    }

    public function test_cancel_pending_does_not_touch_stock(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'price' => 1000,
            'current_stock' => 5,
            'stock_control_enabled' => true,
        ]);

        $order = app(OrderService::class)->create([
            'payment_method' => 'PIX',
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ], $admin);

        app(OrderService::class)->cancel($order, $admin, 'cliente desistiu');
        $this->assertSame(5, $product->fresh()->current_stock);
        $this->assertSame(PaymentStatus::Cancelled, $order->fresh()->payment->status);
    }

    public function test_cancel_confirmed_restores_stock_with_return_movement(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'price' => 1000,
            'current_stock' => 5,
            'stock_control_enabled' => true,
        ]);

        $svc = app(OrderService::class);
        $order = $svc->create([
            'payment_method' => 'CASH',
            'amount_received' => 2000,
            'items' => [['product_id' => $product->id, 'quantity' => 2]],
        ], $admin);
        $order = $svc->confirm($order, $admin);
        $this->assertSame(3, $product->fresh()->current_stock);

        $order = $svc->cancel($order, $admin, 'erro');
        $this->assertSame(5, $product->fresh()->current_stock);
        $this->assertSame(OrderStatus::Cancelled, $order->status);
        $this->assertDatabaseHas('inventory_movements', [
            'product_id' => $product->id,
            'type' => 'RETURN',
            'quantity' => 2,
        ]);
        $this->assertSame(PaymentStatus::Refunded, $order->fresh()->payment->status);
    }

    public function test_cancel_preparing_restores_stock(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'price' => 2000,
            'current_stock' => 4,
            'stock_control_enabled' => true,
        ]);
        $svc = app(OrderService::class);
        $order = $svc->create([
            'payment_method' => 'PIX',
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ], $admin);
        $order = $svc->confirm($order, $admin);
        $order = $svc->startPreparing($order, $admin);
        $svc->cancel($order, $admin);
        $this->assertSame(4, $product->fresh()->current_stock);
    }

    public function test_completed_cannot_be_cancelled(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'price' => 2000,
            'current_stock' => 4,
            'stock_control_enabled' => true,
        ]);
        $svc = app(OrderService::class);
        $order = $svc->create([
            'payment_method' => 'PIX',
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ], $admin);
        $order = $svc->confirm($order, $admin);
        $order = $svc->startPreparing($order, $admin);
        $order = $svc->markReady($order, $admin);
        $order = $svc->markDelivered($order, $admin);
        $order = $svc->complete($order, $admin);

        $this->expectException(\RuntimeException::class);
        $svc->cancel($order, $admin);
    }

    public function test_zero_total_order_rejected(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'price' => 0,
            'current_stock' => 10,
            'stock_control_enabled' => true,
        ]);

        $this->expectException(\InvalidArgumentException::class);
        app(OrderService::class)->create([
            'payment_method' => 'PIX',
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ], $admin);
    }

    public function test_cash_refund_on_cancel_affects_drawer(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        app(CashService::class)->open(0, $admin);

        $product = Product::factory()->create([
            'category_id' => Category::factory()->create()->id,
            'price' => 5800,
            'current_stock' => 10,
            'stock_control_enabled' => true,
        ]);

        $svc = app(OrderService::class);
        $order = $svc->create([
            'payment_method' => 'CASH',
            'amount_received' => 10000,
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ], $admin);
        $svc->confirm($order, $admin);
        $svc->cancel($order->fresh(), $admin, 'estorno');

        $register = app(CashService::class)->currentOpen();
        $summary = app(CashService::class)->buildSummary($register);
        $this->assertSame(0, $summary['expected_cash']);
        $this->assertSame(5800, $summary['refunds_total']);
    }
}
