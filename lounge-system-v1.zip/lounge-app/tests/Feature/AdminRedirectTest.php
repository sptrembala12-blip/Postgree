<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminRedirectTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
    }

    public function test_guest_admin_redirects_to_login_not_500(): void
    {
        $this->get('/admin')->assertRedirect(route('admin.login'));
        $this->get('/admin/orders')->assertRedirect(route('admin.login'));
        $this->get('/admin/products')->assertRedirect(route('admin.login'));
    }

    public function test_attendant_lands_on_attendant_dashboard(): void
    {
        $user = User::factory()->create(['email' => 'a@test.com', 'password' => 'password']);
        $user->assignRole('attendant');

        $this->post('/admin/login', [
            'email' => 'a@test.com',
            'password' => 'password',
        ])->assertRedirect(route('attendant.dashboard'));
    }

    public function test_admin_dashboard_ok(): void
    {
        $user = User::factory()->create(['password' => 'password']);
        $user->assignRole('admin');
        $this->actingAs($user)->get('/admin')->assertOk();
    }
}
