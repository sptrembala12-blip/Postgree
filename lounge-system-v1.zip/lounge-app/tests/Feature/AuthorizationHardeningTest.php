<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AuthorizationHardeningTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
    }

    private function userWithRole(string $role): User
    {
        $user = User::factory()->create();
        $user->assignRole($role);

        return $user;
    }

    public function test_attendant_cannot_manage_users_via_api(): void
    {
        Sanctum::actingAs($this->userWithRole('attendant'));

        $this->getJson('/api/v1/admin/users')->assertForbidden();
        $this->postJson('/api/v1/admin/users', [
            'name' => 'Hack',
            'email' => 'hack@test.com',
            'password' => 'password123',
            'role' => 'admin',
        ])->assertForbidden();
    }

    public function test_attendant_cannot_access_reports_or_settings_or_audit(): void
    {
        Sanctum::actingAs($this->userWithRole('attendant'));

        $this->getJson('/api/v1/admin/reports/payments')->assertForbidden();
        $this->getJson('/api/v1/admin/audit-logs')->assertForbidden();
    }

    public function test_attendant_cannot_manage_stock_or_products(): void
    {
        Sanctum::actingAs($this->userWithRole('attendant'));
        $cat = Category::factory()->create();
        $product = Product::factory()->create(['category_id' => $cat->id, 'current_stock' => 10]);

        $this->postJson('/api/v1/admin/products', [
            'category_id' => $cat->id,
            'name' => 'X',
            'price' => 100,
        ])->assertForbidden();

        $this->postJson('/api/v1/admin/stock/movements', [
            'product_id' => $product->id,
            'type' => 'PURCHASE',
            'quantity' => 5,
        ])->assertForbidden();
    }

    public function test_attendant_can_view_orders_but_stock_manager_cannot_manage_orders(): void
    {
        Sanctum::actingAs($this->userWithRole('attendant'));
        $this->getJson('/api/v1/admin/orders')->assertOk();

        Sanctum::actingAs($this->userWithRole('stock_manager'));
        $this->getJson('/api/v1/admin/orders')->assertForbidden();
        $this->getJson('/api/v1/admin/stock')->assertOk();
    }

    public function test_cashier_can_manage_cash_not_users(): void
    {
        Sanctum::actingAs($this->userWithRole('cashier'));
        $this->getJson('/api/v1/admin/cash/current')->assertOk();
        $this->postJson('/api/v1/admin/cash/open', ['opening_amount' => 0])->assertCreated();
        $this->getJson('/api/v1/admin/users')->assertForbidden();
        $this->getJson('/api/v1/admin/reports/products')->assertForbidden();
    }

    public function test_manager_can_see_reports_not_users(): void
    {
        Sanctum::actingAs($this->userWithRole('manager'));
        $this->getJson('/api/v1/admin/reports/payments')->assertOk();
        $this->getJson('/api/v1/admin/users')->assertForbidden();
        $this->getJson('/api/v1/admin/audit-logs')->assertOk();
    }

    public function test_web_admin_users_page_forbidden_for_attendant(): void
    {
        $att = $this->userWithRole('attendant');
        $this->actingAs($att)->get('/admin/users')->assertForbidden();
        $this->actingAs($att)->get('/admin/reports')->assertForbidden();
        $this->actingAs($att)->get('/admin/settings')->assertForbidden();
        $this->actingAs($att)->get('/admin/orders')->assertOk();
    }

    public function test_login_does_not_expose_password(): void
    {
        $user = $this->userWithRole('admin');
        $user->email = 'safe@test.com';
        $user->password = 'password';
        $user->save();

        $res = $this->postJson('/api/v1/auth/login', [
            'email' => 'safe@test.com',
            'password' => 'password',
        ])->assertOk();

        $this->assertArrayNotHasKey('password', $res->json('user'));
        $this->assertStringNotContainsString('password', strtolower(json_encode($res->json('user'))));
    }
}
