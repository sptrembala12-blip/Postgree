<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use Database\Seeders\RolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class CatalogTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesAndPermissionsSeeder::class);
    }

    public function test_admin_can_create_category_and_product(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        Sanctum::actingAs($admin);

        $cat = $this->postJson('/api/v1/admin/categories', [
            'name' => 'Cervejas Teste',
            'is_active' => true,
        ])->assertCreated()->json('data');

        $product = $this->postJson('/api/v1/admin/products', [
            'category_id' => $cat['id'],
            'name' => 'Balde Heineken Test',
            'price' => 5800,
            'current_stock' => 20,
            'minimum_stock' => 5,
            'stock_control_enabled' => true,
            'is_active' => true,
        ])->assertCreated()->json('data');

        $this->assertSame(5800, $product['price']);
        $this->assertDatabaseHas('products', ['name' => 'Balde Heineken Test', 'price' => 5800]);
    }

    public function test_admin_can_create_table(): void
    {
        $admin = User::factory()->create();
        $admin->assignRole('admin');
        Sanctum::actingAs($admin);

        $this->postJson('/api/v1/admin/tables', [
            'number' => '08',
            'name' => 'Mesa 08',
            'type' => 'TABLE',
            'capacity' => 4,
        ])->assertCreated()
            ->assertJsonPath('data.number', '08');

        $this->assertDatabaseHas('tables', ['number' => '08']);
        $table = Table::where('number', '08')->first();
        $this->assertNotEmpty($table->qr_token);
        $this->assertNotEmpty($table->qr_code_path);
    }

    public function test_public_menu_hides_inactive_products(): void
    {
        $cat = Category::factory()->create(['is_active' => true]);
        Product::factory()->create(['category_id' => $cat->id, 'is_active' => true, 'name' => 'Ativo']);
        Product::factory()->create(['category_id' => $cat->id, 'is_active' => false, 'name' => 'Inativo']);

        $response = $this->getJson('/api/v1/public/menu')->assertOk();
        $names = collect($response->json('categories'))->flatMap(fn ($c) => collect($c['products'])->pluck('name'));

        $this->assertTrue($names->contains('Ativo'));
        $this->assertFalse($names->contains('Inativo'));
    }
}
