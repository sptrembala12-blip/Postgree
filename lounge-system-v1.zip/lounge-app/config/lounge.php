<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Business timezone
    |--------------------------------------------------------------------------
    | Used for "today", dashboards and period filters. Mirrors app.timezone.
    */
    'timezone' => env('APP_TIMEZONE', 'America/Sao_Paulo'),

    /*
    |--------------------------------------------------------------------------
    | Allow negative stock
    |--------------------------------------------------------------------------
    | When false, sales that would drive stock below zero are rejected.
    */
    'allow_negative_stock' => env('ALLOW_NEGATIVE_STOCK', false),

    /*
    |--------------------------------------------------------------------------
    | When stock is deducted
    |--------------------------------------------------------------------------
    | confirmed = on order confirmation (default)
    | completed = only when order is completed
    */
    'stock_deduction_on' => env('STOCK_DEDUCTION_ON', 'confirmed'),

    /*
    |--------------------------------------------------------------------------
    | Payment gateway driver
    |--------------------------------------------------------------------------
    | manual = local/test mode (no external charge)
    */
    'payment_gateway' => env('PAYMENT_GATEWAY', 'manual'),

    /*
    |--------------------------------------------------------------------------
    | QR / Menu
    |--------------------------------------------------------------------------
    */
    'menu_path_prefix' => '/menu/table',

    /*
    |--------------------------------------------------------------------------
    | Order number sequence start
    |--------------------------------------------------------------------------
    */
    'order_number_start' => (int) env('ORDER_NUMBER_START', 100),
];
