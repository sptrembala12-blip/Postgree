# Permissions (RBAC)

## Roles (seeded)

| Slug | Label |
|------|-------|
| `admin` | full access (short-circuit) |
| `attendant` | orders/tables ops |
| `manager` | ops + catalog + stock + cash + reports + audit |
| `cashier` | cash + orders view/manage |
| `stock_manager` | stock + product view |

## Permission slugs

- `dashboard.view`
- `orders.view` / `orders.manage` / `orders.cancel`
- `tables.view` / `tables.manage`
- `categories.view` / `categories.manage`
- `products.view` / `products.manage`
- `stock.view` / `stock.manage`
- `cash.view` / `cash.manage`
- `reports.view`
- `users.view` / `users.manage`
- `audit.view`
- `settings.manage`
- `payments.confirm`

## Enforcement

- API: `auth:sanctum` + `active` + `admin` + `permission:*`
- Web admin: `auth` + `active` + `admin` + `permission:*` per route
- Controllers may double-check cancel/payment actions

## Guarantees

Attendant **cannot**:

- create admin users
- view financial reports
- change stock
- change settings
- view audit logs
- manage product prices

Verified by `AuthorizationHardeningTest`.
