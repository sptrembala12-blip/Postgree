# Architecture — Lounge System

## Overview

Laravel 12 modular backend for lounge/bar operations.

```
Client (menu Blade / future SPA)
        │
        ▼
   HTTP Routes
   ├─ web.php   (public menu + admin Blade)
   └─ api.php   (v1 auth/public/customer/admin)
        │
        ▼
 Controllers (thin)
        │
        ▼
 Services (business rules)
   Orders · Payments · Inventory · Cash · Tables · Reports · Audit
        │
        ▼
 Eloquent Models + MySQL/MariaDB
        │
        ▼
 Events (OrderCreated, …) → log | SSE poll | future Reverb/Pusher
```

## Principles

1. Backend is source of truth for prices, totals, stock, change, permissions.
2. Money in **integer cents** via `App\Support\Money`.
3. Critical ops in `DB::transaction` + `lockForUpdate` where needed.
4. RBAC: `roles` / `permissions` + middleware `permission:`.
5. Payment **method ≠ status**; gateway interface for future PSP.

## Key services

| Service | Responsibility |
|---------|----------------|
| `OrderService` | Create order, state machine, stock deduct/restore |
| `PaymentService` | Create/confirm/refund/cancel payments |
| `InventoryService` | Stock movements with row locks |
| `CashService` | Open/close register, movements, summary |
| `CartService` | Ephemeral cart; always recalculates |
| `TableService` | Tables, QR, sessions |
| `ReportService` | Dashboard & reports in business timezone |
| `AuditService` | Immutable audit log writes |

## Order state machine

```
PENDING → CONFIRMED → PREPARING → READY → DELIVERED → COMPLETED
   └──────────── cancel allowed until DELIVERED ──────────┘
COMPLETED / CANCELLED are terminal
```

Stock deduction default: on **CONFIRMED**. Cancel restores via `RETURN` movement when `stock_deducted`.

## Layers intentionally not used

- No Repository layer (Eloquent is enough for this domain size).
- Policies folder empty — authorization centralized in middleware + controller checks.
- No fake payment capture.
