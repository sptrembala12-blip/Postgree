# Relatório de Auditoria Técnica — Lounge System Motor v1.0

Data: 2026-08-20

## Ambiente

| Item | Valor |
|------|-------|
| PHP | 8.4.24 |
| Laravel | 12.67.0 |
| Banco (dev) | **MariaDB 11.8.6** via driver `mysql` |
| Banco (prod alvo) | MySQL 8+ gerenciado (Render) |
| Timezone | `America/Sao_Paulo` |

## Testes

| | |
|--|--|
| Total | **51** |
| Passando | **51** |
| Falhando | **0** |
| Assertions | 144 |

## Correções realizadas

1. **Autorização web admin** — rotas Blade agora usam `permission:*` (antes só `admin` genérico; attendant acessava users/reports/settings).
2. **Cancelamento de pedido** — checagem extra de `orders.cancel` / `payments.confirm` no controller web.
3. **Order total > 0** — rejeita pedido zerado.
4. **Money** — parse BR sem aritmética float no caminho principal; rejeita total 0 e negativos no troco; exact change = 0.
5. **OrderService** — agrega itens, lock estável por product_id, valida categoria ativa, mesa maintenance bloqueada, carrinho expirado.
6. **Cancelamento + pagamento** — PENDING cancela payment; PAID faz refund + movimento REFUND no caixa.
7. **CashService** — `GET_LOCK` na abertura; impede movimento duplicado por payment; `recordRefundPayment`; expected_cash corrigido (refunds).
8. **PaymentService** — cancel/refund com lock; metadata `real_capture:false`; confirm registra venda no caixa sem duplicar.
9. **PaymentStatus::Authorized** adicionado ao enum.
10. **Timezone** — `APP_TIMEZONE=America/Sao_Paulo` em config/app, lounge, .env, phpunit, ReportService.
11. **Realtime honesto** — SSE + poll JSON; dashboard/orders usam EventSource; docs deixam claro que WebSocket NÃO está ativo.
12. **Índices** — migration `2026_08_20_120000_add_hardening_indexes` (não destrutiva).
13. **Cart** — expirado gera novo token; summarize recalcula preço atual.
14. **ManualPaymentGateway** — documentação explícita de modo teste.
15. **Testes novos** — Authorization, Concurrency/Cancel, Cart/QR, Money edge cases.
16. **Documentação** — ARCHITECTURE, API, DATABASE, DEPLOY, REALTIME, PERMISSIONS, BUSINESS_RULES.

## Problemas encontrados (e status)

| Problema | Status |
|----------|--------|
| Web admin sem permission middleware fino | **Corrigido** |
| COMPLETED→cancel permitido na máquina? | Já bloqueado; teste adicionado |
| Troco/total zero não rejeitado | **Corrigido** |
| Timezone UTC distorce “hoje” | **Corrigido** → America/Sao_Paulo |
| WebSocket declarado implicitamente | **Corrigido** — SSE + docs honestos |
| Dupla abertura de caixa race | **Mitigado** com GET_LOCK |
| Refund não voltava ao caixa | **Corrigido** |
| Movimento de venda duplicado no confirm | **Corrigido** (unique por reference) |
| Policies vazias | Aceito — middleware centraliza (documentado) |
| Upload local efêmero no Render | **Documentado** (não corrigido com S3 — fora de escopo motor) |
| Queue worker separado no Render | **Documentado** como pendência ops |
| Concorrência multi-process real | Teste serial com locks; multi-process full E2E não rodado em CI |

## Problemas que permanecem (aceitáveis / ops)

1. **WebSocket real** não provisionado (Reverb/Pusher) — SSE cobre near-realtime.
2. **PIX/Cartão reais** não integrados — gateway manual explícito.
3. **Storage de imagens/QR no Render** sem disco persistente/S3.
4. **Queue worker** não é processo separado no render.yaml.
5. **Policies Laravel** não usadas (RBAC via middleware) — suficiente, mas diferente do estilo Policy-first.
6. **Teste de race multi-process** (dois PHP paralelos) não está no PHPUnit padrão.

## Realtime

**WebSocket REAL funcionando: NÃO**

O que funciona:
- Events `ShouldBroadcast` disparados
- SSE `/admin/realtime/orders-stream`
- Poll `/api/v1/admin/realtime/orders`
- UI admin escuta SSE e mostra/atualiza pedidos

O que falta para WebSocket:
- `BROADCAST_CONNECTION=reverb|pusher`
- servidor Reverb/Pusher + Redis opcional
- frontend Echo assinando canais

## Pagamentos

| | |
|--|--|
| PIX real integrado | **NÃO** |
| Cartão real integrado | **NÃO** |
| Manual/teste | **SIM** |
| CASH com troco validado | **SIM** |
| method ≠ status | **SIM** |

## Produção (Render)

| Item | |
|------|--|
| Render pronto (Dockerfile/yaml/PORT) | **SIM** (com ressalvas) |
| Banco produção configurado | **Parcial** — blueprint pronto; precisa provisionar |
| Migrations produção controladas | **SIM** (`RUN_MIGRATIONS`) |
| Storage persistente | **NÃO** por padrão |
| Queue worker | **NÃO** dedicado |
| Realtime WebSocket | **NÃO** |
| APP_DEBUG production blueprint | **false** |

**Não declarar “produção enterprise completa”.**  
Motor **v1.0 estabilizado** para validação de negócio e integração de frontend; deploy Render é **viável com checklist** em `docs/DEPLOY.md`.

## Critério final

- Segurança de autorização backend: **OK** (testada)
- Integridade financeira cents: **OK**
- Estoque com lock: **OK**
- Testes: **51/51**
- WebSocket não falsamente vendido: **OK**
- Pagamento real não fingido: **OK**

**MOTOR v1.0 ESTABILIZADO — não iniciar frontend definitivo ainda sem revisão deste relatório.**
