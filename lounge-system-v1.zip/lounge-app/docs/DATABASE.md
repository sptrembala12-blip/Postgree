# Database

## Engine

| Environment | Engine | Version (current dev) |
|-------------|--------|------------------------|
| Development (this workspace) | **MariaDB** | **11.8.6** |
| Target production (Render) | **MySQL 8+** (managed) | as provisioned |

Laravel uses `DB_CONNECTION=mysql` driver — compatible with both MySQL 8 and MariaDB 10.11+/11.x.

**Do not use SQLite for production.**

## Money columns

All monetary fields are `BIGINT UNSIGNED` (or signed `BIGINT` for differences) storing **cents**.

Examples: `products.price`, `orders.total`, `payments.amount`, `cash_registers.opening_amount`.

## Core tables

See migrations under `database/migrations/`.

Notable FKs:

- `order_items.product_id` → nullOnDelete (keeps historical snapshot)
- `products.category_id` → restrictOnDelete
- `inventory_movements.product_id` → restrictOnDelete
- Cash movements cascade with register

## Indexes (incl. hardening migration)

- orders: status+created_at, table_id+created_at, order_number unique
- payments: method+status, status+method+paid_at
- products: active+category+sort, current_stock
- audit_logs: action+created_at
- cash_registers: status+opened_at

## Character set

`utf8mb4` / `utf8mb4_unicode_ci`
