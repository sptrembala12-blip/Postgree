# Business Rules

## Money

- Store and calculate in **cents (int)**.
- Never trust client totals/prices.
- Cash change: `amount_received >= total`; else reject.
- Order total must be **> 0**.

## Orders

- Price from DB at checkout (`effectivePrice` = promo if lower).
- Snapshot `product_name_snapshot` + `unit_price` on items.
- State machine enforced in `OrderService`.
- Cancel after confirm restores stock via `RETURN` movement.
- Cancel COMPLETED: **blocked**.
- Billable statuses for revenue: CONFIRMED…COMPLETED (not PENDING, not CANCELLED).

## Stock

- `lockForUpdate` on product row.
- Negative stock forbidden unless `ALLOW_NEGATIVE_STOCK=true`.
- All changes via `inventory_movements`.

## Payments

| Method | Initial status (manual gateway) | Real capture |
|--------|----------------------------------|--------------|
| CASH | PAID (after change validation) | N/A (cash) |
| PIX | AWAITING_CONFIRMATION | **No** |
| CREDIT/DEBIT | AWAITING_CONFIRMATION | **No** |

Manual confirm sets PAID and may register cash movement. Metadata marks `real_capture: false`.

## Cash register

- Single open register (GET_LOCK + check).
- Sales/refunds linked to payment reference (no silent dupes).
- Close computes expected vs informed difference.

## Tables / QR

- Each table has unique `qr_token`.
- Public menu by number or token; orders validate active table not in MAINTENANCE/INACTIVE.
- Sessions track consumption period.

## Timezone

- `APP_TIMEZONE=America/Sao_Paulo` for "today" and period filters.
