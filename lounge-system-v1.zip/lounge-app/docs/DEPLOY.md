# Deploy — Render

## What is ready

| Item | Status |
|------|--------|
| Dockerfile (PHP 8.3 CLI) | Yes |
| `render.yaml` blueprint | Yes |
| Dynamic `PORT` | Yes (`docker/start.sh`) |
| Health check `/up` | Yes |
| Controlled migrations (`RUN_MIGRATIONS`) | Yes |
| MySQL managed DB wiring | Yes (env from Render DB) |
| `APP_DEBUG=false` in blueprint | Yes |
| Storage symlink on boot | Yes |
| Queue worker process | **Not** as separate worker yet — uses `database` driver; process jobs via `schedule`/`queue:work` if needed |
| Redis / Reverb WebSocket | **Not** provisioned by default |
| Object storage (S3) for images | **Not** — uses local `public` disk |

## Steps

1. Push repo to GitHub/GitLab.
2. Create Render Blueprint from `render.yaml` **or** Web Service from Dockerfile.
3. Attach MySQL database.
4. Set env:
   - `APP_KEY` (generate)
   - `APP_URL` https://your-service.onrender.com
   - `APP_ENV=production`
   - `APP_DEBUG=false`
   - `APP_TIMEZONE=America/Sao_Paulo`
   - DB_* from database
   - `RUN_MIGRATIONS=true` for first deploy only
5. Deploy.
6. One-time seed (Render shell): `php artisan db:seed --force`
7. Set `RUN_MIGRATIONS=false` after schema is applied.
8. Verify `/up`, `/admin/login`, `/api/v1/public/menu`.

## Important

- Migrations are **non-destructive** (`migrate`, not `migrate:fresh`).
- Never run `migrate:fresh` in production.
- Local disk uploads are **ephemeral** on Render free/starter without persistent disk — attach a disk to `/var/www/html/storage` or switch to S3 for production images/QR.

## Start command

```bash
/usr/local/bin/start.sh
# php artisan serve --host=0.0.0.0 --port=$PORT
```

For higher load, put nginx+php-fpm or Octane behind the same PORT contract.
