# Realtime

## Honest status

| Capability | Status |
|------------|--------|
| Laravel Events (`OrderCreated`, etc.) | **Yes** — dispatched |
| `ShouldBroadcast` interfaces | **Yes** — ready |
| WebSocket server (Reverb/Pusher) | **NO** by default |
| `BROADCAST_CONNECTION` default | `log` |
| Near-realtime admin feed | **Yes** — **SSE + JSON poll** |

**WebSocket REAL funcionando: NÃO**

O painel admin **não** depende de declarar WebSocket falso. Usa:

1. **SSE** `GET /admin/realtime/orders-stream` (web session)
2. **JSON poll** `GET /api/v1/admin/realtime/orders?last_id=`
3. Events still fire for future WebSocket consumers

## How SSE works

```
Order created → DB commit → OrderCreated event (also logged if broadcast=log)
Admin browser EventSource → /admin/realtime/orders-stream
Controller polls new Order rows by id → pushes event: order.created
```

Latency: ~1–2s. Not push-from-Redis, but no fake WebSocket claim.

## Enabling real WebSockets later

1. Install Laravel Reverb (or Pusher).
2. `BROADCAST_CONNECTION=reverb`
3. Run `php artisan reverb:start`
4. Front subscribes to channel `admin.orders` events `order.created`, `order.status_updated`.
5. Keep SSE as fallback.

## Notifications

- New order payload includes cash change fields when method=CASH.
- Low stock: endpoint `/api/v1/admin/stock/low` + dashboard count (no spam loop).
- Do not emit infinite notifications from polling — SSE only emits **new** ids.
