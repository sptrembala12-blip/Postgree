# API v1 — Lounge System

Base: `/api/v1`  
Auth admin: `Authorization: Bearer {token}`  
Money: **integer cents**

## Auth
- `POST /auth/login`
- `GET /auth/me`
- `POST /auth/logout`

## Public
- `GET /public/menu|categories|products|...`
- `GET /public/tables/number/{n}`
- `GET /public/tables/token/{token}`

## Customer
- Cart CRUD under `/customer/cart*`
- `POST /customer/orders` — backend recalculates everything
- `GET /customer/orders/{orderNumber}`

## Admin
Full CRUD + order transitions + stock + cash + reports + users + audit.

### Near-realtime
- `GET /admin/realtime/orders?last_id=`
- `GET /admin/realtime/orders/stream` (SSE)

See also root README and BUSINESS_RULES.md.
