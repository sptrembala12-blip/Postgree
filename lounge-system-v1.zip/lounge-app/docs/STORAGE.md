# Storage

- Local disk: `storage/app/public` linked to `public/storage`
- Product images and QR codes live there
- On Render free/ephemeral FS: attach a **persistent disk** mounted at `/var/www/html/storage` or switch `FILESYSTEM_DISK` to S3-compatible later
- V1 does not require paid object storage; document only
