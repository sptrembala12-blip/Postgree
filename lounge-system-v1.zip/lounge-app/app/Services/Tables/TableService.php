<?php

namespace App\Services\Tables;

use App\Enums\TableSessionStatus;
use App\Enums\TableStatus;
use App\Events\TableStatusUpdated;
use App\Models\Table;
use App\Models\TableSession;
use App\Models\User;
use App\Services\Audit\AuditService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class TableService
{
    public function __construct(private readonly AuditService $audit) {}

    public function create(array $data, ?User $user = null): Table
    {
        $table = Table::create([
            'number' => $data['number'],
            'name' => $data['name'] ?? null,
            'type' => $data['type'] ?? \App\Enums\TableType::Table->value,
            'capacity' => $data['capacity'] ?? 4,
            'location' => $data['location'] ?? null,
            'status' => $data['status'] ?? TableStatus::Available->value,
            'qr_token' => Str::random(40),
            'is_active' => $data['is_active'] ?? true,
        ]);

        $this->generateQrCode($table);
        $this->audit->log('TABLE_CREATED', $table, null, $table->toArray(), $user);

        return $table->fresh();
    }

    public function update(Table $table, array $data, ?User $user = null): Table
    {
        $old = $table->toArray();
        $table->fill($data);
        $table->save();

        $this->audit->log('TABLE_UPDATED', $table, $old, $table->toArray(), $user);
        event(new TableStatusUpdated($table->fresh()));

        return $table->fresh();
    }

    public function generateQrCode(Table $table): Table
    {
        $url = $table->publicTokenUrl();
        $filename = 'qrcodes/table-'.$table->id.'-'.Str::random(8).'.svg';

        $svg = QrCode::format('svg')->size(300)->margin(1)->generate($url);
        Storage::disk('public')->put($filename, $svg);

        if ($table->qr_code_path && Storage::disk('public')->exists($table->qr_code_path)) {
            Storage::disk('public')->delete($table->qr_code_path);
        }

        $table->qr_code_path = $filename;
        $table->save();

        return $table;
    }

    public function regenerateQr(Table $table, ?User $user = null): Table
    {
        $oldToken = $table->qr_token;
        $table->qr_token = Str::random(40);
        $table->save();
        $this->generateQrCode($table);

        $this->audit->log('TABLE_QR_REGENERATED', $table, ['qr_token' => $oldToken], [
            'qr_token' => $table->qr_token,
        ], $user);

        return $table->fresh();
    }

    public function openSession(Table $table, ?User $user = null): TableSession
    {
        return DB::transaction(function () use ($table, $user) {
            /** @var Table $locked */
            $locked = Table::query()->whereKey($table->id)->lockForUpdate()->firstOrFail();

            if (! $locked->is_active) {
                throw new RuntimeException('Mesa inativa.');
            }

            $existing = TableSession::query()
                ->where('table_id', $locked->id)
                ->where('status', TableSessionStatus::Open->value)
                ->first();

            if ($existing) {
                return $existing;
            }

            $session = TableSession::create([
                'table_id' => $locked->id,
                'opened_at' => now(),
                'status' => TableSessionStatus::Open->value,
                'total_amount' => 0,
                'opened_by' => $user?->id,
            ]);

            $locked->status = TableStatus::Occupied;
            $locked->save();

            event(new TableStatusUpdated($locked->fresh()));

            return $session;
        });
    }

    public function closeSession(TableSession $session, ?User $user = null): TableSession
    {
        return DB::transaction(function () use ($session, $user) {
            /** @var TableSession $locked */
            $locked = TableSession::query()->whereKey($session->id)->lockForUpdate()->firstOrFail();

            if (! $locked->isOpen()) {
                return $locked;
            }

            $locked->recalculateTotal();
            $locked->status = TableSessionStatus::Closed;
            $locked->closed_at = now();
            $locked->closed_by = $user?->id;
            $locked->save();

            $table = Table::query()->whereKey($locked->table_id)->lockForUpdate()->first();
            if ($table) {
                $hasOtherOpen = TableSession::query()
                    ->where('table_id', $table->id)
                    ->where('status', TableSessionStatus::Open->value)
                    ->where('id', '!=', $locked->id)
                    ->exists();

                if (! $hasOtherOpen) {
                    $table->status = TableStatus::Available;
                    $table->save();
                    event(new TableStatusUpdated($table->fresh()));
                }
            }

            return $locked->fresh();
        });
    }

    public function findByNumber(string $number): ?Table
    {
        return Table::query()->where('number', $number)->where('is_active', true)->first();
    }

    public function findByToken(string $token): ?Table
    {
        return Table::query()->where('qr_token', $token)->where('is_active', true)->first();
    }
}
