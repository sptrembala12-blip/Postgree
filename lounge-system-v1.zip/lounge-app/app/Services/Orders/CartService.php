<?php

namespace App\Services\Orders;

use App\Models\Cart;
use App\Models\Product;
use App\Models\Table;
use App\Support\Money;
use Illuminate\Support\Str;
use InvalidArgumentException;
use RuntimeException;

class CartService
{
    public function getOrCreate(?string $token = null, ?Table $table = null): Cart
    {
        if ($token) {
            $cart = Cart::query()->where('token', $token)->first();
            if ($cart) {
                if ($cart->isExpired()) {
                    // Expired carts are discarded — create a fresh one
                    return Cart::create([
                        'token' => Str::random(40),
                        'table_id' => $table?->id ?? $cart->table_id,
                        'items' => [],
                        'expires_at' => now()->addHours(6),
                    ]);
                }
                if ($table && $cart->table_id !== $table->id) {
                    $cart->table_id = $table->id;
                    $cart->save();
                }

                return $cart;
            }
        }

        return Cart::create([
            'token' => Str::random(40),
            'table_id' => $table?->id,
            'items' => [],
            'expires_at' => now()->addHours(6),
        ]);
    }

    public function addItem(Cart $cart, int $productId, int $quantity = 1, ?string $notes = null): Cart
    {
        if ($quantity < 1) {
            throw new InvalidArgumentException('Quantidade deve ser pelo menos 1.');
        }

        $product = Product::query()->active()->findOrFail($productId);

        if (! $product->isAvailableForSale($quantity)) {
            throw new RuntimeException("Produto {$product->name} indisponível para a quantidade solicitada.");
        }

        $items = $cart->items ?? [];
        $found = false;

        foreach ($items as &$item) {
            if ((int) $item['product_id'] === $productId) {
                $newQty = (int) $item['quantity'] + $quantity;
                if (! $product->isAvailableForSale($newQty)) {
                    throw new RuntimeException("Estoque insuficiente para {$product->name}.");
                }
                $item['quantity'] = $newQty;
                if ($notes !== null) {
                    $item['notes'] = $notes;
                }
                $found = true;
                break;
            }
        }
        unset($item);

        if (! $found) {
            $items[] = [
                'product_id' => $productId,
                'quantity' => $quantity,
                'notes' => $notes,
            ];
        }

        $cart->items = array_values($items);
        $cart->expires_at = now()->addHours(6);
        $cart->save();

        return $cart->fresh();
    }

    public function updateQuantity(Cart $cart, int $productId, int $quantity): Cart
    {
        if ($quantity < 1) {
            return $this->removeItem($cart, $productId);
        }

        $product = Product::query()->active()->findOrFail($productId);
        if (! $product->isAvailableForSale($quantity)) {
            throw new RuntimeException("Estoque insuficiente para {$product->name}.");
        }

        $items = $cart->items ?? [];
        $found = false;

        foreach ($items as &$item) {
            if ((int) $item['product_id'] === $productId) {
                $item['quantity'] = $quantity;
                $found = true;
                break;
            }
        }
        unset($item);

        if (! $found) {
            throw new InvalidArgumentException('Item não encontrado no carrinho.');
        }

        $cart->items = array_values($items);
        $cart->save();

        return $cart->fresh();
    }

    public function removeItem(Cart $cart, int $productId): Cart
    {
        $items = array_values(array_filter(
            $cart->items ?? [],
            fn ($item) => (int) $item['product_id'] !== $productId
        ));

        $cart->items = $items;
        $cart->save();

        return $cart->fresh();
    }

    public function clear(Cart $cart): Cart
    {
        $cart->items = [];
        $cart->save();

        return $cart->fresh();
    }

    /**
     * Recalculate cart using backend prices only.
     *
     * @return array{
     *   items: list<array<string,mixed>>,
     *   subtotal: int,
     *   total: int,
     *   subtotal_formatted: string,
     *   total_formatted: string
     * }
     */
    public function summarize(Cart $cart): array
    {
        $lines = [];
        $subtotal = 0;

        foreach ($cart->items ?? [] as $item) {
            $product = Product::query()->with('category')->find($item['product_id']);
            if (! $product || ! $product->is_active) {
                continue;
            }

            $qty = (int) $item['quantity'];
            $unit = $product->effectivePrice();
            $lineSubtotal = Money::multiply($unit, $qty);
            $subtotal += $lineSubtotal;

            $lines[] = [
                'product_id' => $product->id,
                'name' => $product->name,
                'slug' => $product->slug,
                'quantity' => $qty,
                'unit_price' => $unit,
                'unit_price_formatted' => Money::format($unit),
                'subtotal' => $lineSubtotal,
                'subtotal_formatted' => Money::format($lineSubtotal),
                'notes' => $item['notes'] ?? null,
                'available' => $product->isAvailableForSale($qty),
                'stock_control_enabled' => $product->stock_control_enabled,
                'current_stock' => $product->current_stock,
            ];
        }

        return [
            'token' => $cart->token,
            'table_id' => $cart->table_id,
            'customer_name' => $cart->customer_name,
            'items' => $lines,
            'subtotal' => $subtotal,
            'total' => $subtotal,
            'subtotal_formatted' => Money::format($subtotal),
            'total_formatted' => Money::format($subtotal),
            'items_count' => array_sum(array_column($lines, 'quantity')),
        ];
    }
}
