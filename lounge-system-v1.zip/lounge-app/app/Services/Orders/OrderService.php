<?php

namespace App\Services\Orders;

use App\Enums\OrderStatus;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableStatus;
use App\Events\OrderCreated;
use App\Events\OrderStatusUpdated;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Table;
use App\Models\User;
use App\Services\Audit\AuditService;
use App\Services\Cash\CashService;
use App\Services\Inventory\InventoryService;
use App\Services\Payments\PaymentService;
use App\Services\Tables\TableService;
use App\Support\Money;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use RuntimeException;

class OrderService
{
    public function __construct(
        private readonly InventoryService $inventory,
        private readonly PaymentService $payments,
        private readonly TableService $tables,
        private readonly CashService $cash,
        private readonly AuditService $audit,
        private readonly CartService $carts,
    ) {}

    /**
     * Create order. All prices recalculated on backend.
     *
     * @param  array<string, mixed>  $data
     */
    public function create(array $data, ?User $user = null): Order
    {
        return DB::transaction(function () use ($data, $user) {
            $table = $this->resolveTable($data);
            $session = $table ? $this->tables->openSession($table, $user) : null;

            $rawItems = $data['items'] ?? null;
            if ($rawItems === null && ! empty($data['cart_token'])) {
                $cart = $this->carts->getOrCreate($data['cart_token'], $table);
                if ($cart->isExpired()) {
                    throw new InvalidArgumentException('Carrinho expirado.');
                }
                $summary = $this->carts->summarize($cart);
                $rawItems = array_map(fn ($i) => [
                    'product_id' => $i['product_id'],
                    'quantity' => $i['quantity'],
                    'notes' => $i['notes'] ?? null,
                ], $summary['items']);
            }

            if (empty($rawItems)) {
                throw new InvalidArgumentException('Pedido sem itens.');
            }

            // Aggregate quantities by product to lock each row once
            $aggregated = [];
            foreach ($rawItems as $line) {
                $productId = (int) ($line['product_id'] ?? 0);
                $qty = (int) ($line['quantity'] ?? 0);
                if ($productId < 1 || $qty < 1) {
                    throw new InvalidArgumentException('Item de pedido inválido.');
                }
                if (! isset($aggregated[$productId])) {
                    $aggregated[$productId] = ['quantity' => 0, 'notes' => $line['notes'] ?? null];
                }
                $aggregated[$productId]['quantity'] += $qty;
                if (! empty($line['notes'])) {
                    $aggregated[$productId]['notes'] = $line['notes'];
                }
            }

            // Stable lock order to reduce deadlocks
            ksort($aggregated);

            $builtItems = [];
            $subtotal = 0;

            foreach ($aggregated as $productId => $line) {
                $qty = (int) $line['quantity'];

                /** @var Product $product */
                $product = Product::query()->whereKey($productId)->lockForUpdate()->firstOrFail();

                if (! $product->is_active) {
                    throw new RuntimeException("Produto {$product->name} está inativo.");
                }

                $product->loadMissing('category');
                if ($product->category && ! $product->category->is_active) {
                    throw new RuntimeException("Categoria do produto {$product->name} está inativa.");
                }

                // Inline stock check under the same lock (no nested lock race)
                if ($product->stock_control_enabled && ! config('lounge.allow_negative_stock', false)) {
                    if ($product->current_stock < $qty) {
                        throw new RuntimeException(
                            "Estoque insuficiente para {$product->name}. Disponível: {$product->current_stock}, solicitado: {$qty}"
                        );
                    }
                }

                $unit = $product->effectivePrice();
                if ($unit < 0) {
                    throw new RuntimeException("Preço inválido para {$product->name}.");
                }

                $lineSubtotal = Money::multiply($unit, $qty);
                $subtotal += $lineSubtotal;

                $builtItems[] = [
                    'product_id' => $product->id,
                    'product_name_snapshot' => $product->name,
                    'unit_price' => $unit,
                    'quantity' => $qty,
                    'subtotal' => $lineSubtotal,
                    'notes' => $line['notes'],
                ];
            }

            $discount = (int) ($data['discount'] ?? 0);
            if ($discount < 0 || $discount > $subtotal) {
                throw new InvalidArgumentException('Desconto inválido.');
            }
            $total = $subtotal - $discount;

            if ($total <= 0) {
                throw new InvalidArgumentException('Total do pedido deve ser maior que zero.');
            }

            $orderNumber = $this->nextOrderNumber();

            $order = Order::create([
                'order_number' => $orderNumber,
                'table_id' => $table?->id,
                'table_session_id' => $session?->id,
                'status' => OrderStatus::Pending->value,
                'subtotal' => $subtotal,
                'discount' => $discount,
                'total' => $total,
                'notes' => $data['notes'] ?? null,
                'customer_name' => $data['customer_name'] ?? null,
                'created_by' => $user?->id,
                'stock_deducted' => false,
            ]);

            foreach ($builtItems as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item['product_id'],
                    'product_name_snapshot' => $item['product_name_snapshot'],
                    'unit_price' => $item['unit_price'],
                    'quantity' => $item['quantity'],
                    'subtotal' => $item['subtotal'],
                    'notes' => $item['notes'],
                ]);
            }

            $payment = $this->payments->createForOrder($order, [
                'method' => $data['payment_method'],
                'amount_received' => $data['amount_received'] ?? null,
            ], $user);

            if (! empty($data['cart_token'])) {
                $cart = $this->carts->getOrCreate($data['cart_token'], $table);
                $this->carts->clear($cart);
            }

            $session?->recalculateTotal();

            $order = $order->fresh(['items', 'payment', 'table', 'tableSession']);

            $this->audit->log('ORDER_CREATED', $order, null, [
                'order_number' => $order->order_number,
                'total' => $order->total,
                'status' => $order->status->value,
                'payment_method' => $payment->method->value,
                'payment_status' => $payment->status->value,
            ], $user);

            event(new OrderCreated($order));

            return $order;
        });
    }

    public function transition(Order $order, OrderStatus $target, ?User $user = null, ?string $reason = null): Order
    {
        return DB::transaction(function () use ($order, $target, $user, $reason) {
            /** @var Order $locked */
            $locked = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            $current = $locked->status;

            if (! $current->canTransitionTo($target)) {
                throw new RuntimeException(
                    "Transição inválida: {$current->value} → {$target->value}"
                );
            }

            $oldStatus = $current->value;
            $locked->status = $target;

            match ($target) {
                OrderStatus::Confirmed => $locked->confirmed_at = now(),
                OrderStatus::Completed => $locked->completed_at = now(),
                OrderStatus::Cancelled => tap($locked, function (Order $o) use ($user, $reason) {
                    $o->cancelled_at = now();
                    $o->cancelled_by = $user?->id;
                    $o->cancellation_reason = $reason;
                }),
                default => null,
            };

            $locked->save();

            if ($target === OrderStatus::Confirmed) {
                $this->deductStockIfNeeded($locked, $user);
            }

            if ($target === OrderStatus::Cancelled) {
                $this->restoreStockIfNeeded($locked, $user);
                $this->handlePaymentOnCancel($locked, $user);
            }

            $locked->tableSession?->recalculateTotal();

            $this->audit->log(
                $target === OrderStatus::Cancelled ? 'ORDER_CANCELLED' : 'ORDER_STATUS_UPDATED',
                $locked,
                ['status' => $oldStatus],
                ['status' => $target->value, 'reason' => $reason],
                $user
            );

            $fresh = $locked->fresh(['items', 'payment', 'table']);
            event(new OrderStatusUpdated($fresh));

            return $fresh;
        });
    }

    public function confirm(Order $order, ?User $user = null): Order
    {
        return $this->transition($order, OrderStatus::Confirmed, $user);
    }

    public function startPreparing(Order $order, ?User $user = null): Order
    {
        return $this->transition($order, OrderStatus::Preparing, $user);
    }

    public function markReady(Order $order, ?User $user = null): Order
    {
        return $this->transition($order, OrderStatus::Ready, $user);
    }

    public function markDelivered(Order $order, ?User $user = null): Order
    {
        return $this->transition($order, OrderStatus::Delivered, $user);
    }

    public function complete(Order $order, ?User $user = null): Order
    {
        return $this->transition($order, OrderStatus::Completed, $user);
    }

    public function cancel(Order $order, ?User $user = null, ?string $reason = null): Order
    {
        return $this->transition($order, OrderStatus::Cancelled, $user, $reason);
    }

    private function deductStockIfNeeded(Order $order, ?User $user): void
    {
        if ($order->stock_deducted) {
            return;
        }

        if (config('lounge.stock_deduction_on', 'confirmed') !== 'confirmed') {
            return;
        }

        $order->loadMissing('items.product');

        // Lock products in stable ID order
        $items = $order->items->sortBy('product_id');
        foreach ($items as $item) {
            if (! $item->product || ! $item->product->stock_control_enabled) {
                continue;
            }
            $this->inventory->sale($item->product, (int) $item->quantity, $order, $user);
        }

        $order->stock_deducted = true;
        $order->save();
    }

    private function restoreStockIfNeeded(Order $order, ?User $user): void
    {
        if (! $order->stock_deducted) {
            return;
        }

        $order->loadMissing('items.product');

        $items = $order->items->sortBy('product_id');
        foreach ($items as $item) {
            if (! $item->product || ! $item->product->stock_control_enabled) {
                continue;
            }
            $this->inventory->returnStock(
                $item->product,
                (int) $item->quantity,
                'Cancelamento pedido '.$order->displayNumber(),
                $user,
                $order
            );
        }

        $order->stock_deducted = false;
        $order->save();
    }

    private function handlePaymentOnCancel(Order $order, ?User $user): void
    {
        $payment = $order->payment()->lockForUpdate()->first();
        if (! $payment) {
            return;
        }

        if ($payment->status === PaymentStatus::Paid) {
            $this->payments->refund($payment, $user);
            $this->cash->recordRefundPayment($payment->fresh(), $user);
        } elseif (in_array($payment->status, [
            PaymentStatus::Pending,
            PaymentStatus::AwaitingConfirmation,
            PaymentStatus::Authorized,
        ], true)) {
            $this->payments->cancel($payment, $user);
        }
    }

    private function nextOrderNumber(): int
    {
        // Lock latest row to serialize numbering inside the transaction
        $last = Order::query()->orderByDesc('order_number')->lockForUpdate()->value('order_number');
        $start = (int) config('lounge.order_number_start', 100);

        return $last ? ((int) $last + 1) : $start;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    private function resolveTable(array $data): ?Table
    {
        $table = null;

        if (! empty($data['table_id'])) {
            $table = Table::query()->whereKey($data['table_id'])->where('is_active', true)->firstOrFail();
        } elseif (! empty($data['table_number'])) {
            $table = $this->tables->findByNumber((string) $data['table_number']);
            if (! $table) {
                throw new InvalidArgumentException('Mesa não encontrada.');
            }
        }

        if ($table) {
            if (in_array($table->status, [TableStatus::Maintenance, TableStatus::Inactive], true)) {
                throw new RuntimeException('Mesa indisponível para pedidos.');
            }
        }

        return $table;
    }
}
