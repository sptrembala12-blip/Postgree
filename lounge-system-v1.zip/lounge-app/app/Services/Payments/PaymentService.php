<?php

namespace App\Services\Payments;

use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Events\PaymentUpdated;
use App\Models\Order;
use App\Models\Payment;
use App\Models\User;
use App\Services\Audit\AuditService;
use App\Services\Notifications\AdminNotificationService;
use App\Support\Money;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class PaymentService
{
    public function __construct(
        private readonly PaymentGatewayInterface $gateway,
        private readonly AuditService $audit,
    ) {}

    /**
     * @param  array{method:string, amount_received?:int|null, transaction_reference?:string|null}  $data
     */
    public function createForOrder(Order $order, array $data, ?User $user = null): Payment
    {
        $method = PaymentMethod::from($data['method']);
        $amount = (int) $order->total;

        if ($amount <= 0) {
            throw new InvalidArgumentException('Valor do pagamento deve ser maior que zero.');
        }

        $amountReceived = null;
        $changeAmount = 0;

        if ($method === PaymentMethod::Cash) {
            if (! isset($data['amount_received'])) {
                throw new InvalidArgumentException('Para pagamento em dinheiro informe amount_received (centavos).');
            }
            $change = Money::calculateChange($amount, (int) $data['amount_received']);
            $amountReceived = $change['amount_received'];
            $changeAmount = $change['change_amount'];
        }

        return DB::transaction(function () use ($order, $method, $amount, $amountReceived, $changeAmount, $data, $user) {
            $payment = Payment::create([
                'order_id' => $order->id,
                'method' => $method->value,
                'status' => PaymentStatus::Pending->value,
                'amount' => $amount,
                'amount_received' => $amountReceived,
                'change_amount' => $changeAmount,
                'transaction_reference' => $data['transaction_reference'] ?? null,
                'metadata' => [
                    'gateway' => $this->gateway->driver(),
                    'gateway_mode' => 'manual_test',
                    'note' => 'Gateway manual/teste — não representa captura real de adquirente/PIX.',
                ],
                'recorded_by' => $user?->id,
            ]);

            $result = $this->gateway->initiate($order, $payment, $data);

            $payment->status = $result->status;
            $payment->transaction_reference = $result->transactionReference ?? $payment->transaction_reference;
            $payment->metadata = array_merge($payment->metadata ?? [], $result->metadata);
            if ($result->isPaid()) {
                $payment->paid_at = now();
            }
            $payment->save();

            if ($payment->isPaid() && $method === PaymentMethod::Cash) {
                app(\App\Services\Cash\CashService::class)->recordSalePayment($payment, $user);
            }

            $this->audit->log('PAYMENT_CREATED', $payment, null, [
                'method' => $payment->method->value,
                'status' => $payment->status->value,
                'amount' => $payment->amount,
                'change_amount' => $payment->change_amount,
            ], $user);
            event(new PaymentUpdated($payment->fresh()));

            // Cash is settled at checkout (validated change). PIX/card stay awaiting — no notify here.
            if ($payment->isPaid() && $method === PaymentMethod::Cash) {
                $fresh = $payment->fresh(['order.table']);
                DB::afterCommit(function () use ($fresh, $user) {
                    app(AdminNotificationService::class)->notifyPaymentConfirmed($fresh, $user);
                });
            }

            return $payment->fresh();
        });
    }

    public function confirm(Payment $payment, ?User $user = null, array $payload = []): Payment
    {
        if ($payment->status === PaymentStatus::Paid) {
            return $payment;
        }

        if (in_array($payment->status, [PaymentStatus::Refunded, PaymentStatus::Cancelled, PaymentStatus::Failed], true)) {
            throw new InvalidArgumentException('Pagamento não pode ser confirmado no status atual: '.$payment->status->value);
        }

        return DB::transaction(function () use ($payment, $user, $payload) {
            /** @var Payment $locked */
            $locked = Payment::query()->whereKey($payment->id)->lockForUpdate()->firstOrFail();

            if ($locked->status === PaymentStatus::Paid) {
                return $locked;
            }

            $old = $locked->only(['status', 'transaction_reference', 'paid_at']);
            $result = $this->gateway->confirm($locked, $payload);

            $locked->status = $result->status;
            $locked->transaction_reference = $result->transactionReference ?? $locked->transaction_reference;
            $locked->metadata = array_merge($locked->metadata ?? [], $result->metadata, [
                'confirmed_by' => $user?->id,
            ]);
            $becamePaid = false;
            if ($result->isPaid()) {
                $locked->paid_at = now();
                $becamePaid = true;
            }
            $locked->save();

            if ($locked->isPaid()) {
                app(\App\Services\Cash\CashService::class)->recordSalePayment($locked, $user);
            }

            $this->audit->log('PAYMENT_UPDATED', $locked, $old, $locked->only(['status', 'transaction_reference', 'paid_at']), $user);
            event(new PaymentUpdated($locked->fresh()));

            if ($becamePaid && $locked->isPaid()) {
                $fresh = $locked->fresh(['order.table']);
                DB::afterCommit(function () use ($fresh, $user) {
                    app(AdminNotificationService::class)->notifyPaymentConfirmed($fresh, $user);
                });
            }

            return $locked->fresh();
        });
    }

    public function refund(Payment $payment, ?User $user = null): Payment
    {
        if ($payment->status !== PaymentStatus::Paid) {
            throw new InvalidArgumentException('Somente pagamentos pagos podem ser estornados.');
        }

        return DB::transaction(function () use ($payment, $user) {
            /** @var Payment $locked */
            $locked = Payment::query()->whereKey($payment->id)->lockForUpdate()->firstOrFail();
            if ($locked->status !== PaymentStatus::Paid) {
                throw new InvalidArgumentException('Somente pagamentos pagos podem ser estornados.');
            }

            $old = $locked->only(['status']);
            $locked->status = PaymentStatus::Refunded;
            $locked->metadata = array_merge($locked->metadata ?? [], [
                'refunded_at' => now()->toIso8601String(),
                'refunded_by' => $user?->id,
            ]);
            $locked->save();

            $this->audit->log('PAYMENT_UPDATED', $locked, $old, $locked->only(['status']), $user);
            event(new PaymentUpdated($locked->fresh()));

            return $locked->fresh();
        });
    }

    public function cancel(Payment $payment, ?User $user = null): Payment
    {
        if ($payment->status === PaymentStatus::Paid) {
            throw new InvalidArgumentException('Pagamento pago deve ser estornado, não cancelado.');
        }

        if ($payment->status === PaymentStatus::Cancelled) {
            return $payment;
        }

        return DB::transaction(function () use ($payment, $user) {
            /** @var Payment $locked */
            $locked = Payment::query()->whereKey($payment->id)->lockForUpdate()->firstOrFail();
            $old = $locked->only(['status']);
            $locked->status = PaymentStatus::Cancelled;
            $locked->metadata = array_merge($locked->metadata ?? [], [
                'cancelled_at' => now()->toIso8601String(),
                'cancelled_by' => $user?->id,
            ]);
            $locked->save();

            $this->audit->log('PAYMENT_UPDATED', $locked, $old, $locked->only(['status']), $user);
            event(new PaymentUpdated($locked->fresh()));

            return $locked->fresh();
        });
    }
}
