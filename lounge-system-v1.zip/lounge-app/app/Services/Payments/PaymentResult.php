<?php

namespace App\Services\Payments;

use App\Enums\PaymentStatus;

final class PaymentResult
{
    /**
     * @param  array<string, mixed>  $metadata
     */
    public function __construct(
        public readonly PaymentStatus $status,
        public readonly ?string $transactionReference = null,
        public readonly array $metadata = [],
        public readonly ?string $message = null,
    ) {}

    public function isPaid(): bool
    {
        return $this->status === PaymentStatus::Paid;
    }
}
