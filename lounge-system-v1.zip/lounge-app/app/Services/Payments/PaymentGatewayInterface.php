<?php

namespace App\Services\Payments;

use App\Models\Order;
use App\Models\Payment;

/**
 * Contract for future payment gateway integrations (PIX / cards).
 * Implementations must never mark a payment as paid without a real confirmation path.
 */
interface PaymentGatewayInterface
{
    /**
     * Initiate a payment for the given order.
     *
     * @param  array<string, mixed>  $options
     */
    public function initiate(Order $order, Payment $payment, array $options = []): PaymentResult;

    /**
     * Confirm / capture a payment (webhook or manual confirmation).
     *
     * @param  array<string, mixed>  $payload
     */
    public function confirm(Payment $payment, array $payload = []): PaymentResult;

    public function driver(): string;
}
