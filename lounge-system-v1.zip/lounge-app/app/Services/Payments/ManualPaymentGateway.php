<?php

namespace App\Services\Payments;

use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\Payment;

/**
 * MANUAL / TEST gateway — NOT a real acquirer integration.
 *
 * - CASH: marked PAID when cash is handed over (change validated in PaymentService).
 * - PIX / CARD: AWAITING_CONFIRMATION until staff confirms receipt in the panel.
 *
 * This deliberately does NOT pretend a card was charged or a PIX was settled
 * by an external PSP. Replace with PixGateway/CardGateway implementations later.
 */
class ManualPaymentGateway implements PaymentGatewayInterface
{
    public function initiate(Order $order, Payment $payment, array $options = []): PaymentResult
    {
        return match ($payment->method) {
            PaymentMethod::Cash => new PaymentResult(
                status: PaymentStatus::Paid,
                transactionReference: 'CASH-MANUAL-'.now()->format('YmdHis').'-'.$payment->id,
                metadata: [
                    'mode' => 'manual_test',
                    'real_capture' => false,
                    'amount_received' => $payment->amount_received,
                    'change_amount' => $payment->change_amount,
                ],
                message: 'Pagamento em dinheiro registrado (manual).',
            ),
            PaymentMethod::Pix => new PaymentResult(
                status: PaymentStatus::AwaitingConfirmation,
                transactionReference: 'PIX-MANUAL-'.$payment->id,
                metadata: [
                    'mode' => 'manual_test',
                    'real_capture' => false,
                    'note' => 'PIX não integrado a PSP. Confirme manualmente após receber o comprovante.',
                ],
                message: 'PIX aguardando confirmação manual.',
            ),
            PaymentMethod::CreditCard, PaymentMethod::DebitCard => new PaymentResult(
                status: PaymentStatus::AwaitingConfirmation,
                transactionReference: 'CARD-MANUAL-'.$payment->id,
                metadata: [
                    'mode' => 'manual_test',
                    'real_capture' => false,
                    'note' => 'Cartão não integrado a adquirente. Confirme manualmente após TEF/maquininha.',
                    'card_type' => $payment->method->value,
                ],
                message: 'Cartão aguardando confirmação manual.',
            ),
        };
    }

    public function confirm(Payment $payment, array $payload = []): PaymentResult
    {
        return new PaymentResult(
            status: PaymentStatus::Paid,
            transactionReference: $payment->transaction_reference ?? 'MANUAL-CONFIRMED-'.$payment->id,
            metadata: array_merge($payment->metadata ?? [], [
                'confirmed_manually' => true,
                'real_capture' => false,
                'confirmed_at' => now()->toIso8601String(),
            ], $payload),
            message: 'Pagamento confirmado manualmente (sem captura externa).',
        );
    }

    public function driver(): string
    {
        return 'manual';
    }
}
