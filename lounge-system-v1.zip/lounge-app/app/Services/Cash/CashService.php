<?php

namespace App\Services\Cash;

use App\Enums\CashMovementType;
use App\Enums\CashRegisterStatus;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\CashMovement;
use App\Models\CashRegister;
use App\Models\Payment;
use App\Models\User;
use App\Services\Audit\AuditService;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class CashService
{
    public function __construct(private readonly AuditService $audit) {}

    public function currentOpen(): ?CashRegister
    {
        return CashRegister::query()
            ->where('status', CashRegisterStatus::Open->value)
            ->latest('opened_at')
            ->first();
    }

    public function open(int $openingAmountCents, User $user, ?string $notes = null): CashRegister
    {
        return DB::transaction(function () use ($openingAmountCents, $user, $notes) {
            // Cross-DB advisory lock (MySQL GET_LOCK / PostgreSQL pg_advisory_xact_lock)
            $this->acquireOpenLock();

            try {
                if ($this->currentOpen()) {
                    throw new RuntimeException('Já existe um caixa aberto.');
                }

                if ($openingAmountCents < 0) {
                    throw new RuntimeException('Valor de abertura inválido.');
                }

                $register = CashRegister::create([
                    'opened_by' => $user->id,
                    'opened_at' => now(),
                    'opening_amount' => $openingAmountCents,
                    'status' => CashRegisterStatus::Open->value,
                    'notes' => $notes,
                ]);

                if ($openingAmountCents > 0) {
                    CashMovement::create([
                        'cash_register_id' => $register->id,
                        'type' => CashMovementType::Deposit->value,
                        'payment_method' => PaymentMethod::Cash->value,
                        'amount' => $openingAmountCents,
                        'description' => 'Abertura de caixa',
                        'user_id' => $user->id,
                    ]);
                }

                $this->audit->log('CASH_REGISTER_OPENED', $register, null, [
                    'opening_amount' => $register->opening_amount,
                    'opened_by' => $user->id,
                ], $user);

                return $register->fresh('movements');
            } finally {
                $this->releaseOpenLock();
            }
        });
    }

    private function acquireOpenLock(): void
    {
        $driver = DB::getDriverName();

        if ($driver === 'pgsql') {
            // Transaction-scoped lock; released automatically on commit/rollback
            DB::select('SELECT pg_advisory_xact_lock(?)', [88442211]);

            return;
        }

        if (in_array($driver, ['mysql', 'mariadb'], true)) {
            $gotLock = DB::selectOne('SELECT GET_LOCK(?, 5) AS l', ['lounge_cash_open']);
            if (! $gotLock || (int) $gotLock->l !== 1) {
                throw new RuntimeException('Não foi possível obter lock de abertura de caixa. Tente novamente.');
            }

            return;
        }

        // sqlite/testing: rely on transaction + currentOpen check
    }

    private function releaseOpenLock(): void
    {
        $driver = DB::getDriverName();

        if (in_array($driver, ['mysql', 'mariadb'], true)) {
            DB::select('SELECT RELEASE_LOCK(?)', ['lounge_cash_open']);
        }
        // pgsql advisory_xact_lock is released with the transaction
    }

    public function close(int $closingAmountCents, User $user, ?string $notes = null): CashRegister
    {
        return DB::transaction(function () use ($closingAmountCents, $user, $notes) {
            if ($closingAmountCents < 0) {
                throw new RuntimeException('Valor de fechamento inválido.');
            }

            $register = $this->currentOpen();
            if (! $register) {
                throw new RuntimeException('Não há caixa aberto.');
            }

            /** @var CashRegister $locked */
            $locked = CashRegister::query()->whereKey($register->id)->lockForUpdate()->firstOrFail();

            if ($locked->status !== CashRegisterStatus::Open) {
                throw new RuntimeException('Caixa já está fechado.');
            }

            $summary = $this->buildSummary($locked);
            $expectedCash = $summary['expected_cash'];

            $locked->closed_by = $user->id;
            $locked->closed_at = now();
            $locked->closing_amount = $closingAmountCents;
            $locked->expected_amount = $expectedCash;
            $locked->difference = $closingAmountCents - $expectedCash;
            $locked->status = CashRegisterStatus::Closed->value;
            $locked->summary = $summary;
            if ($notes) {
                $locked->notes = trim(($locked->notes ? $locked->notes."\n" : '').$notes);
            }
            $locked->save();

            $this->audit->log('CASH_REGISTER_CLOSED', $locked, null, [
                'expected_amount' => $locked->expected_amount,
                'closing_amount' => $locked->closing_amount,
                'difference' => $locked->difference,
                'summary' => $summary,
            ], $user);

            return $locked->fresh('movements');
        });
    }

    public function recordSalePayment(Payment $payment, ?User $user = null): ?CashMovement
    {
        $register = $this->currentOpen();
        if (! $register) {
            return null;
        }

        if ($payment->status !== PaymentStatus::Paid) {
            return null;
        }

        // Prevent duplicate sale movements for the same payment
        $exists = CashMovement::query()
            ->where('reference_type', Payment::class)
            ->where('reference_id', $payment->id)
            ->where('type', CashMovementType::Sale->value)
            ->exists();

        if ($exists) {
            return null;
        }

        $payment->loadMissing('order');

        return CashMovement::create([
            'cash_register_id' => $register->id,
            'type' => CashMovementType::Sale->value,
            'payment_method' => $payment->method->value,
            'amount' => (int) $payment->amount,
            'description' => 'Venda pedido #'.($payment->order?->order_number ?? $payment->order_id),
            'user_id' => $user?->id,
            'reference_type' => Payment::class,
            'reference_id' => $payment->id,
        ]);
    }

    public function recordRefundPayment(Payment $payment, ?User $user = null): ?CashMovement
    {
        $register = $this->currentOpen();
        if (! $register) {
            return null;
        }

        $exists = CashMovement::query()
            ->where('reference_type', Payment::class)
            ->where('reference_id', $payment->id)
            ->where('type', CashMovementType::Refund->value)
            ->exists();

        if ($exists) {
            return null;
        }

        $payment->loadMissing('order');

        return CashMovement::create([
            'cash_register_id' => $register->id,
            'type' => CashMovementType::Refund->value,
            'payment_method' => $payment->method->value,
            'amount' => -abs((int) $payment->amount),
            'description' => 'Estorno pedido #'.($payment->order?->order_number ?? $payment->order_id),
            'user_id' => $user?->id,
            'reference_type' => Payment::class,
            'reference_id' => $payment->id,
        ]);
    }

    public function addMovement(
        CashMovementType $type,
        int $amountCents,
        User $user,
        ?string $description = null,
        ?PaymentMethod $method = null,
    ): CashMovement {
        return DB::transaction(function () use ($type, $amountCents, $user, $description, $method) {
            $register = $this->currentOpen();
            if (! $register) {
                throw new RuntimeException('Não há caixa aberto.');
            }

            /** @var CashRegister $locked */
            $locked = CashRegister::query()->whereKey($register->id)->lockForUpdate()->firstOrFail();
            if (! $locked->isOpen()) {
                throw new RuntimeException('Caixa não está aberto.');
            }

            if ($amountCents === 0) {
                throw new RuntimeException('Valor da movimentação não pode ser zero.');
            }

            $signed = match ($type) {
                CashMovementType::Sale, CashMovementType::Deposit => abs($amountCents),
                CashMovementType::Refund, CashMovementType::Expense, CashMovementType::Withdrawal => -abs($amountCents),
                CashMovementType::Adjustment => $amountCents,
            };

            $movement = CashMovement::create([
                'cash_register_id' => $locked->id,
                'type' => $type->value,
                'payment_method' => $method?->value ?? PaymentMethod::Cash->value,
                'amount' => $signed,
                'description' => $description,
                'user_id' => $user->id,
            ]);

            $this->audit->log('CASH_MOVEMENT_CREATED', $movement, null, $movement->toArray(), $user);

            return $movement;
        });
    }

    /**
     * @return array<string, mixed>
     */
    public function buildSummary(CashRegister $register): array
    {
        $movements = $register->movements()->get();

        $byMethod = [
            PaymentMethod::Cash->value => 0,
            PaymentMethod::Pix->value => 0,
            PaymentMethod::CreditCard->value => 0,
            PaymentMethod::DebitCard->value => 0,
        ];

        $sales = 0;
        $refunds = 0;
        $expenses = 0;
        $withdrawals = 0;
        $extraDeposits = 0;

        foreach ($movements as $m) {
            $method = $m->payment_method instanceof PaymentMethod
                ? $m->payment_method->value
                : (string) ($m->payment_method ?? PaymentMethod::Cash->value);

            if (! isset($byMethod[$method])) {
                $byMethod[$method] = 0;
            }

            $type = $m->type instanceof CashMovementType ? $m->type : CashMovementType::from((string) $m->type);
            $amount = (int) $m->amount;

            match ($type) {
                CashMovementType::Sale => tap(null, function () use (&$sales, &$byMethod, $method, $amount) {
                    $sales += $amount;
                    $byMethod[$method] += $amount;
                }),
                CashMovementType::Refund => tap(null, function () use (&$refunds, &$byMethod, $method, $amount) {
                    $refunds += abs($amount);
                    $byMethod[$method] -= abs($amount);
                }),
                CashMovementType::Expense => $expenses += abs($amount),
                CashMovementType::Withdrawal => $withdrawals += abs($amount),
                CashMovementType::Deposit => tap(null, function () use (&$extraDeposits, $m, $amount) {
                    if ($m->description !== 'Abertura de caixa') {
                        $extraDeposits += $amount;
                    }
                }),
                default => null,
            };
        }

        $cashSalesNet = (int) ($byMethod[PaymentMethod::Cash->value] ?? 0);

        // Drawer expected = opening + net cash sales (already net of cash refunds in byMethod)
        // + extra deposits - expenses - withdrawals
        // Note: cash refunds already reduced byMethod[CASH]
        $expectedCash = (int) $register->opening_amount
            + $cashSalesNet
            - $expenses
            - $withdrawals
            + $extraDeposits;

        // For display, separate gross cash sales
        $grossCashSales = $movements
            ->filter(fn ($m) => ($m->type instanceof CashMovementType ? $m->type : CashMovementType::from((string) $m->type)) === CashMovementType::Sale)
            ->filter(function ($m) {
                $method = $m->payment_method instanceof PaymentMethod
                    ? $m->payment_method->value
                    : (string) $m->payment_method;

                return $method === PaymentMethod::Cash->value;
            })
            ->sum(fn ($m) => (int) $m->amount);

        return [
            'opening_amount' => (int) $register->opening_amount,
            'sales_total' => $sales,
            'refunds_total' => $refunds,
            'expenses_total' => $expenses,
            'withdrawals_total' => $withdrawals,
            'deposits_total' => $extraDeposits,
            'by_method' => $byMethod,
            'expected_cash' => $expectedCash,
            'pix' => (int) ($byMethod[PaymentMethod::Pix->value] ?? 0),
            'credit_card' => (int) ($byMethod[PaymentMethod::CreditCard->value] ?? 0),
            'debit_card' => (int) ($byMethod[PaymentMethod::DebitCard->value] ?? 0),
            'cash' => (int) $grossCashSales,
        ];
    }
}
