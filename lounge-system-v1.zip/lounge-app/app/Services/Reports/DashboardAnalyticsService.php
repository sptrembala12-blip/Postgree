<?php

namespace App\Services\Reports;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Support\Money;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;

/**
 * Extended analytics for Admin Mini PWA dashboard.
 * All money from backend cents; frontend must not recompute.
 */
class DashboardAnalyticsService
{
    public function __construct(private readonly ReportService $reports) {}

    /**
     * @return array<string, mixed>
     */
    public function full(?string $preset = 'today', ?string $from = null, ?string $to = null): array
    {
        $primary = $this->reports->dashboard($preset, $from, $to);
        $tz = config('lounge.timezone', config('app.timezone', 'America/Sao_Paulo'));

        return array_merge($primary, [
            'snapshots' => [
                'today' => $this->snapshot('today'),
                'month' => $this->snapshot('month'),
                '30d' => $this->snapshot('30d'),
                '3m' => $this->snapshot('3m'),
            ],
            'series' => $this->salesSeries($preset, $from, $to),
            'top_products' => $this->reports->productsReport(
                $primary['period']['from'],
                Carbon::parse($primary['period']['to'])->toDateString(),
            ),
            'recent_payments' => $this->recentPaidPayments(8),
            'server_time' => Carbon::now($tz)->toIso8601String(),
            'server_date_label' => Carbon::now($tz)->translatedFormat('d \d\e F \d\e Y'),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public function snapshot(string $key): array
    {
        $period = match ($key) {
            'month' => $this->monthPeriod(),
            '30d' => $this->reports->resolvePeriod('30d'),
            '3m' => $this->reports->resolvePeriod('3m'),
            default => $this->reports->resolvePeriod('today'),
        };

        $received = $this->sumPaid($period['from'], $period['to']);
        $awaiting = $this->sumAwaiting($period['from'], $period['to']);
        $sales = $this->sumSales($period['from'], $period['to']);
        $orders = $this->countBillableOrders($period['from'], $period['to']);
        $ticket = $orders > 0 ? (int) intdiv($sales, $orders) : 0;
        $byMethod = $this->paidByMethod($period['from'], $period['to']);

        return [
            'key' => $key,
            'from' => $period['from']->toDateTimeString(),
            'to' => $period['to']->toDateTimeString(),
            'received' => $received,
            'received_formatted' => Money::format($received),
            'awaiting' => $awaiting,
            'awaiting_formatted' => Money::format($awaiting),
            'sales' => $sales,
            'sales_formatted' => Money::format($sales),
            'orders_count' => $orders,
            'average_ticket' => $ticket,
            'average_ticket_formatted' => Money::format($ticket),
            'by_method' => $byMethod,
            'by_method_formatted' => [
                'PIX' => Money::format($byMethod['PIX'] ?? 0),
                'CREDIT_CARD' => Money::format($byMethod['CREDIT_CARD'] ?? 0),
                'DEBIT_CARD' => Money::format($byMethod['DEBIT_CARD'] ?? 0),
                'CASH' => Money::format($byMethod['CASH'] ?? 0),
            ],
        ];
    }

    /**
     * @return array{from:Carbon,to:Carbon}
     */
    private function monthPeriod(): array
    {
        $tz = config('lounge.timezone', config('app.timezone', 'America/Sao_Paulo'));
        $now = Carbon::now($tz);

        return [
            'from' => $now->copy()->startOfMonth()->startOfDay(),
            'to' => $now->copy()->endOfDay(),
        ];
    }

    private function sumPaid(Carbon $from, Carbon $to): int
    {
        return (int) Payment::query()
            ->where('status', PaymentStatus::Paid->value)
            ->where(function ($q) use ($from, $to) {
                $q->whereBetween('paid_at', [$from, $to])
                    ->orWhere(function ($q2) use ($from, $to) {
                        $q2->whereNull('paid_at')->whereBetween('created_at', [$from, $to]);
                    });
            })
            ->sum('amount');
    }

    private function sumAwaiting(Carbon $from, Carbon $to): int
    {
        return (int) Payment::query()
            ->where('status', PaymentStatus::AwaitingConfirmation->value)
            ->whereBetween('created_at', [$from, $to])
            ->sum('amount');
    }

    private function sumSales(Carbon $from, Carbon $to): int
    {
        return (int) Order::query()
            ->billable()
            ->whereBetween('created_at', [$from, $to])
            ->sum('total');
    }

    private function countBillableOrders(Carbon $from, Carbon $to): int
    {
        return (int) Order::query()
            ->billable()
            ->whereBetween('created_at', [$from, $to])
            ->count();
    }

    /**
     * @return array<string,int>
     */
    private function paidByMethod(Carbon $from, Carbon $to): array
    {
        $rows = Payment::query()
            ->select('method', DB::raw('SUM(amount) as total'))
            ->where('status', PaymentStatus::Paid->value)
            ->where(function ($q) use ($from, $to) {
                $q->whereBetween('paid_at', [$from, $to])
                    ->orWhere(function ($q2) use ($from, $to) {
                        $q2->whereNull('paid_at')->whereBetween('created_at', [$from, $to]);
                    });
            })
            ->groupBy('method')
            ->get();

        $out = ['PIX' => 0, 'CREDIT_CARD' => 0, 'DEBIT_CARD' => 0, 'CASH' => 0];
        foreach ($rows as $row) {
            $key = $row->method instanceof \BackedEnum ? $row->method->value : (string) $row->method;
            $out[$key] = (int) $row->total;
        }

        return $out;
    }

    /**
     * @return list<array{label:string,date:string,received:int,received_formatted:string,orders:int}>
     */
    public function salesSeries(?string $preset = '7d', ?string $from = null, ?string $to = null): array
    {
        $period = $this->reports->resolvePeriod($preset === 'today' ? '7d' : ($preset ?: '7d'), $from, $to);
        if ($preset === 'today') {
            $period = $this->reports->resolvePeriod('today');
        }
        if ($preset === 'month') {
            $period = $this->monthPeriod();
        }

        $start = $period['from']->copy()->startOfDay();
        $end = $period['to']->copy()->startOfDay();
        // For multi-day, build daily buckets
        if ($start->equalTo($end) || $preset === 'today') {
            // hourly today
            $points = [];
            $day = $period['from']->copy()->startOfDay();
            for ($h = 0; $h < 24; $h++) {
                $f = $day->copy()->setTime($h, 0);
                $t = $day->copy()->setTime($h, 59, 59);
                if ($t->gt($period['to'])) {
                    $t = $period['to']->copy();
                }
                if ($f->gt($period['to'])) {
                    break;
                }
                $recv = $this->sumPaid($f, $t);
                $points[] = [
                    'label' => sprintf('%02dh', $h),
                    'date' => $f->toDateString(),
                    'received' => $recv,
                    'received_formatted' => Money::format($recv),
                    'orders' => $this->countBillableOrders($f, $t),
                ];
            }

            return $points;
        }

        $points = [];
        foreach (CarbonPeriod::create($start, '1 day', $end) as $day) {
            /** @var Carbon $day */
            $f = $day->copy()->startOfDay();
            $t = $day->copy()->endOfDay();
            $recv = $this->sumPaid($f, $t);
            $points[] = [
                'label' => $day->translatedFormat('D d/m'),
                'date' => $day->toDateString(),
                'received' => $recv,
                'received_formatted' => Money::format($recv),
                'orders' => $this->countBillableOrders($f, $t),
            ];
        }

        return $points;
    }

    /**
     * @return list<array<string,mixed>>
     */
    public function recentPaidPayments(int $limit = 10): array
    {
        return Payment::query()
            ->with(['order.table'])
            ->where('status', PaymentStatus::Paid->value)
            ->latest('paid_at')
            ->limit($limit)
            ->get()
            ->map(function (Payment $p) {
                return [
                    'id' => $p->id,
                    'method' => $p->method->value,
                    'method_label' => $p->method->label(),
                    'amount' => (int) $p->amount,
                    'amount_formatted' => Money::format((int) $p->amount),
                    'order_id' => $p->order_id,
                    'order_number' => $p->order?->order_number,
                    'display_number' => $p->order ? '#'.$p->order->order_number : null,
                    'table' => $p->order?->table?->number,
                    'paid_at' => $p->paid_at?->toIso8601String(),
                    'paid_human' => $p->paid_at?->diffForHumans(),
                ];
            })
            ->all();
    }
}
