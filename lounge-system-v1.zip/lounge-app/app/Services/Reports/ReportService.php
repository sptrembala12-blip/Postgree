<?php

namespace App\Services\Reports;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Enums\TableStatus;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Table;
use App\Support\Money;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ReportService
{
    /**
     * @return array{from:Carbon,to:Carbon}
     */
    public function resolvePeriod(?string $preset = null, ?string $from = null, ?string $to = null): array
    {
        $tz = config('lounge.timezone', config('app.timezone', 'America/Sao_Paulo'));
        $now = Carbon::now($tz);

        if ($from && $to) {
            return [
                'from' => Carbon::parse($from, $tz)->startOfDay(),
                'to' => Carbon::parse($to, $tz)->endOfDay(),
            ];
        }

        return match ($preset) {
            '7d', '7_days' => ['from' => $now->copy()->subDays(6)->startOfDay(), 'to' => $now->copy()->endOfDay()],
            '30d', '30_days' => ['from' => $now->copy()->subDays(29)->startOfDay(), 'to' => $now->copy()->endOfDay()],
            '3m', '3_months' => ['from' => $now->copy()->subMonthsNoOverflow(3)->startOfDay(), 'to' => $now->copy()->endOfDay()],
            default => ['from' => $now->copy()->startOfDay(), 'to' => $now->copy()->endOfDay()],
        };
    }

    /**
     * @return array<string, mixed>
     */
    public function dashboard(?string $preset = 'today', ?string $from = null, ?string $to = null): array
    {
        $period = $this->resolvePeriod($preset, $from, $to);

        // Vendas = pedidos billable (operação)
        $orders = Order::query()
            ->billable()
            ->whereBetween('created_at', [$period['from'], $period['to']]);

        $sales = (int) (clone $orders)->sum('total');
        $ordersCount = (clone $orders)->count();
        $ticket = $ordersCount > 0 ? (int) intdiv($sales, $ordersCount) : 0;

        $productsSold = (int) OrderItem::query()
            ->whereHas('order', function ($q) use ($period) {
                $q->billable()->whereBetween('created_at', [$period['from'], $period['to']]);
            })
            ->sum('quantity');

        // Recebido = apenas pagamentos PAID
        $paidRows = Payment::query()
            ->where('status', PaymentStatus::Paid->value)
            ->where(function ($q) use ($period) {
                $q->whereBetween('paid_at', [$period['from'], $period['to']])
                    ->orWhere(function ($q2) use ($period) {
                        $q2->whereNull('paid_at')
                            ->whereBetween('created_at', [$period['from'], $period['to']]);
                    });
            })
            ->select('method', DB::raw('SUM(amount) as total'), DB::raw('COUNT(*) as cnt'))
            ->groupBy('method')
            ->get();

        $receivedByMethod = [
            'PIX' => 0,
            'CREDIT_CARD' => 0,
            'DEBIT_CARD' => 0,
            'CASH' => 0,
        ];
        $received = 0;
        foreach ($paidRows as $row) {
            $key = $row->method instanceof \BackedEnum ? $row->method->value : (string) $row->method;
            $receivedByMethod[$key] = (int) $row->total;
            $received += (int) $row->total;
        }

        // Aguardando confirmação (PIX/cartão manuais)
        $awaiting = (int) Payment::query()
            ->where('status', PaymentStatus::AwaitingConfirmation->value)
            ->whereBetween('created_at', [$period['from'], $period['to']])
            ->sum('amount');

        $awaitingCount = (int) Payment::query()
            ->where('status', PaymentStatus::AwaitingConfirmation->value)
            ->whereBetween('created_at', [$period['from'], $period['to']])
            ->count();

        return [
            'period' => [
                'from' => $period['from']->toDateTimeString(),
                'to' => $period['to']->toDateTimeString(),
                'preset' => $preset,
            ],
            // backward-compatible keys
            'revenue' => $received,
            'revenue_formatted' => Money::format($received),
            'sales' => $sales,
            'sales_formatted' => Money::format($sales),
            'received' => $received,
            'received_formatted' => Money::format($received),
            'awaiting' => $awaiting,
            'awaiting_formatted' => Money::format($awaiting),
            'awaiting_count' => $awaitingCount,
            'orders_count' => $ordersCount,
            'average_ticket' => $ticket,
            'average_ticket_formatted' => Money::format($ticket),
            'products_sold' => $productsSold,
            'tables' => [
                'occupied' => Table::query()->where('status', TableStatus::Occupied->value)->count(),
                'available' => Table::query()->where('status', TableStatus::Available->value)->where('is_active', true)->count(),
                'total_active' => Table::query()->where('is_active', true)->count(),
            ],
            'payments' => $receivedByMethod,
            'payments_formatted' => [
                'PIX' => Money::format($receivedByMethod['PIX'] ?? 0),
                'CREDIT_CARD' => Money::format($receivedByMethod['CREDIT_CARD'] ?? 0),
                'DEBIT_CARD' => Money::format($receivedByMethod['DEBIT_CARD'] ?? 0),
                'CASH' => Money::format($receivedByMethod['CASH'] ?? 0),
            ],
            'low_stock_products' => Product::query()->lowStock()->active()->count(),
            'pending_orders' => Order::query()->where('status', OrderStatus::Pending->value)->count(),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function productsReport(?string $from = null, ?string $to = null, ?int $productId = null, ?int $categoryId = null): array
    {
        $period = $this->resolvePeriod(null, $from ?? now()->startOfDay()->toDateString(), $to ?? now()->toDateString());

        // Faturamento de produto = itens de pedidos billable com pagamento PAID (quando existir payment)
        $query = OrderItem::query()
            ->select([
                'order_items.product_id',
                'order_items.product_name_snapshot',
                DB::raw('SUM(order_items.quantity) as quantity_sold'),
                DB::raw('SUM(order_items.subtotal) as revenue'),
                DB::raw('AVG(order_items.unit_price) as avg_unit_price'),
            ])
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->whereIn('orders.status', OrderStatus::billableValues())
            ->whereBetween('orders.created_at', [$period['from'], $period['to']])
            ->whereExists(function ($q) {
                $q->select(DB::raw(1))
                    ->from('payments')
                    ->whereColumn('payments.order_id', 'orders.id')
                    ->where('payments.status', PaymentStatus::Paid->value);
            })
            ->groupBy('order_items.product_id', 'order_items.product_name_snapshot')
            ->orderByDesc('revenue');

        if ($productId) {
            $query->where('order_items.product_id', $productId);
        }

        if ($categoryId) {
            $query->join('products', 'products.id', '=', 'order_items.product_id')
                ->where('products.category_id', $categoryId);
        }

        return $query->get()->map(function ($row) {
            return [
                'product_id' => $row->product_id,
                'product_name' => $row->product_name_snapshot,
                'quantity_sold' => (int) $row->quantity_sold,
                'avg_unit_price' => (int) round((float) $row->avg_unit_price),
                'avg_unit_price_formatted' => Money::format((int) round((float) $row->avg_unit_price)),
                'revenue' => (int) $row->revenue,
                'revenue_formatted' => Money::format((int) $row->revenue),
            ];
        })->all();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function categoriesReport(?string $from = null, ?string $to = null): array
    {
        $period = $this->resolvePeriod(null, $from ?? now()->startOfDay()->toDateString(), $to ?? now()->toDateString());

        $rows = OrderItem::query()
            ->select([
                'categories.id as category_id',
                'categories.name as category_name',
                DB::raw('SUM(order_items.quantity) as quantity_sold'),
                DB::raw('SUM(order_items.subtotal) as revenue'),
            ])
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->leftJoin('products', 'products.id', '=', 'order_items.product_id')
            ->leftJoin('categories', 'categories.id', '=', 'products.category_id')
            ->whereIn('orders.status', OrderStatus::billableValues())
            ->whereBetween('orders.created_at', [$period['from'], $period['to']])
            ->whereExists(function ($q) {
                $q->select(DB::raw(1))
                    ->from('payments')
                    ->whereColumn('payments.order_id', 'orders.id')
                    ->where('payments.status', PaymentStatus::Paid->value);
            })
            ->groupBy('categories.id', 'categories.name')
            ->orderByDesc('revenue')
            ->get();

        return $rows->map(fn ($row) => [
            'category_id' => $row->category_id,
            'category_name' => $row->category_name ?? 'Sem categoria',
            'quantity_sold' => (int) $row->quantity_sold,
            'revenue' => (int) $row->revenue,
            'revenue_formatted' => Money::format((int) $row->revenue),
        ])->all();
    }

    /**
     * @return array<string, mixed>
     */
    public function paymentsReport(?string $from = null, ?string $to = null): array
    {
        $period = $this->resolvePeriod(null, $from ?? now()->startOfDay()->toDateString(), $to ?? now()->toDateString());

        $rows = Payment::query()
            ->select('method', DB::raw('SUM(amount) as total'), DB::raw('COUNT(*) as count'))
            ->where('status', PaymentStatus::Paid->value)
            ->where(function ($q) use ($period) {
                $q->whereBetween('paid_at', [$period['from'], $period['to']])
                    ->orWhere(function ($q2) use ($period) {
                        $q2->whereNull('paid_at')
                            ->whereBetween('created_at', [$period['from'], $period['to']]);
                    });
            })
            ->groupBy('method')
            ->get();

        $methods = [];
        $grand = 0;
        foreach ($rows as $row) {
            $total = (int) $row->total;
            $grand += $total;
            $methodKey = $row->method instanceof \BackedEnum ? $row->method->value : (string) $row->method;
            $methods[$methodKey] = [
                'method' => $methodKey,
                'count' => (int) $row->count,
                'total' => $total,
                'total_formatted' => Money::format($total),
            ];
        }

        $awaiting = (int) Payment::query()
            ->where('status', PaymentStatus::AwaitingConfirmation->value)
            ->whereBetween('created_at', [$period['from'], $period['to']])
            ->sum('amount');

        return [
            'methods' => $methods,
            'total' => $grand,
            'total_formatted' => Money::format($grand),
            'awaiting' => $awaiting,
            'awaiting_formatted' => Money::format($awaiting),
            'period' => [
                'from' => $period['from']->toDateTimeString(),
                'to' => $period['to']->toDateTimeString(),
            ],
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function tablesReport(?string $from = null, ?string $to = null): array
    {
        $period = $this->resolvePeriod(null, $from ?? now()->startOfDay()->toDateString(), $to ?? now()->toDateString());

        $rows = Order::query()
            ->select([
                'tables.id as table_id',
                'tables.number as table_number',
                'tables.name as table_name',
                DB::raw('COUNT(orders.id) as orders_count'),
                DB::raw('SUM(orders.total) as consumption'),
            ])
            ->join('tables', 'tables.id', '=', 'orders.table_id')
            ->whereIn('orders.status', OrderStatus::billableValues())
            ->whereBetween('orders.created_at', [$period['from'], $period['to']])
            ->groupBy('tables.id', 'tables.number', 'tables.name')
            ->orderByDesc('consumption')
            ->get();

        return $rows->map(fn ($row) => [
            'table_id' => $row->table_id,
            'table_number' => $row->table_number,
            'table_name' => $row->table_name,
            'orders_count' => (int) $row->orders_count,
            'consumption' => (int) $row->consumption,
            'consumption_formatted' => Money::format((int) $row->consumption),
        ])->all();
    }
}
