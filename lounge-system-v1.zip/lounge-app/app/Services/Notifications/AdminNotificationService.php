<?php

namespace App\Services\Notifications;

use App\Enums\PaymentMethod;
use App\Events\PaymentConfirmed;
use App\Models\AdminNotification;
use App\Models\Payment;
use App\Models\User;
use App\Services\Audit\AuditService;
use App\Support\Money;
use Illuminate\Support\Facades\DB;

class AdminNotificationService
{
    public function __construct(private readonly AuditService $audit) {}

    /**
     * Create payment-confirmed notification idempotently (one per payment).
     */
    public function notifyPaymentConfirmed(Payment $payment, ?User $actor = null): ?AdminNotification
    {
        $payment->loadMissing(['order.table']);

        if (! $payment->isPaid()) {
            return null;
        }

        $dedupe = 'payment_confirmed:'.$payment->id;

        return DB::transaction(function () use ($payment, $actor, $dedupe) {
            $existing = AdminNotification::query()->where('dedupe_key', $dedupe)->lockForUpdate()->first();
            if ($existing) {
                return $existing;
            }

            $order = $payment->order;
            $method = $payment->method;
            $amount = (int) $payment->amount;
            $amountFmt = Money::format($amount);

            [$title, $message] = $this->paymentCopy($method, $amount, $payment);

            $notification = AdminNotification::create([
                'type' => 'payment_confirmed',
                'title' => $title,
                'message' => $message,
                'dedupe_key' => $dedupe,
                'user_id' => null,
                'actor_id' => $actor?->id,
                'order_id' => $order?->id,
                'payment_id' => $payment->id,
                'payment_method' => $method->value,
                'amount' => $amount,
                'amount_received' => $payment->amount_received,
                'change_amount' => $payment->change_amount,
                'table_number' => $order?->table?->number,
                'order_number' => $order?->order_number,
                'data' => [
                    'confirmed_by' => $actor?->id,
                    'confirmed_by_name' => $actor?->name,
                ],
            ]);

            $this->audit->log('PAYMENT_CONFIRMED', $payment, null, [
                'payment_id' => $payment->id,
                'order_id' => $order?->id,
                'method' => $method->value,
                'amount' => $amount,
                'notification_id' => $notification->id,
                'actor_id' => $actor?->id,
            ], $actor);

            event(new PaymentConfirmed($payment->fresh(['order.table']), $notification));

            return $notification;
        });
    }

    /**
     * @return array{0:string,1:string}
     */
    private function paymentCopy(PaymentMethod $method, int $amount, Payment $payment): array
    {
        $fmt = Money::format($amount);

        return match ($method) {
            PaymentMethod::Pix => [
                'Pagamento aprovado',
                "Pagamento aprovado no PIX — {$fmt}",
            ],
            PaymentMethod::CreditCard => [
                'Pagamento aprovado',
                "Pagamento aprovado no crédito — {$fmt}",
            ],
            PaymentMethod::DebitCard => [
                'Pagamento aprovado',
                "Pagamento aprovado no débito — {$fmt}",
            ],
            PaymentMethod::Cash => $this->cashCopy($payment, $fmt),
        };
    }

    /**
     * @return array{0:string,1:string}
     */
    private function cashCopy(Payment $payment, string $amountFmt): array
    {
        $title = 'Pagamento recebido';
        if ($payment->amount_received && (int) $payment->change_amount > 0) {
            $recv = Money::format((int) $payment->amount_received);
            $chg = Money::format((int) $payment->change_amount);
            $message = "Pagamento recebido em dinheiro — {$recv} | Troco: {$chg}";
        } else {
            $message = "Pagamento recebido em dinheiro — {$amountFmt}";
        }

        return [$title, $message];
    }

    public function unreadCount(?User $user = null): int
    {
        return AdminNotification::query()->whereNull('read_at')->count();
    }

    public function markRead(AdminNotification $notification): AdminNotification
    {
        $notification->markRead();

        return $notification->fresh();
    }

    public function markAllRead(): int
    {
        return AdminNotification::query()->whereNull('read_at')->update(['read_at' => now()]);
    }
}
