<?php

namespace App\Services\Inventory;

use App\Enums\InventoryMovementType;
use App\Events\InventoryUpdated;
use App\Models\InventoryMovement;
use App\Models\Product;
use App\Models\User;
use App\Services\Audit\AuditService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use RuntimeException;

class InventoryService
{
    public function __construct(private readonly AuditService $audit) {}

    /**
     * Apply a stock movement with row lock to avoid race conditions.
     */
    public function move(
        Product $product,
        InventoryMovementType $type,
        int $quantity,
        ?string $reason = null,
        ?User $user = null,
        ?Model $reference = null,
    ): InventoryMovement {
        if ($quantity === 0) {
            throw new InvalidArgumentException('Quantidade da movimentação não pode ser zero.');
        }

        return DB::transaction(function () use ($product, $type, $quantity, $reason, $user, $reference) {
            /** @var Product $locked */
            $locked = Product::query()->whereKey($product->id)->lockForUpdate()->firstOrFail();

            if (! $locked->stock_control_enabled) {
                throw new RuntimeException("Produto {$locked->name} não controla estoque.");
            }

            $previous = (int) $locked->current_stock;
            $delta = $this->resolveDelta($type, $quantity);
            $newStock = $previous + $delta;

            if ($newStock < 0 && ! config('lounge.allow_negative_stock', false)) {
                throw new RuntimeException(
                    "Estoque insuficiente para {$locked->name}. Disponível: {$previous}, solicitado: ".abs($delta)
                );
            }

            $locked->current_stock = $newStock;
            $locked->save();

            $movement = InventoryMovement::create([
                'product_id' => $locked->id,
                'type' => $type->value,
                'quantity' => $delta,
                'previous_stock' => $previous,
                'new_stock' => $newStock,
                'reason' => $reason,
                'user_id' => $user?->id,
                'reference_type' => $reference ? $reference::class : null,
                'reference_id' => $reference?->getKey(),
            ]);

            $this->audit->log('STOCK_ADJUSTED', $locked, [
                'current_stock' => $previous,
            ], [
                'current_stock' => $newStock,
                'type' => $type->value,
                'delta' => $delta,
                'reason' => $reason,
            ], $user);

            event(new InventoryUpdated($locked->fresh(), $movement));

            return $movement;
        });
    }

    public function purchase(Product $product, int $quantity, ?string $reason = null, ?User $user = null): InventoryMovement
    {
        return $this->move($product, InventoryMovementType::Purchase, abs($quantity), $reason ?? 'Entrada de mercadoria', $user);
    }

    public function sale(Product $product, int $quantity, ?Model $reference = null, ?User $user = null): InventoryMovement
    {
        return $this->move($product, InventoryMovementType::Sale, abs($quantity), 'Venda', $user, $reference);
    }

    public function loss(Product $product, int $quantity, ?string $reason = null, ?User $user = null): InventoryMovement
    {
        return $this->move($product, InventoryMovementType::Loss, abs($quantity), $reason ?? 'Perda', $user);
    }

    public function returnStock(Product $product, int $quantity, ?string $reason = null, ?User $user = null, ?Model $reference = null): InventoryMovement
    {
        return $this->move($product, InventoryMovementType::Return, abs($quantity), $reason ?? 'Devolução', $user, $reference);
    }

    public function adjustment(Product $product, int $signedQuantity, ?string $reason = null, ?User $user = null): InventoryMovement
    {
        return $this->move($product, InventoryMovementType::Adjustment, $signedQuantity, $reason ?? 'Ajuste de estoque', $user);
    }

    /**
     * Ensure product has enough stock for quantity (with lock).
     */
    public function assertAvailable(Product $product, int $quantity): void
    {
        if (! $product->stock_control_enabled) {
            return;
        }

        if (config('lounge.allow_negative_stock', false)) {
            return;
        }

        /** @var Product $locked */
        $locked = Product::query()->whereKey($product->id)->lockForUpdate()->firstOrFail();

        if ($locked->current_stock < $quantity) {
            throw new RuntimeException(
                "Estoque insuficiente para {$locked->name}. Disponível: {$locked->current_stock}, solicitado: {$quantity}"
            );
        }
    }

    private function resolveDelta(InventoryMovementType $type, int $quantity): int
    {
        return match ($type->direction()) {
            'in' => abs($quantity),
            'out' => -abs($quantity),
            'signed' => $quantity,
        };
    }
}
