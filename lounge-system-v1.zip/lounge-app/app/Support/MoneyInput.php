<?php

namespace App\Support;

/**
 * Helpers to convert form money inputs (R$) into cents for persistence.
 */
final class MoneyInput
{
    private function __construct() {}

    /**
     * Accepts reais string ("58,00", "58.00", "R$ 58,00") or already-cents integer-like.
     * If value looks like cents-only integer without decimal and $assumeReais is true, treat as reais.
     */
    public static function toCents(mixed $value, bool $assumeReaisWhenPlain = true): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_int($value)) {
            return $assumeReaisWhenPlain ? $value * 100 : $value;
        }

        $raw = trim((string) $value);

        // Already looks like cents field from API (only digits, large, no decimal separators) when flagged
        if (! $assumeReaisWhenPlain && preg_match('/^\d+$/', $raw)) {
            return (int) $raw;
        }

        return Money::ofReais($raw);
    }
}
