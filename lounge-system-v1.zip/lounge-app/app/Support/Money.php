<?php

namespace App\Support;

use InvalidArgumentException;

/**
 * Money helper — all monetary values are stored and calculated in cents (integer).
 * Never use float for currency arithmetic.
 */
final class Money
{
    private function __construct() {}

    /**
     * Parse human input into cents without floating binary math on the stored path.
     * Accepts: 58, "58", "58.00", "58,00", "R$ 58,00", "1.234,56"
     */
    public static function ofReais(int|string $reais): int
    {
        if (is_int($reais)) {
            return $reais * 100;
        }

        $raw = trim($reais);
        $raw = str_replace(['R$', ' '], '', $raw);

        if ($raw === '' || ! preg_match('/^-?[0-9.,]+$/', $raw)) {
            throw new InvalidArgumentException("Valor monetário inválido: {$reais}");
        }

        // Brazilian format 1.234,56 vs 1234.56
        if (str_contains($raw, ',') && str_contains($raw, '.')) {
            $raw = str_replace('.', '', $raw);
            $raw = str_replace(',', '.', $raw);
        } elseif (str_contains($raw, ',')) {
            $raw = str_replace(',', '.', $raw);
        }

        if (! preg_match('/^-?\d+(\.\d{1,2})?$/', $raw)) {
            // more than 2 decimals — reject rather than silently round-trip via float
            if (preg_match('/^-?\d+\.\d{3,}$/', $raw)) {
                throw new InvalidArgumentException('Use no máximo 2 casas decimais.');
            }
            throw new InvalidArgumentException("Valor monetário inválido: {$reais}");
        }

        $negative = str_starts_with($raw, '-');
        $raw = ltrim($raw, '-');
        [$whole, $frac] = array_pad(explode('.', $raw, 2), 2, '0');
        $frac = str_pad(substr($frac, 0, 2), 2, '0');
        $cents = ((int) $whole) * 100 + (int) $frac;

        return $negative ? -$cents : $cents;
    }

    public static function toDecimalString(int $cents): string
    {
        $sign = $cents < 0 ? '-' : '';
        $abs = abs($cents);

        return $sign.sprintf('%d.%02d', intdiv($abs, 100), $abs % 100);
    }

    public static function format(int $cents, string $currency = 'R$'): string
    {
        $sign = $cents < 0 ? '-' : '';
        $abs = abs($cents);

        return sprintf('%s%s %s', $sign, $currency, number_format($abs / 100, 2, ',', '.'));
    }

    public static function add(int ...$amounts): int
    {
        $sum = 0;
        foreach ($amounts as $amount) {
            $sum += $amount;
        }

        return $sum;
    }

    public static function subtract(int $a, int $b): int
    {
        return $a - $b;
    }

    public static function multiply(int $cents, int $quantity): int
    {
        if ($quantity < 0) {
            throw new InvalidArgumentException('Quantidade não pode ser negativa.');
        }

        return $cents * $quantity;
    }

    public static function percent(int $cents, int $basisPoints): int
    {
        // basisPoints: 1000 = 10.00% — integer division toward zero
        return intdiv($cents * $basisPoints, 10000);
    }

    /**
     * @return array{amount:int, amount_received:int, change_amount:int}
     */
    public static function calculateChange(int $amount, int $amountReceived): array
    {
        if ($amount <= 0) {
            throw new InvalidArgumentException('Valor do pedido deve ser maior que zero.');
        }

        if ($amountReceived < 0) {
            throw new InvalidArgumentException('Valores monetários não podem ser negativos.');
        }

        if ($amountReceived < $amount) {
            throw new InvalidArgumentException(
                sprintf(
                    'Valor recebido (%s) é menor que o total do pedido (%s).',
                    self::format($amountReceived),
                    self::format($amount)
                )
            );
        }

        return [
            'amount' => $amount,
            'amount_received' => $amountReceived,
            'change_amount' => $amountReceived - $amount,
        ];
    }

    public static function assertPositive(int $cents, string $label = 'Valor'): void
    {
        if ($cents <= 0) {
            throw new InvalidArgumentException("{$label} deve ser maior que zero.");
        }
    }

    public static function zero(): int
    {
        return 0;
    }
}
