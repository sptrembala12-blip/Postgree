<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\Table;
use App\Services\Orders\CartService;
use App\Services\Orders\OrderService;
use App\Support\Money;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    public function __construct(
        private readonly CartService $carts,
        private readonly OrderService $orders,
    ) {}

    public function tableByNumber(string $number)
    {
        $table = Table::where('number', $number)->where('is_active', true)->firstOrFail();

        return $this->menu($table);
    }

    public function tableByToken(string $token)
    {
        $table = Table::where('qr_token', $token)->where('is_active', true)->firstOrFail();

        return $this->menu($table);
    }

    public function index()
    {
        return $this->menu(null);
    }

    private function menu(?Table $table)
    {
        $categories = Category::active()
            ->with(['products' => fn ($q) => $q->active()->with('primaryImage')->orderBy('sort_order')->orderBy('name')])
            ->orderBy('sort_order')
            ->get();

        $cart = $this->resolveCart($table);
        $summary = $this->carts->summarize($cart);

        return view('menu.index', compact('table', 'categories', 'summary', 'cart'));
    }

    public function product(Request $request, string $slug)
    {
        $product = Product::query()
            ->active()
            ->where('slug', $slug)
            ->with(['category', 'images', 'primaryImage'])
            ->firstOrFail();

        $table = null;
        if ($request->filled('table')) {
            $table = Table::where('number', $request->string('table'))->where('is_active', true)->first();
        } elseif ($request->filled('t')) {
            $table = Table::where('qr_token', $request->string('t'))->where('is_active', true)->first();
        } elseif (session('menu_table_id')) {
            $table = Table::find(session('menu_table_id'));
        }

        $cart = $this->resolveCart($table);
        $summary = $this->carts->summarize($cart);

        return view('menu.product', compact('product', 'table', 'summary', 'cart'));
    }

    public function cartPage(Request $request)
    {
        $table = $this->tableFromSession();
        $cart = $this->resolveCart($table);
        $summary = $this->carts->summarize($cart);

        return view('menu.cart', compact('table', 'summary', 'cart'));
    }

    public function addToCart(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'quantity' => ['sometimes', 'integer', 'min:1', 'max:99'],
            'table_id' => ['nullable', 'exists:tables,id'],
        ]);

        $table = ! empty($data['table_id']) ? Table::find($data['table_id']) : $this->tableFromSession();
        $cart = $this->resolveCart($table);

        try {
            $this->carts->addItem($cart, (int) $data['product_id'], (int) ($data['quantity'] ?? 1));
        } catch (\Throwable $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }

        if ($request->boolean('go_cart')) {
            return redirect()->route('menu.cart')->with('success', 'Item adicionado.');
        }

        return back()->with('success', 'Item adicionado ao carrinho.');
    }

    public function updateCart(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer'],
            'quantity' => ['required', 'integer', 'min:0', 'max:99'],
        ]);
        $cart = $this->resolveCart($this->tableFromSession());

        try {
            $this->carts->updateQuantity($cart, (int) $data['product_id'], (int) $data['quantity']);
        } catch (\Throwable $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Carrinho atualizado.');
    }

    public function checkoutForm()
    {
        $table = $this->tableFromSession();
        $cart = $this->resolveCart($table);
        $summary = $this->carts->summarize($cart);
        if (empty($summary['items'])) {
            return redirect()->route('menu.index')->withErrors(['error' => 'Carrinho vazio.']);
        }
        $tables = Table::active()->orderBy('number')->get();

        return view('menu.checkout', compact('summary', 'cart', 'tables', 'table'));
    }

    public function checkout(Request $request)
    {
        $data = $request->validate([
            'table_id' => ['nullable', 'exists:tables,id'],
            'customer_name' => ['nullable', 'string', 'max:255'],
            'notes' => ['nullable', 'string', 'max:1000'],
            'payment_method' => ['required', 'in:PIX,CREDIT_CARD,DEBIT_CARD,CASH'],
            'amount_received_reais' => ['nullable', 'string'],
            'need_change' => ['nullable', 'boolean'],
        ]);

        $table = ! empty($data['table_id'])
            ? Table::find($data['table_id'])
            : $this->tableFromSession();

        $cart = $this->resolveCart($table);
        $summary = $this->carts->summarize($cart);
        if (empty($summary['items'])) {
            return redirect()->route('menu.index')->withErrors(['error' => 'Carrinho vazio.']);
        }

        $amountReceived = null;
        if ($data['payment_method'] === 'CASH') {
            if ($request->boolean('need_change')) {
                if (empty($data['amount_received_reais'])) {
                    return back()->withErrors(['amount_received_reais' => 'Informe o valor para troco.'])->withInput();
                }
                try {
                    $amountReceived = Money::ofReais($data['amount_received_reais']);
                } catch (\Throwable $e) {
                    return back()->withErrors(['amount_received_reais' => $e->getMessage()])->withInput();
                }
            } else {
                $amountReceived = $summary['total'];
            }
        }

        try {
            $order = $this->orders->create([
                'table_id' => $table?->id,
                'customer_name' => $data['customer_name'] ?? null,
                'notes' => $data['notes'] ?? null,
                'payment_method' => $data['payment_method'],
                'amount_received' => $amountReceived,
                'cart_token' => session('cart_token'),
            ]);
        } catch (\Throwable $e) {
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }

        session()->forget('cart_token');
        session(['last_order_number' => $order->order_number]);

        return redirect()->route('menu.order', $order->order_number)
            ->with('success', 'Pedido realizado!');
    }

    public function orderStatus(int $orderNumber)
    {
        $order = Order::with(['items', 'payment', 'table'])
            ->where('order_number', $orderNumber)
            ->firstOrFail();

        return view('menu.order', compact('order'));
    }

    /**
     * Lightweight JSON poll for customer order tracking.
     */
    public function orderStatusJson(int $orderNumber)
    {
        $order = Order::with(['payment', 'table'])
            ->where('order_number', $orderNumber)
            ->firstOrFail();

        $payment = $order->payment;

        return response()->json([
            'order_number' => $order->order_number,
            'status' => $order->status->value,
            'status_label' => $order->status->label(),
            'payment_method' => $payment?->method?->value,
            'payment_status' => $payment?->status?->value,
            'payment_status_label' => $payment?->status?->label(),
            'total_formatted' => $order->formattedTotal(),
            'table' => $order->table?->number,
            'updated_at' => $order->updated_at?->toIso8601String(),
        ]);
    }

    private function resolveCart(?Table $table)
    {
        if ($table) {
            session(['menu_table_id' => $table->id]);
        }
        $cart = $this->carts->getOrCreate(session('cart_token'), $table ?? $this->tableFromSession());
        session(['cart_token' => $cart->token]);

        return $cart;
    }

    private function tableFromSession(): ?Table
    {
        $id = session('menu_table_id');

        return $id ? Table::whereKey($id)->where('is_active', true)->first() : null;
    }
}
