<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

class IntegrationsController extends Controller
{
    public function index()
    {
        $integrations = [
            [
                'key' => 'pix_auto',
                'title' => 'PIX automático',
                'status' => 'EM BREVE',
                'description' => 'Receba pagamentos PIX automaticamente através de um gateway. Confirmação instantânea sem ação manual do atendente.',
            ],
            [
                'key' => 'card_auto',
                'title' => 'Cartão automático',
                'status' => 'EM BREVE',
                'description' => 'Integração futura com adquirentes/TEF para crédito e débito com captura real.',
            ],
            [
                'key' => 'print',
                'title' => 'Impressão de comandas',
                'status' => 'EM BREVE',
                'description' => 'Impressão automática de pedidos e comandas em impressoras térmicas da rede.',
            ],
        ];

        return view('admin.integrations.index', compact('integrations'));
    }
}
