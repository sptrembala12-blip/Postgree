<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminNotification;
use App\Services\Notifications\AdminNotificationService;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function __construct(private readonly AdminNotificationService $notifications) {}

    public function index(Request $request)
    {
        $type = $request->string('type')->toString();
        $query = AdminNotification::query()->latest();

        if ($type && $type !== 'all') {
            if ($type === 'payments') {
                $query->where('type', 'payment_confirmed');
            } else {
                $query->where('type', $type);
            }
        }

        $notifications = $query->paginate(30)->withQueryString();
        $unread = $this->notifications->unreadCount($request->user());

        return view('admin.notifications.index', compact('notifications', 'unread', 'type'));
    }

    public function markRead(Request $request, AdminNotification $notification)
    {
        $this->notifications->markRead($notification);

        if ($request->wantsJson()) {
            return response()->json(['ok' => true, 'data' => $notification->fresh()->toApiArray()]);
        }

        if ($notification->order_id) {
            return redirect()->route('admin.orders.show', $notification->order_id);
        }

        return back()->with('success', 'Notificação marcada como lida.');
    }

    public function markAllRead(Request $request)
    {
        $count = $this->notifications->markAllRead();

        if ($request->wantsJson()) {
            return response()->json(['ok' => true, 'marked' => $count]);
        }

        return back()->with('success', 'Todas as notificações foram marcadas como lidas.');
    }
}
