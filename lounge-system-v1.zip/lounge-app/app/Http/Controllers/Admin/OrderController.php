<?php

namespace App\Http\Controllers\Admin;

use App\Enums\OrderStatus;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Table;
use App\Services\Orders\OrderService;
use App\Services\Payments\PaymentService;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function __construct(
        private readonly OrderService $orders,
        private readonly PaymentService $payments,
    ) {}

    public function index(Request $request)
    {
        $query = Order::query()->with(['items', 'payment', 'table'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }
        if ($request->filled('table_id')) {
            $query->where('table_id', $request->integer('table_id'));
        }
        if ($request->filled('order_number')) {
            $query->where('order_number', $request->integer('order_number'));
        }
        if ($request->filled('payment_method')) {
            $query->whereHas('payment', fn ($q) => $q->where('method', $request->string('payment_method')));
        }

        $orders = $query->paginate(20)->withQueryString();
        $tables = Table::query()->orderBy('number')->get();
        $statuses = OrderStatus::cases();

        return view('admin.orders.index', compact('orders', 'tables', 'statuses'));
    }

    public function show(Order $order)
    {
        $order->load(['items.product', 'payment', 'table', 'tableSession']);

        return view('admin.orders.show', compact('order'));
    }

    public function transition(Request $request, Order $order, string $action)
    {
        $user = $request->user();

        if ($action === 'cancel') {
            if (! $user->isAdmin() && ! $user->hasPermission('orders.cancel')) {
                abort(403, 'Sem permissão para cancelar pedidos.');
            }
        } elseif ($action === 'confirm-payment') {
            if (! $user->isAdmin() && ! $user->hasPermission('payments.confirm')) {
                abort(403, 'Sem permissão para confirmar pagamentos.');
            }
        } elseif (! $user->isAdmin() && ! $user->hasPermission('orders.manage')) {
            abort(403, 'Sem permissão para gerenciar pedidos.');
        }

        try {
            match ($action) {
                'confirm' => $this->orders->confirm($order, $user),
                'prepare' => $this->orders->startPreparing($order, $user),
                'ready' => $this->orders->markReady($order, $user),
                'deliver' => $this->orders->markDelivered($order, $user),
                'complete' => $this->orders->complete($order, $user),
                'cancel' => $this->orders->cancel($order, $user, $request->input('reason')),
                'confirm-payment' => tap($order, function (Order $o) use ($user) {
                    if ($o->payment) {
                        $this->payments->confirm($o->payment, $user);
                    }
                }),
                default => abort(404),
            };
        } catch (\Throwable $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Pedido atualizado.');
    }
}
