<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (Auth::check()) {
            return redirect()->to($this->homeFor(Auth::user()));
        }

        return view('admin.auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (! Auth::attempt($credentials, $request->boolean('remember'))) {
            return back()->withErrors(['email' => 'Credenciais inválidas.'])->onlyInput('email');
        }

        $request->session()->regenerate();

        if (! Auth::user()->is_active) {
            Auth::logout();

            return back()->withErrors(['email' => 'Usuário inativo.']);
        }

        return redirect()->intended($this->homeFor(Auth::user()));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login');
    }

    private function homeFor($user): string
    {
        if ($user->isAdmin() || $user->hasRole('manager')) {
            return route('admin.dashboard');
        }

        if ($user->hasRole('attendant') || $user->hasRole('cashier')) {
            return route('attendant.dashboard');
        }

        if ($user->hasPermission('dashboard.view')) {
            return route('admin.dashboard');
        }

        if ($user->hasPermission('orders.view')) {
            return route('attendant.dashboard');
        }

        return route('admin.dashboard');
    }
}
