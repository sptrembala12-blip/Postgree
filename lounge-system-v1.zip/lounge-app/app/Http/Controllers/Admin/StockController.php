<?php

namespace App\Http\Controllers\Admin;

use App\Enums\InventoryMovementType;
use App\Http\Controllers\Controller;
use App\Models\InventoryMovement;
use App\Models\Product;
use App\Services\Inventory\InventoryService;
use Illuminate\Http\Request;

class StockController extends Controller
{
    public function __construct(private readonly InventoryService $inventory) {}

    public function index(Request $request)
    {
        $query = Product::query()->where('stock_control_enabled', true)->with('category')->orderBy('name');
        if ($request->boolean('low_stock')) {
            $query->lowStock();
        }
        $products = $query->paginate(30)->withQueryString();
        $movements = InventoryMovement::with(['product', 'user'])->latest()->limit(20)->get();

        return view('admin.stock.index', compact('products', 'movements'));
    }

    public function move(Request $request)
    {
        $data = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'type' => ['required', 'in:PURCHASE,LOSS,RETURN,ADJUSTMENT'],
            'quantity' => ['required', 'integer', 'not_in:0'],
            'reason' => ['nullable', 'string', 'max:500'],
        ]);

        $product = Product::findOrFail($data['product_id']);
        $type = InventoryMovementType::from($data['type']);
        $qty = (int) $data['quantity'];
        $user = $request->user();
        $reason = $data['reason'] ?? null;

        match ($type) {
            InventoryMovementType::Purchase => $this->inventory->purchase($product, $qty, $reason, $user),
            InventoryMovementType::Loss => $this->inventory->loss($product, $qty, $reason, $user),
            InventoryMovementType::Return => $this->inventory->returnStock($product, $qty, $reason, $user),
            InventoryMovementType::Adjustment => $this->inventory->adjustment($product, $qty, $reason, $user),
            default => null,
        };

        return back()->with('success', 'Movimentação registrada.');
    }
}
