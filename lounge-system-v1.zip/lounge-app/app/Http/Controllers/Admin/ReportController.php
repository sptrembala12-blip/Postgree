<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Reports\ReportService;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function __construct(private readonly ReportService $reports) {}

    public function index(Request $request)
    {
        $from = $request->input('from', now()->startOfMonth()->toDateString());
        $to = $request->input('to', now()->toDateString());

        return view('admin.reports.index', [
            'from' => $from,
            'to' => $to,
            'products' => $this->reports->productsReport($from, $to),
            'categories' => $this->reports->categoriesReport($from, $to),
            'payments' => $this->reports->paymentsReport($from, $to),
            'tables' => $this->reports->tablesReport($from, $to),
        ]);
    }
}
