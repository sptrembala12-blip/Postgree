<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Category\StoreCategoryRequest;
use App\Http\Requests\Category\UpdateCategoryRequest;
use App\Models\Category;
use App\Services\Audit\AuditService;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function __construct(private readonly AuditService $audit) {}

    public function index()
    {
        $categories = Category::query()->withCount('products')->orderBy('sort_order')->orderBy('name')->get();

        return view('admin.categories.index', compact('categories'));
    }

    public function create()
    {
        return view('admin.categories.form', ['category' => new Category]);
    }

    public function store(StoreCategoryRequest $request)
    {
        $data = $request->safe()->except('image');
        if (empty($data['slug'])) {
            $data['slug'] = Category::uniqueSlug($data['name']);
        }
        $category = Category::create($data);
        $this->audit->log('CATEGORY_CREATED', $category, null, $category->toArray(), $request->user());

        return redirect()->route('admin.categories.index')->with('success', 'Categoria criada.');
    }

    public function edit(Category $category)
    {
        return view('admin.categories.form', compact('category'));
    }

    public function update(UpdateCategoryRequest $request, Category $category)
    {
        $old = $category->toArray();
        $category->fill($request->safe()->except('image'))->save();
        $this->audit->log('CATEGORY_UPDATED', $category, $old, $category->toArray(), $request->user());

        return redirect()->route('admin.categories.index')->with('success', 'Categoria atualizada.');
    }

    public function destroy(Request $request, Category $category)
    {
        if ($category->products()->exists()) {
            return back()->withErrors(['error' => 'Categoria possui produtos.']);
        }
        $this->audit->log('CATEGORY_DELETED', $category, $category->toArray(), null, $request->user());
        $category->delete();

        return back()->with('success', 'Categoria excluída.');
    }
}
