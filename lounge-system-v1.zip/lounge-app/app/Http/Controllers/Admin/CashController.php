<?php

namespace App\Http\Controllers\Admin;

use App\Enums\CashMovementType;
use App\Http\Controllers\Controller;
use App\Models\CashRegister;
use App\Services\Cash\CashService;
use Illuminate\Http\Request;

class CashController extends Controller
{
    public function __construct(private readonly CashService $cash) {}

    public function index()
    {
        $register = $this->cash->currentOpen();
        $summary = $register ? $this->cash->buildSummary($register) : null;
        $history = CashRegister::with(['openedBy', 'closedBy'])->latest('opened_at')->limit(15)->get();

        return view('admin.cash.index', compact('register', 'summary', 'history'));
    }

    public function open(Request $request)
    {
        $data = $request->validate([
            'opening_amount' => ['required', 'integer', 'min:0'],
            'notes' => ['nullable', 'string'],
        ]);

        $this->cash->open((int) $data['opening_amount'], $request->user(), $data['notes'] ?? null);

        return back()->with('success', 'Caixa aberto.');
    }

    public function close(Request $request)
    {
        $data = $request->validate([
            'closing_amount' => ['required', 'integer', 'min:0'],
            'notes' => ['nullable', 'string'],
        ]);

        $register = $this->cash->close((int) $data['closing_amount'], $request->user(), $data['notes'] ?? null);

        return back()->with('success', 'Caixa fechado. Diferença: '.$register->difference.' centavos.');
    }

    public function movement(Request $request)
    {
        $data = $request->validate([
            'type' => ['required', 'in:EXPENSE,WITHDRAWAL,DEPOSIT,ADJUSTMENT'],
            'amount' => ['required', 'integer', 'not_in:0'],
            'description' => ['nullable', 'string'],
        ]);

        $this->cash->addMovement(
            CashMovementType::from($data['type']),
            (int) $data['amount'],
            $request->user(),
            $data['description'] ?? null
        );

        return back()->with('success', 'Movimentação de caixa registrada.');
    }
}
