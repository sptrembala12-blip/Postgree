<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Services\Notifications\AdminNotificationService;
use App\Services\Reports\DashboardAnalyticsService;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __construct(
        private readonly DashboardAnalyticsService $analytics,
        private readonly AdminNotificationService $notifications,
    ) {}

    public function index(Request $request)
    {
        $period = $request->input('period', 'today');
        $from = $request->input('from');
        $to = $request->input('to');

        $data = $this->analytics->full($period, $from, $to);
        $recentOrders = Order::query()->with(['table', 'payment'])->latest()->limit(8)->get();
        $lowStock = Product::query()->lowStock()->active()->orderBy('current_stock')->limit(8)->get();
        $unread = $this->notifications->unreadCount($request->user());
        $topProducts = array_slice($data['top_products'] ?? [], 0, 8);

        return view('admin.dashboard.index', compact(
            'data',
            'recentOrders',
            'lowStock',
            'period',
            'unread',
            'topProducts',
            'from',
            'to',
        ));
    }
}
