<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Table\StoreTableRequest;
use App\Http\Requests\Table\UpdateTableRequest;
use App\Models\Table;
use App\Services\Tables\TableService;
use Illuminate\Http\Request;

class TableController extends Controller
{
    public function __construct(private readonly TableService $tables) {}

    public function index()
    {
        $tables = Table::query()->with(['currentSession.orders'])->orderBy('number')->get();

        return view('admin.tables.index', compact('tables'));
    }

    public function create()
    {
        return view('admin.tables.form', ['table' => new Table]);
    }

    public function store(StoreTableRequest $request)
    {
        $this->tables->create($request->validated(), $request->user());

        return redirect()->route('admin.tables.index')->with('success', 'Mesa criada.');
    }

    public function show(Table $table)
    {
        $table->load(['currentSession.orders.items', 'currentSession.orders.payment', 'sessions' => fn ($q) => $q->latest()->limit(10)]);
        $session = $table->currentSession;
        $orders = $session
            ? $session->orders()->with(['items', 'payment'])->latest()->get()
            : collect();

        return view('admin.tables.show', compact('table', 'session', 'orders'));
    }

    public function edit(Table $table)
    {
        return view('admin.tables.form', compact('table'));
    }

    public function update(UpdateTableRequest $request, Table $table)
    {
        $this->tables->update($table, $request->validated(), $request->user());

        return redirect()->route('admin.tables.index')->with('success', 'Mesa atualizada.');
    }

    public function qrcode(Table $table)
    {
        if (! $table->qr_code_path) {
            $this->tables->generateQrCode($table);
            $table->refresh();
        }

        return view('admin.tables.qrcode', compact('table'));
    }

    public function regenerateQr(Request $request, Table $table)
    {
        $this->tables->regenerateQr($table, $request->user());

        return back()->with('success', 'QR Code regenerado.');
    }

    public function openSession(Request $request, Table $table)
    {
        $this->tables->openSession($table, $request->user());

        return back()->with('success', 'Sessão aberta.');
    }

    public function closeSession(Request $request, Table $table)
    {
        $session = $table->currentSession;
        if (! $session) {
            return back()->withErrors(['error' => 'Nenhuma sessão aberta.']);
        }
        $this->tables->closeSession($session, $request->user());

        return back()->with('success', 'Sessão encerrada. Total: '.\App\Support\Money::format((int) $session->fresh()->total_amount));
    }
}
