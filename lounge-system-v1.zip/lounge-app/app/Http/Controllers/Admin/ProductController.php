<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\StoreProductRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use App\Services\Audit\AuditService;
use App\Support\MoneyInput;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    public function __construct(private readonly AuditService $audit) {}

    public function index(Request $request)
    {
        $query = Product::query()->with(['category', 'primaryImage'])->orderBy('name');

        if ($request->filled('q')) {
            $query->where('name', 'like', '%'.$request->string('q').'%');
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->integer('category_id'));
        }

        $products = $query->paginate(20)->withQueryString();
        $categories = Category::orderBy('name')->get();

        return view('admin.products.index', compact('products', 'categories'));
    }

    public function create()
    {
        $categories = Category::orderBy('name')->get();

        return view('admin.products.form', ['product' => new Product, 'categories' => $categories]);
    }

    public function store(StoreProductRequest $request)
    {
        $data = $request->safe()->except(['image', 'price', 'promotional_price', 'price_cents', 'promotional_price_cents']);
        $data = $this->normalizeBooleans($request, $data);
        $data = array_merge($data, $this->moneyFromRequest($request));

        if (empty($data['slug'])) {
            $data['slug'] = Product::uniqueSlug($data['name']);
        }
        $product = Product::create($data);

        if ($request->hasFile('image')) {
            $this->storeImage($product, $request->file('image'));
        }

        $this->audit->log('PRODUCT_CREATED', $product, null, $product->toArray(), $request->user());

        return redirect()->route('admin.products.index')->with('success', 'Produto criado.');
    }

    public function edit(Product $product)
    {
        $categories = Category::orderBy('name')->get();
        $product->load('images');

        return view('admin.products.form', compact('product', 'categories'));
    }

    public function update(UpdateProductRequest $request, Product $product)
    {
        $old = $product->toArray();
        $data = $request->safe()->except(['image', 'price', 'promotional_price', 'price_cents', 'promotional_price_cents']);
        $data = $this->normalizeBooleans($request, $data);
        $data = array_merge($data, $this->moneyFromRequest($request, true));

        if (isset($data['price']) && (int) $data['price'] !== (int) $product->price) {
            $this->audit->log('PRICE_CHANGED', $product, ['price' => $product->price], ['price' => $data['price']], $request->user());
        }

        $product->fill($data)->save();

        if ($request->hasFile('image')) {
            $this->storeImage($product, $request->file('image'), true);
        }

        $this->audit->log('PRODUCT_UPDATED', $product, $old, $product->toArray(), $request->user());

        return redirect()->route('admin.products.index')->with('success', 'Produto atualizado.');
    }

    public function destroy(Request $request, Product $product)
    {
        if ($product->orderItems()->exists()) {
            $product->update(['is_active' => false]);

            return back()->with('success', 'Produto desativado (possui histórico).');
        }

        $this->audit->log('PRODUCT_DELETED', $product, $product->toArray(), null, $request->user());
        $product->delete();

        return back()->with('success', 'Produto excluído.');
    }

    /**
     * @return array<string, mixed>
     */
    private function moneyFromRequest(Request $request, bool $partial = false): array
    {
        $out = [];

        if ($request->filled('price_cents')) {
            $out['price'] = (int) $request->input('price_cents');
        } elseif ($request->filled('price') || ! $partial) {
            $out['price'] = MoneyInput::toCents($request->input('price'), true) ?? 0;
        }

        if ($request->filled('promotional_price_cents')) {
            $out['promotional_price'] = (int) $request->input('promotional_price_cents');
        } elseif ($request->exists('promotional_price')) {
            $val = $request->input('promotional_price');
            $out['promotional_price'] = ($val === null || $val === '')
                ? null
                : MoneyInput::toCents($val, true);
        }

        return $out;
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    private function normalizeBooleans(Request $request, array $data): array
    {
        foreach (['stock_control_enabled', 'is_active', 'is_featured'] as $field) {
            $data[$field] = $request->boolean($field);
        }

        return $data;
    }

    private function storeImage(Product $product, $file, bool $replace = false): void
    {
        $path = $file->storeAs('products/'.$product->id, Str::uuid().'.'.$file->getClientOriginalExtension(), 'public');
        if ($replace) {
            $product->images()->where('is_primary', true)->update(['is_primary' => false]);
        }
        ProductImage::create([
            'product_id' => $product->id,
            'path' => $path,
            'original_name' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'size' => $file->getSize(),
            'is_primary' => true,
        ]);
    }
}
