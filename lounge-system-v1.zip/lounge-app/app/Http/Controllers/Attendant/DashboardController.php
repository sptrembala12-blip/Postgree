<?php

namespace App\Http\Controllers\Attendant;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Table;
use App\Services\Orders\OrderService;
use App\Services\Payments\PaymentService;
use App\Services\Tables\TableService;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __construct(
        private readonly OrderService $orders,
        private readonly PaymentService $payments,
        private readonly TableService $tables,
    ) {}

    public function index(Request $request)
    {
        $active = Order::query()
            ->with(['items', 'payment', 'table'])
            ->whereNotIn('status', [OrderStatus::Completed->value, OrderStatus::Cancelled->value])
            ->latest()
            ->limit(80)
            ->get();

        $byStatus = [
            'PENDING' => $active->where('status', OrderStatus::Pending),
            'CONFIRMED' => $active->where('status', OrderStatus::Confirmed),
            'PREPARING' => $active->where('status', OrderStatus::Preparing),
            'READY' => $active->where('status', OrderStatus::Ready),
            'DELIVERED' => $active->where('status', OrderStatus::Delivered),
        ];

        $awaitingPayment = Order::query()
            ->with(['items', 'payment', 'table'])
            ->whereHas('payment', fn ($q) => $q->where('status', PaymentStatus::AwaitingConfirmation->value))
            ->whereNotIn('status', [OrderStatus::Cancelled->value, OrderStatus::Completed->value])
            ->latest()
            ->limit(30)
            ->get();

        $newCount = $byStatus['PENDING']->count() + $awaitingPayment->count();

        return view('attendant.dashboard', compact('byStatus', 'awaitingPayment', 'newCount'));
    }

    public function action(Request $request, Order $order, string $action)
    {
        $user = $request->user();

        try {
            match ($action) {
                'confirm' => $this->orders->confirm($order, $user),
                'prepare' => $this->orders->startPreparing($order, $user),
                'ready' => $this->orders->markReady($order, $user),
                'deliver' => $this->orders->markDelivered($order, $user),
                'complete' => $this->orders->complete($order, $user),
                'cancel' => $this->orders->cancel($order, $user, $request->input('reason', 'Cancelado no painel do atendente')),
                'confirm-payment' => tap($order, function (Order $o) use ($user) {
                    if ($o->payment) {
                        $this->payments->confirm($o->payment, $user);
                    }
                }),
                default => abort(404),
            };
        } catch (\Throwable $e) {
            return back()->withErrors(['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Pedido atualizado.');
    }

    public function tables()
    {
        $tables = Table::query()->with('currentSession')->orderBy('number')->get();

        return view('attendant.tables', compact('tables'));
    }

    public function tableShow(Table $table)
    {
        $table->load(['currentSession.orders.items', 'currentSession.orders.payment']);
        $session = $table->currentSession;
        $orders = $session
            ? $session->orders()->with(['items', 'payment'])->latest()->get()
            : collect();

        return view('attendant.table-show', compact('table', 'session', 'orders'));
    }

    public function openSession(Request $request, Table $table)
    {
        $this->tables->openSession($table, $request->user());

        return back()->with('success', 'Sessão aberta.');
    }

    public function closeSession(Request $request, Table $table)
    {
        $session = $table->currentSession;
        if (! $session) {
            return back()->withErrors(['error' => 'Nenhuma sessão aberta.']);
        }
        $this->tables->closeSession($session, $request->user());

        return back()->with('success', 'Sessão encerrada.');
    }
}
