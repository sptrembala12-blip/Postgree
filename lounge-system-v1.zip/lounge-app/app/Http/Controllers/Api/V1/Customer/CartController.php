<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use App\Models\Table;
use App\Services\Orders\CartService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function __construct(private readonly CartService $carts) {}

    public function show(Request $request): JsonResponse
    {
        $table = $this->resolveTable($request);
        $cart = $this->carts->getOrCreate($request->header('X-Cart-Token') ?? $request->query('token'), $table);

        return response()->json([
            'data' => $this->carts->summarize($cart),
        ]);
    }

    public function add(Request $request): JsonResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'quantity' => ['sometimes', 'integer', 'min:1'],
            'notes' => ['nullable', 'string', 'max:500'],
            'table_id' => ['nullable', 'integer', 'exists:tables,id'],
            'token' => ['nullable', 'string'],
        ]);

        $table = $this->resolveTable($request);
        $cart = $this->carts->getOrCreate($data['token'] ?? $request->header('X-Cart-Token'), $table);
        $cart = $this->carts->addItem($cart, (int) $data['product_id'], (int) ($data['quantity'] ?? 1), $data['notes'] ?? null);

        return response()->json(['data' => $this->carts->summarize($cart)]);
    }

    public function updateItem(Request $request): JsonResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'quantity' => ['required', 'integer', 'min:0'],
            'token' => ['nullable', 'string'],
        ]);

        $cart = $this->carts->getOrCreate($data['token'] ?? $request->header('X-Cart-Token'));
        $cart = $this->carts->updateQuantity($cart, (int) $data['product_id'], (int) $data['quantity']);

        return response()->json(['data' => $this->carts->summarize($cart)]);
    }

    public function removeItem(Request $request): JsonResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'token' => ['nullable', 'string'],
        ]);

        $cart = $this->carts->getOrCreate($data['token'] ?? $request->header('X-Cart-Token'));
        $cart = $this->carts->removeItem($cart, (int) $data['product_id']);

        return response()->json(['data' => $this->carts->summarize($cart)]);
    }

    public function clear(Request $request): JsonResponse
    {
        $cart = $this->carts->getOrCreate($request->input('token') ?? $request->header('X-Cart-Token'));
        $cart = $this->carts->clear($cart);

        return response()->json(['data' => $this->carts->summarize($cart)]);
    }

    private function resolveTable(Request $request): ?Table
    {
        if ($request->filled('table_id')) {
            return Table::query()->whereKey($request->integer('table_id'))->where('is_active', true)->first();
        }

        if ($request->filled('table_number')) {
            return Table::query()->where('number', $request->string('table_number'))->where('is_active', true)->first();
        }

        return null;
    }
}
