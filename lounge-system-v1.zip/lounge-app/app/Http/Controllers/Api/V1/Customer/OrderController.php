<?php

namespace App\Http\Controllers\Api\V1\Customer;

use App\Http\Controllers\Controller;
use App\Http\Requests\Order\CreateOrderRequest;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use App\Services\Orders\OrderService;
use Illuminate\Http\JsonResponse;

class OrderController extends Controller
{
    public function __construct(private readonly OrderService $orders) {}

    public function store(CreateOrderRequest $request): JsonResponse
    {
        $order = $this->orders->create($request->validated());

        return response()->json([
            'message' => 'Pedido criado com sucesso.',
            'data' => new OrderResource($order->load(['items', 'payment', 'table'])),
        ], 201);
    }

    public function show(int $orderNumber): JsonResponse
    {
        $order = Order::query()
            ->where('order_number', $orderNumber)
            ->with(['items', 'payment', 'table'])
            ->firstOrFail();

        return response()->json(['data' => new OrderResource($order)]);
    }
}
