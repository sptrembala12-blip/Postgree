<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Enums\CashMovementType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Cash\CloseCashRegisterRequest;
use App\Http\Requests\Cash\OpenCashRegisterRequest;
use App\Models\CashRegister;
use App\Services\Cash\CashService;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CashRegisterController extends Controller
{
    public function __construct(private readonly CashService $cash) {}

    public function current(): JsonResponse
    {
        $register = $this->cash->currentOpen();

        if (! $register) {
            return response()->json(['data' => null, 'message' => 'Nenhum caixa aberto.']);
        }

        $summary = $this->cash->buildSummary($register);

        return response()->json([
            'data' => $register->load('movements'),
            'summary' => $summary,
            'summary_formatted' => [
                'expected_cash' => Money::format($summary['expected_cash']),
                'sales_total' => Money::format($summary['sales_total']),
            ],
        ]);
    }

    public function open(OpenCashRegisterRequest $request): JsonResponse
    {
        $register = $this->cash->open(
            (int) $request->validated('opening_amount'),
            $request->user(),
            $request->validated('notes')
        );

        return response()->json(['message' => 'Caixa aberto.', 'data' => $register], 201);
    }

    public function close(CloseCashRegisterRequest $request): JsonResponse
    {
        $register = $this->cash->close(
            (int) $request->validated('closing_amount'),
            $request->user(),
            $request->validated('notes')
        );

        return response()->json([
            'message' => 'Caixa fechado.',
            'data' => $register,
            'expected_formatted' => Money::format((int) $register->expected_amount),
            'closing_formatted' => Money::format((int) $register->closing_amount),
            'difference_formatted' => Money::format((int) $register->difference),
        ]);
    }

    public function movement(Request $request): JsonResponse
    {
        $data = $request->validate([
            'type' => ['required', 'in:EXPENSE,WITHDRAWAL,DEPOSIT,ADJUSTMENT,REFUND'],
            'amount' => ['required', 'integer', 'not_in:0'],
            'description' => ['nullable', 'string', 'max:500'],
        ]);

        $movement = $this->cash->addMovement(
            CashMovementType::from($data['type']),
            (int) $data['amount'],
            $request->user(),
            $data['description'] ?? null,
        );

        return response()->json(['message' => 'Movimentação registrada.', 'data' => $movement], 201);
    }

    public function history(Request $request): JsonResponse
    {
        $items = CashRegister::query()->with(['openedBy', 'closedBy'])->latest('opened_at')
            ->paginate(min(50, (int) $request->input('per_page', 15)));

        return response()->json(['data' => $items]);
    }
}
