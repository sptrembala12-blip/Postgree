<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Services\Reports\DashboardAnalyticsService;
use App\Services\Reports\ReportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __construct(
        private readonly ReportService $reports,
        private readonly DashboardAnalyticsService $analytics,
    ) {}

    public function __invoke(Request $request): JsonResponse
    {
        $data = $this->analytics->full(
            $request->input('period', 'today'),
            $request->input('from'),
            $request->input('to'),
        );

        return response()->json(['data' => $data]);
    }

    public function sales(Request $request): JsonResponse
    {
        return response()->json([
            'data' => $this->analytics->salesSeries(
                $request->input('period', '7d'),
                $request->input('from'),
                $request->input('to'),
            ),
        ]);
    }

    public function products(Request $request): JsonResponse
    {
        return response()->json([
            'data' => $this->reports->productsReport(
                $request->input('from'),
                $request->input('to'),
                $request->integer('product_id') ?: null,
                $request->integer('category_id') ?: null,
            ),
        ]);
    }
}
