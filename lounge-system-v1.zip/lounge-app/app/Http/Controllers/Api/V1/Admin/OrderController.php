<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Enums\OrderStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Order\UpdateOrderStatusRequest;
use App\Http\Resources\OrderResource;
use App\Models\Order;
use App\Services\Orders\OrderService;
use App\Services\Payments\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function __construct(
        private readonly OrderService $orders,
        private readonly PaymentService $payments,
    ) {}

    public function index(Request $request): JsonResponse
    {
        $query = Order::query()->with(['items', 'payment', 'table'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }
        if ($request->filled('table_id')) {
            $query->where('table_id', $request->integer('table_id'));
        }
        if ($request->filled('order_number')) {
            $query->where('order_number', $request->integer('order_number'));
        }
        if ($request->filled('payment_method')) {
            $query->whereHas('payment', fn ($q) => $q->where('method', $request->string('payment_method')));
        }
        if ($request->filled('from') && $request->filled('to')) {
            $query->whereBetween('created_at', [
                $request->date('from')->startOfDay(),
                $request->date('to')->endOfDay(),
            ]);
        }

        $orders = $query->paginate(min(100, (int) $request->input('per_page', 20)));

        return OrderResource::collection($orders)->response();
    }

    public function show(Order $order): JsonResponse
    {
        $order->load(['items.product', 'payment', 'table', 'tableSession']);

        return response()->json(['data' => new OrderResource($order)]);
    }

    public function updateStatus(UpdateOrderStatusRequest $request, Order $order): JsonResponse
    {
        $status = OrderStatus::from($request->validated('status'));
        $order = $this->orders->transition($order, $status, $request->user(), $request->validated('reason'));

        return response()->json([
            'message' => 'Status atualizado.',
            'data' => new OrderResource($order),
        ]);
    }

    public function confirm(Request $request, Order $order): JsonResponse
    {
        $order = $this->orders->confirm($order, $request->user());

        return response()->json(['message' => 'Pedido confirmado.', 'data' => new OrderResource($order)]);
    }

    public function prepare(Request $request, Order $order): JsonResponse
    {
        $order = $this->orders->startPreparing($order, $request->user());

        return response()->json(['message' => 'Preparo iniciado.', 'data' => new OrderResource($order)]);
    }

    public function ready(Request $request, Order $order): JsonResponse
    {
        $order = $this->orders->markReady($order, $request->user());

        return response()->json(['message' => 'Pedido pronto.', 'data' => new OrderResource($order)]);
    }

    public function deliver(Request $request, Order $order): JsonResponse
    {
        $order = $this->orders->markDelivered($order, $request->user());

        return response()->json(['message' => 'Pedido entregue.', 'data' => new OrderResource($order)]);
    }

    public function complete(Request $request, Order $order): JsonResponse
    {
        $order = $this->orders->complete($order, $request->user());

        return response()->json(['message' => 'Pedido finalizado.', 'data' => new OrderResource($order)]);
    }

    public function cancel(Request $request, Order $order): JsonResponse
    {
        $data = $request->validate(['reason' => ['nullable', 'string', 'max:500']]);
        $order = $this->orders->cancel($order, $request->user(), $data['reason'] ?? null);

        return response()->json(['message' => 'Pedido cancelado.', 'data' => new OrderResource($order)]);
    }

    public function confirmPayment(Request $request, Order $order): JsonResponse
    {
        $payment = $order->payment;
        if (! $payment) {
            return response()->json(['message' => 'Pedido sem pagamento.'], 422);
        }

        $payment = $this->payments->confirm($payment, $request->user());
        $order->load(['items', 'payment', 'table']);

        return response()->json([
            'message' => 'Pagamento confirmado.',
            'data' => new OrderResource($order),
        ]);
    }
}
