<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Category\StoreCategoryRequest;
use App\Http\Requests\Category\UpdateCategoryRequest;
use App\Http\Resources\CategoryResource;
use App\Models\Category;
use App\Services\Audit\AuditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function __construct(private readonly AuditService $audit) {}

    public function index(Request $request): JsonResponse
    {
        $query = Category::query()->withCount('products')->orderBy('sort_order')->orderBy('name');

        if ($request->filled('active')) {
            $query->where('is_active', filter_var($request->input('active'), FILTER_VALIDATE_BOOLEAN));
        }

        return response()->json([
            'data' => CategoryResource::collection($query->get()),
        ]);
    }

    public function store(StoreCategoryRequest $request): JsonResponse
    {
        $data = $request->safe()->except('image');
        if (empty($data['slug'])) {
            $data['slug'] = Category::uniqueSlug($data['name']);
        }

        $category = Category::create($data);
        $this->audit->log('CATEGORY_CREATED', $category, null, $category->toArray(), $request->user());

        return response()->json([
            'message' => 'Categoria criada.',
            'data' => new CategoryResource($category),
        ], 201);
    }

    public function show(Category $category): JsonResponse
    {
        return response()->json(['data' => new CategoryResource($category->loadCount('products'))]);
    }

    public function update(UpdateCategoryRequest $request, Category $category): JsonResponse
    {
        $old = $category->toArray();
        $category->fill($request->safe()->except('image'));
        $category->save();
        $this->audit->log('CATEGORY_UPDATED', $category, $old, $category->toArray(), $request->user());

        return response()->json([
            'message' => 'Categoria atualizada.',
            'data' => new CategoryResource($category),
        ]);
    }

    public function destroy(Request $request, Category $category): JsonResponse
    {
        if ($category->products()->exists()) {
            return response()->json(['message' => 'Categoria possui produtos. Desative-a ou mova os produtos.'], 422);
        }

        $this->audit->log('CATEGORY_DELETED', $category, $category->toArray(), null, $request->user());
        $category->delete();

        return response()->json(['message' => 'Categoria excluída.']);
    }
}
