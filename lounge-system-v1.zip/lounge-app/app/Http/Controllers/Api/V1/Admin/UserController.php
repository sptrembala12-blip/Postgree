<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\StoreUserRequest;
use App\Http\Requests\User\UpdateUserRequest;
use App\Models\Role;
use App\Models\User;
use App\Services\Audit\AuditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function __construct(private readonly AuditService $audit) {}

    public function index(): JsonResponse
    {
        $users = User::query()->with('roles')->orderBy('name')->get()->map(fn (User $u) => [
            'id' => $u->id,
            'name' => $u->name,
            'email' => $u->email,
            'is_active' => $u->is_active,
            'roles' => $u->roles->pluck('slug'),
        ]);

        return response()->json(['data' => $users]);
    }

    public function store(StoreUserRequest $request): JsonResponse
    {
        $data = $request->validated();
        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'is_active' => $data['is_active'] ?? true,
        ]);
        $user->assignRole($data['role']);

        $this->audit->log('USER_CREATED', $user, null, [
            'email' => $user->email,
            'role' => $data['role'],
        ], $request->user());

        return response()->json(['message' => 'Usuário criado.', 'data' => $user->load('roles')], 201);
    }

    public function update(UpdateUserRequest $request, User $user): JsonResponse
    {
        $old = $user->only(['name', 'email', 'is_active']);
        $data = $request->validated();

        if (isset($data['name'])) {
            $user->name = $data['name'];
        }
        if (isset($data['email'])) {
            $user->email = $data['email'];
        }
        if (isset($data['is_active'])) {
            $user->is_active = $data['is_active'];
        }
        if (! empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }
        $user->save();

        if (! empty($data['role'])) {
            $role = Role::where('slug', $data['role'])->firstOrFail();
            $user->roles()->sync([$role->id]);
        }

        $this->audit->log('USER_UPDATED', $user, $old, $user->only(['name', 'email', 'is_active']), $request->user());

        return response()->json(['message' => 'Usuário atualizado.', 'data' => $user->load('roles')]);
    }

    public function destroy(Request $request, User $user): JsonResponse
    {
        if ($user->id === $request->user()->id) {
            return response()->json(['message' => 'Não é possível excluir o próprio usuário.'], 422);
        }

        $user->is_active = false;
        $user->save();
        $this->audit->log('USER_DEACTIVATED', $user, null, ['is_active' => false], $request->user());

        return response()->json(['message' => 'Usuário desativado.']);
    }
}
