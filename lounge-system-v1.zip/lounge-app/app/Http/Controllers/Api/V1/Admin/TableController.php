<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Table\StoreTableRequest;
use App\Http\Requests\Table\UpdateTableRequest;
use App\Http\Resources\TableResource;
use App\Models\Table;
use App\Services\Tables\TableService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TableController extends Controller
{
    public function __construct(private readonly TableService $tables) {}

    public function index(Request $request): JsonResponse
    {
        $query = Table::query()->with('currentSession')->orderBy('number');

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }
        if ($request->filled('type')) {
            $query->where('type', $request->string('type'));
        }

        return response()->json([
            'data' => TableResource::collection($query->get()),
        ]);
    }

    public function store(StoreTableRequest $request): JsonResponse
    {
        $table = $this->tables->create($request->validated(), $request->user());

        return response()->json([
            'message' => 'Mesa criada.',
            'data' => new TableResource($table),
        ], 201);
    }

    public function show(Table $table): JsonResponse
    {
        $table->load('currentSession');

        return response()->json(['data' => new TableResource($table)]);
    }

    public function update(UpdateTableRequest $request, Table $table): JsonResponse
    {
        $table = $this->tables->update($table, $request->validated(), $request->user());

        return response()->json([
            'message' => 'Mesa atualizada.',
            'data' => new TableResource($table),
        ]);
    }

    public function qrCode(Table $table): JsonResponse
    {
        if (! $table->qr_code_path) {
            $this->tables->generateQrCode($table);
            $table->refresh();
        }

        return response()->json([
            'data' => [
                'table' => new TableResource($table),
                'qr_code_url' => $table->qr_code_path ? Storage::disk('public')->url($table->qr_code_path) : null,
                'public_url' => $table->publicTokenUrl(),
                'menu_url' => $table->menuUrl(),
            ],
        ]);
    }

    public function regenerateQr(Request $request, Table $table): JsonResponse
    {
        $table = $this->tables->regenerateQr($table, $request->user());

        return response()->json([
            'message' => 'QR Code regenerado.',
            'data' => new TableResource($table),
        ]);
    }

    public function openSession(Request $request, Table $table): JsonResponse
    {
        $session = $this->tables->openSession($table, $request->user());

        return response()->json([
            'message' => 'Sessão aberta.',
            'data' => $session,
        ]);
    }

    public function closeSession(Request $request, Table $table): JsonResponse
    {
        $session = $table->currentSession;
        if (! $session) {
            return response()->json(['message' => 'Nenhuma sessão aberta.'], 422);
        }

        $session = $this->tables->closeSession($session, $request->user());

        return response()->json([
            'message' => 'Sessão fechada.',
            'data' => $session,
        ]);
    }
}
