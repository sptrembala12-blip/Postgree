<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminNotification;
use App\Services\Notifications\AdminNotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function __construct(private readonly AdminNotificationService $notifications) {}

    public function index(Request $request): JsonResponse
    {
        $query = AdminNotification::query()->latest();

        if ($request->filled('type') && $request->string('type') !== 'all') {
            $type = $request->string('type')->toString();
            $query->where('type', $type === 'payments' ? 'payment_confirmed' : $type);
        }

        if ($request->boolean('unread_only')) {
            $query->whereNull('read_at');
        }

        $items = $query->paginate(min(50, (int) $request->input('per_page', 20)));

        return response()->json([
            'data' => collect($items->items())->map->toApiArray()->values(),
            'meta' => [
                'current_page' => $items->currentPage(),
                'last_page' => $items->lastPage(),
                'total' => $items->total(),
                'unread' => $this->notifications->unreadCount($request->user()),
            ],
        ]);
    }

    public function unread(Request $request): JsonResponse
    {
        return response()->json([
            'unread' => $this->notifications->unreadCount($request->user()),
        ]);
    }

    public function markRead(Request $request, AdminNotification $notification): JsonResponse
    {
        $n = $this->notifications->markRead($notification);

        return response()->json(['data' => $n->toApiArray()]);
    }

    public function markAllRead(Request $request): JsonResponse
    {
        $count = $this->notifications->markAllRead();

        return response()->json(['marked' => $count, 'unread' => 0]);
    }
}
