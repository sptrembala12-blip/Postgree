<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminNotification;
use App\Models\Order;
use App\Support\Money;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * SSE feed for admin: new orders + payment-confirmed notifications.
 * Not a WebSocket stack.
 */
class RealtimeController extends Controller
{
    public function ordersStream(Request $request): StreamedResponse
    {
        $lastOrderId = (int) $request->query('last_id', 0);
        $lastNotificationId = (int) $request->query('last_notification_id', 0);
        $started = time();
        $maxSeconds = min(55, (int) $request->query('max', 45));

        return response()->stream(function () use (&$lastOrderId, &$lastNotificationId, $started, $maxSeconds) {
            if (function_exists('apache_setenv')) {
                @apache_setenv('no-gzip', '1');
            }
            @ini_set('zlib.output_compression', '0');
            @ini_set('implicit_flush', '1');
            while (ob_get_level() > 0) {
                ob_end_flush();
            }

            echo "event: connected\n";
            echo 'data: '.json_encode([
                'ok' => true,
                'mode' => 'sse',
                'server_time' => now()->toIso8601String(),
            ], JSON_UNESCAPED_UNICODE)."\n\n";
            flush();

            while (! connection_aborted() && (time() - $started) < $maxSeconds) {
                $orders = Order::query()
                    ->with(['items', 'payment', 'table'])
                    ->where('id', '>', $lastOrderId)
                    ->orderBy('id')
                    ->limit(20)
                    ->get();

                foreach ($orders as $order) {
                    $lastOrderId = (int) $order->id;
                    $payment = $order->payment;
                    $payload = [
                        'type' => 'order.created',
                        'order_id' => $order->id,
                        'order_number' => $order->order_number,
                        'display_number' => $order->displayNumber(),
                        'status' => $order->status->value,
                        'total' => $order->total,
                        'total_formatted' => Money::format((int) $order->total),
                        'table' => $order->table?->number,
                        'payment_method' => $payment?->method?->value,
                        'payment_status' => $payment?->status?->value,
                        'items' => $order->items->map(fn ($i) => [
                            'name' => $i->product_name_snapshot,
                            'quantity' => $i->quantity,
                        ])->values(),
                        'created_at' => $order->created_at?->toIso8601String(),
                    ];
                    if ($payment?->method?->value === 'CASH') {
                        $payload['amount_received'] = $payment->amount_received;
                        $payload['change_amount'] = $payment->change_amount;
                        $payload['amount_received_formatted'] = Money::format((int) $payment->amount_received);
                        $payload['change_amount_formatted'] = Money::format((int) $payment->change_amount);
                    }

                    echo "id: order-{$order->id}\n";
                    echo "event: order.created\n";
                    echo 'data: '.json_encode($payload, JSON_UNESCAPED_UNICODE)."\n\n";
                    flush();
                }

                $notes = AdminNotification::query()
                    ->where('id', '>', $lastNotificationId)
                    ->orderBy('id')
                    ->limit(30)
                    ->get();

                foreach ($notes as $note) {
                    $lastNotificationId = (int) $note->id;
                    $payload = [
                        'type' => 'payment.confirmed',
                        'notification' => $note->toApiArray(),
                    ];
                    echo "id: notif-{$note->id}\n";
                    echo "event: payment.confirmed\n";
                    echo 'data: '.json_encode($payload, JSON_UNESCAPED_UNICODE)."\n\n";
                    flush();
                }

                echo ": ping\n\n";
                flush();
                usleep(1500000);
            }

            echo "event: reconnect\n";
            echo 'data: '.json_encode([
                'last_id' => $lastOrderId,
                'last_notification_id' => $lastNotificationId,
            ])."\n\n";
            flush();
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache, no-store',
            'Connection' => 'keep-alive',
            'X-Accel-Buffering' => 'no',
        ]);
    }

    public function ordersPoll(Request $request)
    {
        $lastId = (int) $request->query('last_id', 0);
        $lastNotificationId = (int) $request->query('last_notification_id', 0);

        $orders = Order::query()
            ->with(['items', 'payment', 'table'])
            ->where('id', '>', $lastId)
            ->orderBy('id')
            ->limit(50)
            ->get()
            ->map(function (Order $order) {
                $payment = $order->payment;

                return [
                    'order_id' => $order->id,
                    'order_number' => $order->order_number,
                    'display_number' => $order->displayNumber(),
                    'status' => $order->status->value,
                    'total' => $order->total,
                    'total_formatted' => Money::format((int) $order->total),
                    'table' => $order->table?->number,
                    'payment_method' => $payment?->method?->value,
                    'payment_status' => $payment?->status?->value,
                    'change_amount' => $payment?->change_amount,
                    'amount_received' => $payment?->amount_received,
                    'items' => $order->items->map(fn ($i) => [
                        'name' => $i->product_name_snapshot,
                        'quantity' => $i->quantity,
                    ])->values(),
                    'created_at' => $order->created_at?->toIso8601String(),
                ];
            });

        $notifications = AdminNotification::query()
            ->where('id', '>', $lastNotificationId)
            ->orderBy('id')
            ->limit(50)
            ->get()
            ->map->toApiArray()
            ->values();

        return response()->json([
            'data' => $orders,
            'notifications' => $notifications,
            'last_id' => $orders->last()['order_id'] ?? $lastId,
            'last_notification_id' => $notifications->last()['id'] ?? $lastNotificationId,
            'mode' => 'poll',
            'server_time' => now()->toIso8601String(),
        ]);
    }
}
