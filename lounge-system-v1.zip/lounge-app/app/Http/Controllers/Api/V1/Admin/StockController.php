<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Enums\InventoryMovementType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Stock\StockMovementRequest;
use App\Http\Resources\ProductResource;
use App\Models\InventoryMovement;
use App\Models\Product;
use App\Services\Inventory\InventoryService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class StockController extends Controller
{
    public function __construct(private readonly InventoryService $inventory) {}

    public function index(Request $request): JsonResponse
    {
        $query = Product::query()
            ->where('stock_control_enabled', true)
            ->with('category')
            ->orderBy('name');

        if ($request->boolean('low_stock')) {
            $query->lowStock();
        }

        if ($request->filled('q')) {
            $query->where('name', 'like', '%'.$request->string('q').'%');
        }

        return ProductResource::collection(
            $query->paginate(min(100, (int) $request->input('per_page', 30)))
        )->response();
    }

    public function lowStock(): JsonResponse
    {
        $products = Product::query()->lowStock()->active()->with('category')->orderBy('current_stock')->get();

        return response()->json([
            'data' => ProductResource::collection($products),
            'alerts' => $products->map(fn (Product $p) => "Estoque baixo: {$p->name} ({$p->current_stock})")->values(),
        ]);
    }

    public function movements(Request $request): JsonResponse
    {
        $query = InventoryMovement::query()->with(['product', 'user'])->latest();

        if ($request->filled('product_id')) {
            $query->where('product_id', $request->integer('product_id'));
        }
        if ($request->filled('type')) {
            $query->where('type', $request->string('type'));
        }

        return response()->json([
            'data' => $query->paginate(min(100, (int) $request->input('per_page', 30))),
        ]);
    }

    public function move(StockMovementRequest $request): JsonResponse
    {
        $data = $request->validated();
        $product = Product::query()->findOrFail($data['product_id']);
        $type = InventoryMovementType::from($data['type']);
        $qty = (int) $data['quantity'];
        $reason = $data['reason'] ?? null;
        $user = $request->user();

        $movement = match ($type) {
            InventoryMovementType::Purchase => $this->inventory->purchase($product, $qty, $reason, $user),
            InventoryMovementType::Loss => $this->inventory->loss($product, $qty, $reason, $user),
            InventoryMovementType::Return => $this->inventory->returnStock($product, $qty, $reason, $user),
            InventoryMovementType::Adjustment => $this->inventory->adjustment($product, $qty, $reason, $user),
            default => $this->inventory->move($product, $type, $qty, $reason, $user),
        };

        return response()->json([
            'message' => 'Movimentação registrada.',
            'data' => $movement->load('product'),
        ], 201);
    }
}
