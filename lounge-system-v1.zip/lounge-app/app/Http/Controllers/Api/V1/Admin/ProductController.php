<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Product\StoreProductRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Models\ProductImage;
use App\Services\Audit\AuditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    public function __construct(private readonly AuditService $audit) {}

    public function index(Request $request): JsonResponse
    {
        $query = Product::query()->with(['category', 'primaryImage'])->latest();

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->integer('category_id'));
        }
        if ($request->filled('active')) {
            $query->where('is_active', filter_var($request->input('active'), FILTER_VALIDATE_BOOLEAN));
        }
        if ($request->filled('q')) {
            $q = '%'.$request->string('q').'%';
            $query->where('name', 'like', $q);
        }
        if ($request->boolean('low_stock')) {
            $query->lowStock();
        }

        return ProductResource::collection(
            $query->paginate(min(100, (int) $request->input('per_page', 20)))
        )->response();
    }

    public function store(StoreProductRequest $request): JsonResponse
    {
        $data = $request->validated();
        unset($data['image'], $data['price_cents'], $data['promotional_price_cents']);
        foreach (['stock_control_enabled', 'is_active', 'is_featured'] as $field) {
            if ($request->has($field)) {
                $data[$field] = $request->boolean($field);
            }
        }

        // API prefers integer cents; also accept price_cents alias
        if ($request->filled('price_cents')) {
            $data['price'] = (int) $request->input('price_cents');
        } elseif (isset($data['price']) && is_string($data['price'])) {
            $data['price'] = \App\Support\MoneyInput::toCents($data['price'], true);
        } else {
            $data['price'] = (int) ($data['price'] ?? 0);
        }

        if ($request->filled('promotional_price_cents')) {
            $data['promotional_price'] = (int) $request->input('promotional_price_cents');
        } elseif (array_key_exists('promotional_price', $data) && is_string($data['promotional_price'])) {
            $data['promotional_price'] = \App\Support\MoneyInput::toCents($data['promotional_price'], true);
        }

        if (empty($data['slug'])) {
            $data['slug'] = Product::uniqueSlug($data['name']);
        }

        $product = Product::create($data);

        if ($request->hasFile('image')) {
            $this->storeImage($product, $request->file('image'));
        }

        $this->audit->log('PRODUCT_CREATED', $product, null, $product->toArray(), $request->user());

        return response()->json([
            'message' => 'Produto criado.',
            'data' => new ProductResource($product->load(['category', 'images', 'primaryImage'])),
        ], 201);
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json([
            'data' => new ProductResource($product->load(['category', 'images', 'primaryImage'])),
        ]);
    }

    public function update(UpdateProductRequest $request, Product $product): JsonResponse
    {
        $old = $product->toArray();
        $data = $request->validated();
        unset($data['image']);
        foreach (['stock_control_enabled', 'is_active', 'is_featured'] as $field) {
            if ($request->has($field)) {
                $data[$field] = $request->boolean($field);
            }
        }

        if (isset($data['price']) && (int) $data['price'] !== (int) $product->price) {
            $this->audit->log('PRICE_CHANGED', $product, ['price' => $product->price], ['price' => $data['price']], $request->user());
        }

        $product->fill($data);
        $product->save();

        if ($request->hasFile('image')) {
            $this->storeImage($product, $request->file('image'), true);
        }

        $this->audit->log('PRODUCT_UPDATED', $product, $old, $product->toArray(), $request->user());

        return response()->json([
            'message' => 'Produto atualizado.',
            'data' => new ProductResource($product->load(['category', 'images', 'primaryImage'])),
        ]);
    }

    public function destroy(Request $request, Product $product): JsonResponse
    {
        if ($product->orderItems()->exists()) {
            $product->is_active = false;
            $product->save();
            $this->audit->log('PRODUCT_DEACTIVATED', $product, null, ['is_active' => false], $request->user());

            return response()->json(['message' => 'Produto possui histórico e foi desativado.']);
        }

        $this->audit->log('PRODUCT_DELETED', $product, $product->toArray(), null, $request->user());
        $product->delete();

        return response()->json(['message' => 'Produto excluído.']);
    }

    private function storeImage(Product $product, $file, bool $replacePrimary = false): void
    {
        $safeName = Str::uuid()->toString().'.'.$file->getClientOriginalExtension();
        $path = $file->storeAs('products/'.$product->id, $safeName, 'public');

        if ($replacePrimary) {
            $product->images()->where('is_primary', true)->update(['is_primary' => false]);
        }

        ProductImage::create([
            'product_id' => $product->id,
            'path' => $path,
            'original_name' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'size' => $file->getSize(),
            'is_primary' => true,
            'sort_order' => 0,
        ]);
    }
}
