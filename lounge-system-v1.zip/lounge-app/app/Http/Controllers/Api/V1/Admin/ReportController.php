<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Services\Reports\ReportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function __construct(private readonly ReportService $reports) {}

    public function products(Request $request): JsonResponse
    {
        return response()->json([
            'data' => $this->reports->productsReport(
                $request->input('from'),
                $request->input('to'),
                $request->integer('product_id') ?: null,
                $request->integer('category_id') ?: null,
            ),
        ]);
    }

    public function categories(Request $request): JsonResponse
    {
        return response()->json([
            'data' => $this->reports->categoriesReport($request->input('from'), $request->input('to')),
        ]);
    }

    public function payments(Request $request): JsonResponse
    {
        return response()->json([
            'data' => $this->reports->paymentsReport($request->input('from'), $request->input('to')),
        ]);
    }

    public function tables(Request $request): JsonResponse
    {
        return response()->json([
            'data' => $this->reports->tablesReport($request->input('from'), $request->input('to')),
        ]);
    }
}
