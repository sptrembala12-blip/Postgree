<?php

namespace App\Http\Controllers\Api\V1\Public;

use App\Http\Controllers\Controller;
use App\Http\Resources\CategoryResource;
use App\Http\Resources\ProductResource;
use App\Http\Resources\TableResource;
use App\Models\Category;
use App\Models\Product;
use App\Models\Table;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MenuController extends Controller
{
    public function menu(Request $request): JsonResponse
    {
        $categories = Category::query()
            ->active()
            ->with(['products' => function ($q) {
                $q->active()->with(['images', 'primaryImage'])->orderBy('sort_order')->orderBy('name');
            }])
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        return response()->json([
            'categories' => CategoryResource::collection($categories),
            'featured' => ProductResource::collection(
                Product::query()->active()->featured()->with(['images', 'primaryImage', 'category'])->limit(12)->get()
            ),
        ]);
    }

    public function categories(): JsonResponse
    {
        $categories = Category::query()->active()->orderBy('sort_order')->orderBy('name')->get();

        return response()->json(['data' => CategoryResource::collection($categories)]);
    }

    public function category(string $slug): JsonResponse
    {
        $category = Category::query()
            ->active()
            ->where('slug', $slug)
            ->with(['products' => fn ($q) => $q->active()->with(['images', 'primaryImage'])->orderBy('sort_order')])
            ->firstOrFail();

        return response()->json(['data' => new CategoryResource($category)]);
    }

    public function products(Request $request): JsonResponse
    {
        $query = Product::query()->active()->with(['category', 'images', 'primaryImage']);

        if ($request->filled('category')) {
            $query->whereHas('category', fn ($q) => $q->where('slug', $request->string('category')));
        }

        if ($request->filled('featured')) {
            $query->featured();
        }

        if ($request->filled('q')) {
            $q = '%'.$request->string('q').'%';
            $query->where(function ($builder) use ($q) {
                $builder->where('name', 'like', $q)->orWhere('description', 'like', $q);
            });
        }

        $products = $query->orderBy('sort_order')->orderBy('name')->paginate(min(50, (int) $request->input('per_page', 24)));

        return ProductResource::collection($products)->response();
    }

    public function product(string $slug): JsonResponse
    {
        $product = Product::query()
            ->active()
            ->where('slug', $slug)
            ->with(['category', 'images', 'primaryImage'])
            ->firstOrFail();

        return response()->json(['data' => new ProductResource($product)]);
    }

    public function tableByNumber(string $number): JsonResponse
    {
        $table = Table::query()->where('number', $number)->where('is_active', true)->firstOrFail();

        return response()->json(['data' => new TableResource($table)]);
    }

    public function tableByToken(string $token): JsonResponse
    {
        $table = Table::query()->where('qr_token', $token)->where('is_active', true)->firstOrFail();

        return response()->json(['data' => new TableResource($table)]);
    }
}
