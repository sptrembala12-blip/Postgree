<?php

namespace App\Http\Resources;

use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Payment */
class PaymentResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'method' => $this->method->value,
            'method_label' => $this->method->label(),
            'status' => $this->status->value,
            'status_label' => $this->status->label(),
            'amount' => $this->amount,
            'amount_formatted' => Money::format((int) $this->amount),
            'amount_received' => $this->amount_received,
            'amount_received_formatted' => $this->amount_received !== null
                ? Money::format((int) $this->amount_received)
                : null,
            'change_amount' => $this->change_amount,
            'change_amount_formatted' => Money::format((int) $this->change_amount),
            'transaction_reference' => $this->transaction_reference,
            'paid_at' => $this->paid_at?->toIso8601String(),
            'metadata' => $this->metadata,
        ];
    }
}
