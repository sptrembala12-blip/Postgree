<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

/** @mixin \App\Models\Table */
class TableResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'number' => $this->number,
            'name' => $this->name,
            'type' => $this->type->value,
            'type_label' => $this->type->label(),
            'capacity' => $this->capacity,
            'location' => $this->location,
            'status' => $this->status->value,
            'status_label' => $this->status->label(),
            'qr_token' => $this->when($request->user() !== null, $this->qr_token),
            'menu_url' => $this->menuUrl(),
            'public_url' => $this->publicTokenUrl(),
            'qr_code_url' => $this->qr_code_path
                ? Storage::disk('public')->url($this->qr_code_path)
                : null,
            'is_active' => $this->is_active,
            'current_session' => $this->whenLoaded('currentSession'),
        ];
    }
}
