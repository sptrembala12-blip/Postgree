<?php

namespace App\Http\Resources;

use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Product */
class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'category_id' => $this->category_id,
            'category' => $this->whenLoaded('category', fn () => [
                'id' => $this->category->id,
                'name' => $this->category->name,
                'slug' => $this->category->slug,
            ]),
            'name' => $this->name,
            'slug' => $this->slug,
            'description' => $this->description,
            'price' => $this->price,
            'price_formatted' => Money::format((int) $this->price),
            'promotional_price' => $this->promotional_price,
            'promotional_price_formatted' => $this->promotional_price !== null
                ? Money::format((int) $this->promotional_price)
                : null,
            'effective_price' => $this->effectivePrice(),
            'effective_price_formatted' => Money::format($this->effectivePrice()),
            'stock_control_enabled' => $this->stock_control_enabled,
            'current_stock' => $this->when(
                $request->user() !== null,
                $this->current_stock
            ),
            'minimum_stock' => $this->when($request->user() !== null, $this->minimum_stock),
            'maximum_stock' => $this->when($request->user() !== null, $this->maximum_stock),
            'is_low_stock' => $this->when($request->user() !== null, $this->isLowStock()),
            'is_active' => $this->is_active,
            'is_featured' => $this->is_featured,
            'sort_order' => $this->sort_order,
            'images' => ProductImageResource::collection($this->whenLoaded('images')),
            'primary_image' => new ProductImageResource($this->whenLoaded('primaryImage')),
            'available' => $this->isAvailableForSale(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
