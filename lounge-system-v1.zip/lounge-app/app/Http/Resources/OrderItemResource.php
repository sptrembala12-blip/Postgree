<?php

namespace App\Http\Resources;

use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\OrderItem */
class OrderItemResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'product_id' => $this->product_id,
            'product_name' => $this->product_name_snapshot,
            'unit_price' => $this->unit_price,
            'unit_price_formatted' => Money::format((int) $this->unit_price),
            'quantity' => $this->quantity,
            'subtotal' => $this->subtotal,
            'subtotal_formatted' => Money::format((int) $this->subtotal),
            'notes' => $this->notes,
        ];
    }
}
