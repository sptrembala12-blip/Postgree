<?php

namespace App\Http\Resources;

use App\Support\Money;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/** @mixin \App\Models\Order */
class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'order_number' => $this->order_number,
            'display_number' => $this->displayNumber(),
            'table' => $this->whenLoaded('table', fn () => [
                'id' => $this->table?->id,
                'number' => $this->table?->number,
                'name' => $this->table?->name,
            ]),
            'table_session_id' => $this->table_session_id,
            'status' => $this->status->value,
            'status_label' => $this->status->label(),
            'subtotal' => $this->subtotal,
            'subtotal_formatted' => Money::format((int) $this->subtotal),
            'discount' => $this->discount,
            'total' => $this->total,
            'total_formatted' => Money::format((int) $this->total),
            'notes' => $this->notes,
            'customer_name' => $this->customer_name,
            'items' => OrderItemResource::collection($this->whenLoaded('items')),
            'payment' => new PaymentResource($this->whenLoaded('payment')),
            'confirmed_at' => $this->confirmed_at?->toIso8601String(),
            'completed_at' => $this->completed_at?->toIso8601String(),
            'cancelled_at' => $this->cancelled_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
