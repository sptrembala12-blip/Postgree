<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsActive
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user && ! $user->is_active) {
            if ($request->expectsJson()) {
                return response()->json(['message' => 'Usuário inativo.'], 403);
            }

            auth()->logout();

            return redirect()->route('admin.login')->withErrors(['email' => 'Usuário inativo.']);
        }

        return $next($request);
    }
}
