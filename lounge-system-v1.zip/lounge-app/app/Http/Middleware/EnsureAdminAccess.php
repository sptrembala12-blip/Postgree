<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureAdminAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (! $user) {
            if ($request->expectsJson()) {
                return response()->json(['message' => 'Não autenticado.'], 401);
            }

            return redirect()->route('admin.login');
        }

        if (! $user->is_active) {
            abort(403, 'Usuário inativo.');
        }

        // Any staff role can access admin area; fine-grained via permissions
        if (
            ! $user->hasAnyPermission([
                'dashboard.view',
                'orders.view',
                'products.view',
                'tables.view',
            ]) && ! $user->isAdmin()
        ) {
            abort(403, 'Acesso administrativo negado.');
        }

        return $next($request);
    }
}
