<?php

namespace App\Http\Requests\Table;

use App\Enums\TableStatus;
use App\Enums\TableType;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreTableRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'number' => ['required', 'string', 'max:20', 'unique:tables,number'],
            'name' => ['nullable', 'string', 'max:255'],
            'type' => ['required', Rule::enum(TableType::class)],
            'capacity' => ['sometimes', 'integer', 'min:1', 'max:50'],
            'location' => ['nullable', 'string', 'max:255'],
            'status' => ['sometimes', Rule::enum(TableStatus::class)],
            'is_active' => ['sometimes', 'boolean'],
        ];
    }
}
