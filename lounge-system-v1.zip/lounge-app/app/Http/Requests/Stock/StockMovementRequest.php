<?php

namespace App\Http\Requests\Stock;

use App\Enums\InventoryMovementType;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StockMovementRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'product_id' => ['required', 'exists:products,id'],
            'type' => ['required', Rule::in([
                InventoryMovementType::Purchase->value,
                InventoryMovementType::Adjustment->value,
                InventoryMovementType::Loss->value,
                InventoryMovementType::Return->value,
                InventoryMovementType::Transfer->value,
            ])],
            'quantity' => ['required', 'integer', 'not_in:0'],
            'reason' => ['nullable', 'string', 'max:500'],
        ];
    }
}
