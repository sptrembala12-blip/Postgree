<?php

namespace App\Enums;

enum InventoryMovementType: string
{
    case Purchase = 'PURCHASE';
    case Sale = 'SALE';
    case Adjustment = 'ADJUSTMENT';
    case Loss = 'LOSS';
    case Return = 'RETURN';
    case Transfer = 'TRANSFER';

    public function label(): string
    {
        return match ($this) {
            self::Purchase => 'Entrada / Compra',
            self::Sale => 'Venda',
            self::Adjustment => 'Ajuste',
            self::Loss => 'Perda',
            self::Return => 'Devolução',
            self::Transfer => 'Transferência',
        };
    }

    /**
     * Positive quantity increases stock; negative decreases.
     * ADJUSTMENT uses signed quantity as provided.
     */
    public function direction(): string
    {
        return match ($this) {
            self::Purchase, self::Return => 'in',
            self::Sale, self::Loss, self::Transfer => 'out',
            self::Adjustment => 'signed',
        };
    }
}
