<?php

namespace App\Enums;

enum OrderStatus: string
{
    case Pending = 'PENDING';
    case Confirmed = 'CONFIRMED';
    case Preparing = 'PREPARING';
    case Ready = 'READY';
    case Delivered = 'DELIVERED';
    case Completed = 'COMPLETED';
    case Cancelled = 'CANCELLED';

    public function label(): string
    {
        return match ($this) {
            self::Pending => 'Pendente',
            self::Confirmed => 'Confirmado',
            self::Preparing => 'Em preparo',
            self::Ready => 'Pronto',
            self::Delivered => 'Entregue',
            self::Completed => 'Finalizado',
            self::Cancelled => 'Cancelado',
        };
    }

    /**
     * @return list<self>
     */
    public function allowedTransitions(): array
    {
        return match ($this) {
            self::Pending => [self::Confirmed, self::Cancelled],
            self::Confirmed => [self::Preparing, self::Cancelled],
            self::Preparing => [self::Ready, self::Cancelled],
            self::Ready => [self::Delivered, self::Cancelled],
            self::Delivered => [self::Completed, self::Cancelled],
            self::Completed => [],
            self::Cancelled => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), true);
    }

    public function isFinal(): bool
    {
        return in_array($this, [self::Completed, self::Cancelled], true);
    }

    /**
     * Statuses that count toward revenue/reports.
     *
     * @return list<self>
     */
    public static function billable(): array
    {
        return [
            self::Confirmed,
            self::Preparing,
            self::Ready,
            self::Delivered,
            self::Completed,
        ];
    }

    /**
     * @return list<string>
     */
    public static function billableValues(): array
    {
        return array_map(fn (self $s) => $s->value, self::billable());
    }
}
