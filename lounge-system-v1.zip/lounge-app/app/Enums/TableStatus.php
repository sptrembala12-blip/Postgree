<?php

namespace App\Enums;

enum TableStatus: string
{
    case Available = 'AVAILABLE';
    case Occupied = 'OCCUPIED';
    case Reserved = 'RESERVED';
    case Maintenance = 'MAINTENANCE';
    case Inactive = 'INACTIVE';

    public function label(): string
    {
        return match ($this) {
            self::Available => 'Livre',
            self::Occupied => 'Ocupada',
            self::Reserved => 'Reservada',
            self::Maintenance => 'Manutenção',
            self::Inactive => 'Inativa',
        };
    }
}
