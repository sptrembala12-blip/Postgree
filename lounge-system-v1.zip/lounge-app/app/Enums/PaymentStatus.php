<?php

namespace App\Enums;

enum PaymentStatus: string
{
    case Pending = 'PENDING';
    case AwaitingConfirmation = 'AWAITING_CONFIRMATION';
    case Authorized = 'AUTHORIZED';
    case Paid = 'PAID';
    case Failed = 'FAILED';
    case Refunded = 'REFUNDED';
    case Cancelled = 'CANCELLED';

    public function label(): string
    {
        return match ($this) {
            self::Pending => 'Pendente',
            self::AwaitingConfirmation => 'Aguardando confirmação',
            self::Authorized => 'Autorizado',
            self::Paid => 'Pago',
            self::Failed => 'Falhou',
            self::Refunded => 'Estornado',
            self::Cancelled => 'Cancelado',
        };
    }

    public function isFinalSuccess(): bool
    {
        return $this === self::Paid;
    }
}
