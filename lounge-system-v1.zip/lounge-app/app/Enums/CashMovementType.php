<?php

namespace App\Enums;

enum CashMovementType: string
{
    case Sale = 'SALE';
    case Refund = 'REFUND';
    case Expense = 'EXPENSE';
    case Withdrawal = 'WITHDRAWAL';
    case Deposit = 'DEPOSIT';
    case Adjustment = 'ADJUSTMENT';

    public function label(): string
    {
        return match ($this) {
            self::Sale => 'Venda',
            self::Refund => 'Estorno',
            self::Expense => 'Despesa',
            self::Withdrawal => 'Sangria',
            self::Deposit => 'Suprimento',
            self::Adjustment => 'Ajuste',
        };
    }
}
