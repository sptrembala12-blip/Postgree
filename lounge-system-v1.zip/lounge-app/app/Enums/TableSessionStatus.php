<?php

namespace App\Enums;

enum TableSessionStatus: string
{
    case Open = 'OPEN';
    case Closed = 'CLOSED';
}
