<?php

namespace App\Enums;

enum TableType: string
{
    case Table = 'TABLE';
    case Lounge = 'LOUNGE';

    public function label(): string
    {
        return match ($this) {
            self::Table => 'Mesa',
            self::Lounge => 'Lounge',
        };
    }
}
