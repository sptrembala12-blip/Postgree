<?php

namespace App\Enums;

enum CashRegisterStatus: string
{
    case Open = 'OPEN';
    case Closed = 'CLOSED';
}
