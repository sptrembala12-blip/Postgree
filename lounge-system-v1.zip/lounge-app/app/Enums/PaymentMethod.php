<?php

namespace App\Enums;

enum PaymentMethod: string
{
    case Pix = 'PIX';
    case CreditCard = 'CREDIT_CARD';
    case DebitCard = 'DEBIT_CARD';
    case Cash = 'CASH';

    public function label(): string
    {
        return match ($this) {
            self::Pix => 'PIX',
            self::CreditCard => 'Crédito',
            self::DebitCard => 'Débito',
            self::Cash => 'Dinheiro',
        };
    }
}
