<?php

namespace App\Enums;

enum UserRole: string
{
    case Admin = 'ADMIN';
    case Attendant = 'ATTENDANT';
    case Manager = 'MANAGER';
    case Cashier = 'CASHIER';
    case StockManager = 'STOCK_MANAGER';

    public function label(): string
    {
        return match ($this) {
            self::Admin => 'Administrador',
            self::Attendant => 'Atendente',
            self::Manager => 'Gerente',
            self::Cashier => 'Caixa',
            self::StockManager => 'Estoque',
        };
    }
}
