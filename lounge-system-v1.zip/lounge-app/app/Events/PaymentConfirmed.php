<?php

namespace App\Events;

use App\Models\AdminNotification;
use App\Models\Payment;
use App\Support\Money;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Fired ONLY when a payment transitions to PAID via explicit confirmation path
 * (or cash settled as paid with staff-visible receipt). Never on mere method selection.
 */
class PaymentConfirmed implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Payment $payment,
        public ?AdminNotification $notification = null,
    ) {
        $this->payment->loadMissing(['order.table', 'order.items']);
    }

    public function broadcastOn(): array
    {
        return [new Channel('admin.payments')];
    }

    public function broadcastAs(): string
    {
        return 'payment.confirmed';
    }

    public function broadcastWith(): array
    {
        $order = $this->payment->order;
        $method = $this->payment->method->value;

        return [
            'type' => 'payment.confirmed',
            'payment_id' => $this->payment->id,
            'order_id' => $this->payment->order_id,
            'order_number' => $order?->order_number,
            'display_number' => $order ? '#'.$order->order_number : null,
            'table' => $order?->table?->number,
            'method' => $method,
            'method_label' => $this->payment->method->label(),
            'amount' => (int) $this->payment->amount,
            'amount_formatted' => Money::format((int) $this->payment->amount),
            'amount_received' => $this->payment->amount_received,
            'change_amount' => $this->payment->change_amount,
            'change_amount_formatted' => Money::format((int) ($this->payment->change_amount ?? 0)),
            'notification' => $this->notification?->toApiArray(),
            'paid_at' => $this->payment->paid_at?->toIso8601String(),
        ];
    }
}
