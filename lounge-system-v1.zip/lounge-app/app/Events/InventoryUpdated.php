<?php

namespace App\Events;

use App\Models\InventoryMovement;
use App\Models\Product;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class InventoryUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Product $product,
        public InventoryMovement $movement,
    ) {}

    public function broadcastOn(): array
    {
        return [new Channel('admin.inventory')];
    }

    public function broadcastAs(): string
    {
        return 'inventory.updated';
    }

    public function broadcastWith(): array
    {
        return [
            'product_id' => $this->product->id,
            'product_name' => $this->product->name,
            'current_stock' => $this->product->current_stock,
            'is_low_stock' => $this->product->isLowStock(),
            'movement' => [
                'id' => $this->movement->id,
                'type' => $this->movement->type->value,
                'quantity' => $this->movement->quantity,
                'previous_stock' => $this->movement->previous_stock,
                'new_stock' => $this->movement->new_stock,
            ],
        ];
    }
}
