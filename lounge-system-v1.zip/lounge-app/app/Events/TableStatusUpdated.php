<?php

namespace App\Events;

use App\Models\Table;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class TableStatusUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public Table $table) {}

    public function broadcastOn(): array
    {
        return [new Channel('admin.tables')];
    }

    public function broadcastAs(): string
    {
        return 'table.status_updated';
    }

    public function broadcastWith(): array
    {
        return [
            'table_id' => $this->table->id,
            'number' => $this->table->number,
            'status' => $this->table->status->value,
            'is_active' => $this->table->is_active,
        ];
    }
}
