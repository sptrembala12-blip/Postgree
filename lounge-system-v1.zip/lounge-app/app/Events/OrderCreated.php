<?php

namespace App\Events;

use App\Models\Order;
use App\Support\Money;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class OrderCreated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public Order $order)
    {
        $this->order->loadMissing(['items', 'payment', 'table']);
    }

    public function broadcastOn(): array
    {
        return [
            new Channel('admin.orders'),
        ];
    }

    public function broadcastAs(): string
    {
        return 'order.created';
    }

    public function broadcastWith(): array
    {
        $payment = $this->order->payment;

        $payload = [
            'order_id' => $this->order->id,
            'order_number' => $this->order->order_number,
            'display_number' => $this->order->displayNumber(),
            'table' => $this->order->table ? [
                'id' => $this->order->table->id,
                'number' => $this->order->table->number,
                'name' => $this->order->table->name,
            ] : null,
            'items' => $this->order->items->map(fn ($i) => [
                'name' => $i->product_name_snapshot,
                'quantity' => $i->quantity,
                'unit_price' => $i->unit_price,
                'subtotal' => $i->subtotal,
            ])->values()->all(),
            'total' => $this->order->total,
            'total_formatted' => Money::format((int) $this->order->total),
            'payment_method' => $payment?->method?->value,
            'payment_status' => $payment?->status?->value,
            'status' => $this->order->status->value,
            'created_at' => $this->order->created_at?->toIso8601String(),
        ];

        if ($payment && $payment->method?->value === 'CASH') {
            $payload['amount_received'] = $payment->amount_received;
            $payload['amount_received_formatted'] = Money::format((int) $payment->amount_received);
            $payload['change_amount'] = $payment->change_amount;
            $payload['change_amount_formatted'] = Money::format((int) $payment->change_amount);
        }

        return $payload;
    }
}
