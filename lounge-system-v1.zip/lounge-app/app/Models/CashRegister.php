<?php

namespace App\Models;

use App\Enums\CashRegisterStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CashRegister extends Model
{
    protected $fillable = [
        'opened_by',
        'opened_at',
        'opening_amount',
        'closed_by',
        'closed_at',
        'closing_amount',
        'expected_amount',
        'difference',
        'status',
        'summary',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'status' => CashRegisterStatus::class,
            'opened_at' => 'datetime',
            'closed_at' => 'datetime',
            'opening_amount' => 'integer',
            'closing_amount' => 'integer',
            'expected_amount' => 'integer',
            'difference' => 'integer',
            'summary' => 'array',
        ];
    }

    public function movements(): HasMany
    {
        return $this->hasMany(CashMovement::class);
    }

    public function openedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'opened_by');
    }

    public function closedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'closed_by');
    }

    public function isOpen(): bool
    {
        return $this->status === CashRegisterStatus::Open;
    }
}
