<?php

namespace App\Models;

use App\Support\Money;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AdminNotification extends Model
{
    protected $fillable = [
        'type',
        'title',
        'message',
        'dedupe_key',
        'user_id',
        'actor_id',
        'order_id',
        'payment_id',
        'payment_method',
        'amount',
        'amount_received',
        'change_amount',
        'table_number',
        'order_number',
        'data',
        'read_at',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'integer',
            'amount_received' => 'integer',
            'change_amount' => 'integer',
            'order_number' => 'integer',
            'data' => 'array',
            'read_at' => 'datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function payment(): BelongsTo
    {
        return $this->belongsTo(Payment::class);
    }

    public function actor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'actor_id');
    }

    public function isRead(): bool
    {
        return $this->read_at !== null;
    }

    public function markRead(): void
    {
        if (! $this->read_at) {
            $this->forceFill(['read_at' => now()])->save();
        }
    }

    public function amountFormatted(): ?string
    {
        return $this->amount !== null ? Money::format((int) $this->amount) : null;
    }

    public function toApiArray(): array
    {
        return [
            'id' => $this->id,
            'type' => $this->type,
            'title' => $this->title,
            'message' => $this->message,
            'payment_method' => $this->payment_method,
            'amount' => $this->amount,
            'amount_formatted' => $this->amountFormatted(),
            'amount_received' => $this->amount_received,
            'amount_received_formatted' => $this->amount_received !== null ? Money::format((int) $this->amount_received) : null,
            'change_amount' => $this->change_amount,
            'change_amount_formatted' => $this->change_amount !== null ? Money::format((int) $this->change_amount) : null,
            'order_id' => $this->order_id,
            'order_number' => $this->order_number,
            'display_number' => $this->order_number ? '#'.$this->order_number : null,
            'table_number' => $this->table_number,
            'payment_id' => $this->payment_id,
            'actor_id' => $this->actor_id,
            'data' => $this->data,
            'read_at' => $this->read_at?->toIso8601String(),
            'is_read' => $this->isRead(),
            'created_at' => $this->created_at?->toIso8601String(),
            'created_human' => $this->created_at?->diffForHumans(),
            'url' => $this->order_id ? url('/admin/orders/'.$this->order_id) : url('/admin/notifications'),
        ];
    }
}
