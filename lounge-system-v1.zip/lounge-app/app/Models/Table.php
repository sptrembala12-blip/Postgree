<?php

namespace App\Models;

use App\Enums\TableStatus;
use App\Enums\TableType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Str;

class Table extends Model
{
    use HasFactory;

    protected $table = 'tables';

    protected $fillable = [
        'number',
        'name',
        'type',
        'capacity',
        'location',
        'status',
        'qr_token',
        'qr_code_path',
        'is_active',
    ];

    protected function casts(): array
    {
        return [
            'type' => TableType::class,
            'status' => TableStatus::class,
            'capacity' => 'integer',
            'is_active' => 'boolean',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Table $table) {
            if (empty($table->qr_token)) {
                $table->qr_token = Str::random(40);
            }
        });
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(TableSession::class);
    }

    public function currentSession(): HasOne
    {
        return $this->hasOne(TableSession::class)
            ->where('status', 'OPEN')
            ->latestOfMany('opened_at');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function menuUrl(): string
    {
        return rtrim(config('app.url'), '/').'/menu/table/'.$this->number;
    }

    public function publicTokenUrl(): string
    {
        return rtrim(config('app.url'), '/').'/menu/t/'.$this->qr_token;
    }

    public function isAvailable(): bool
    {
        return $this->is_active && $this->status === TableStatus::Available;
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
