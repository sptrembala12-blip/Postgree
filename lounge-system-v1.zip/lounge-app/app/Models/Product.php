<?php

namespace App\Models;

use App\Support\Money;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'category_id',
        'name',
        'slug',
        'description',
        'price',
        'promotional_price',
        'stock_control_enabled',
        'current_stock',
        'minimum_stock',
        'maximum_stock',
        'is_active',
        'is_featured',
        'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'price' => 'integer',
            'promotional_price' => 'integer',
            'stock_control_enabled' => 'boolean',
            'current_stock' => 'integer',
            'minimum_stock' => 'integer',
            'maximum_stock' => 'integer',
            'is_active' => 'boolean',
            'is_featured' => 'boolean',
            'sort_order' => 'integer',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (Product $product) {
            if (empty($product->slug)) {
                $product->slug = static::uniqueSlug($product->name);
            }
        });
    }

    public static function uniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $i = 1;

        while (
            static::where('slug', $slug)
                ->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $slug = $base.'-'.$i++;
        }

        return $slug;
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function images(): HasMany
    {
        return $this->hasMany(ProductImage::class)->orderBy('sort_order');
    }

    public function primaryImage()
    {
        return $this->hasOne(ProductImage::class)->where('is_primary', true);
    }

    public function inventoryMovements(): HasMany
    {
        return $this->hasMany(InventoryMovement::class);
    }

    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Effective unit price in cents (promotional if set and lower).
     */
    public function effectivePrice(): int
    {
        if ($this->promotional_price !== null && $this->promotional_price < $this->price) {
            return (int) $this->promotional_price;
        }

        return (int) $this->price;
    }

    public function formattedPrice(): string
    {
        return Money::format($this->effectivePrice());
    }

    public function isLowStock(): bool
    {
        if (! $this->stock_control_enabled) {
            return false;
        }

        return $this->current_stock <= $this->minimum_stock;
    }

    public function isAvailableForSale(int $quantity = 1): bool
    {
        if (! $this->is_active) {
            return false;
        }

        if (! $this->stock_control_enabled) {
            return true;
        }

        if (config('lounge.allow_negative_stock', false)) {
            return true;
        }

        return $this->current_stock >= $quantity;
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeFeatured($query)
    {
        return $query->where('is_featured', true);
    }

    public function scopeLowStock($query)
    {
        return $query
            ->where('stock_control_enabled', true)
            ->whereColumn('current_stock', '<=', 'minimum_stock');
    }
}
