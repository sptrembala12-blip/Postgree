<?php

namespace App\Models;

use App\Enums\TableSessionStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TableSession extends Model
{
    protected $fillable = [
        'table_id',
        'opened_at',
        'closed_at',
        'status',
        'total_amount',
        'opened_by',
        'closed_by',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'status' => TableSessionStatus::class,
            'opened_at' => 'datetime',
            'closed_at' => 'datetime',
            'total_amount' => 'integer',
        ];
    }

    public function table(): BelongsTo
    {
        return $this->belongsTo(Table::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function openedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'opened_by');
    }

    public function closedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'closed_by');
    }

    public function isOpen(): bool
    {
        return $this->status === TableSessionStatus::Open;
    }

    public function recalculateTotal(): void
    {
        $total = $this->orders()
            ->whereNotIn('status', ['CANCELLED'])
            ->sum('total');

        $this->update(['total_amount' => (int) $total]);
    }
}
