<?php

namespace Database\Factories;

use App\Enums\TableStatus;
use App\Enums\TableType;
use App\Models\Table;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends Factory<Table>
 */
class TableFactory extends Factory
{
    protected $model = Table::class;

    public function definition(): array
    {
        $number = (string) fake()->unique()->numberBetween(1, 999);

        return [
            'number' => $number,
            'name' => 'Mesa '.$number,
            'type' => TableType::Table->value,
            'capacity' => 4,
            'location' => 'Salão',
            'status' => TableStatus::Available->value,
            'qr_token' => Str::random(40),
            'is_active' => true,
        ];
    }
}
