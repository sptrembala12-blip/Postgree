<?php

namespace Database\Factories;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends Factory<Product>
 */
class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition(): array
    {
        $name = fake()->unique()->words(3, true);

        return [
            'category_id' => Category::factory(),
            'name' => ucfirst($name),
            'slug' => Str::slug($name).'-'.Str::random(4),
            'description' => fake()->sentence(),
            'price' => fake()->numberBetween(500, 15000),
            'promotional_price' => null,
            'stock_control_enabled' => true,
            'current_stock' => fake()->numberBetween(10, 100),
            'minimum_stock' => 5,
            'maximum_stock' => 500,
            'is_active' => true,
            'is_featured' => false,
            'sort_order' => 0,
        ];
    }
}
