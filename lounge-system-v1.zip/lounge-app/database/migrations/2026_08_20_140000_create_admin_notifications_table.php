<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('admin_notifications', function (Blueprint $table) {
            $table->id();
            $table->string('type', 50)->index(); // payment_confirmed, order_created, stock_low, ...
            $table->string('title');
            $table->text('message');
            $table->string('dedupe_key')->unique(); // prevents duplicates
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete(); // target null = all admins with perm
            $table->foreignId('actor_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('order_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('payment_id')->nullable()->constrained()->nullOnDelete();
            $table->string('payment_method', 30)->nullable();
            $table->unsignedBigInteger('amount')->nullable();
            $table->unsignedBigInteger('amount_received')->nullable();
            $table->unsignedBigInteger('change_amount')->nullable();
            $table->string('table_number', 20)->nullable();
            $table->unsignedBigInteger('order_number')->nullable();
            $table->json('data')->nullable();
            $table->timestamp('read_at')->nullable()->index();
            $table->timestamps();

            $table->index(['type', 'created_at']);
            $table->index(['created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('admin_notifications');
    }
};
