<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Non-destructive indexes for report/order/payment performance.
 * Safe to run on production with RUN_MIGRATIONS=true.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->index(['status', 'created_at'], 'orders_status_created_idx');
            $table->index(['table_id', 'created_at'], 'orders_table_created_idx');
        });

        Schema::table('payments', function (Blueprint $table) {
            $table->index(['status', 'method', 'paid_at'], 'payments_status_method_paid_idx');
        });

        Schema::table('order_items', function (Blueprint $table) {
            $table->index(['product_id', 'created_at'], 'order_items_product_created_idx');
        });

        Schema::table('cash_registers', function (Blueprint $table) {
            $table->index(['status', 'opened_at'], 'cash_registers_status_opened_idx');
        });

        Schema::table('audit_logs', function (Blueprint $table) {
            $table->index(['action', 'created_at'], 'audit_logs_action_created_idx');
        });

        Schema::table('products', function (Blueprint $table) {
            $table->index(['is_active', 'category_id', 'sort_order'], 'products_active_category_sort_idx');
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropIndex('orders_status_created_idx');
            $table->dropIndex('orders_table_created_idx');
        });
        Schema::table('payments', function (Blueprint $table) {
            $table->dropIndex('payments_status_method_paid_idx');
        });
        Schema::table('order_items', function (Blueprint $table) {
            $table->dropIndex('order_items_product_created_idx');
        });
        Schema::table('cash_registers', function (Blueprint $table) {
            $table->dropIndex('cash_registers_status_opened_idx');
        });
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropIndex('audit_logs_action_created_idx');
        });
        Schema::table('products', function (Blueprint $table) {
            $table->dropIndex('products_active_category_sort_idx');
        });
    }
};
