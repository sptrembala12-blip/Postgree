<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->string('method', 20); // PIX, CREDIT_CARD, DEBIT_CARD, CASH
            $table->string('status', 30)->default('PENDING')->index();
            $table->unsignedBigInteger('amount'); // cents
            $table->unsignedBigInteger('amount_received')->nullable(); // cash
            $table->unsignedBigInteger('change_amount')->default(0); // cash change
            $table->string('transaction_reference')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->json('metadata')->nullable();
            $table->foreignId('recorded_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->index(['method', 'status']);
            $table->index('paid_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
