<?php

namespace Database\Seeders;

use App\Enums\TableStatus;
use App\Enums\TableType;
use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Table;
use App\Models\User;
use App\Services\Tables\TableService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    private function ensureProductImage(\App\Models\Product $product): void
    {
        if ($product->images()->exists()) {
            return;
        }
        $dir = storage_path('app/public/products/'.$product->id);
        if (! is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        $file = $dir.'/cover.png';
        $img = imagecreatetruecolor(600, 600);
        $bg = imagecolorallocate($img, 30 + ($product->id * 17) % 40, 28, 40);
        $fg = imagecolorallocate($img, 245, 165, 36);
        imagefilledrectangle($img, 0, 0, 600, 600, $bg);
        $text = mb_substr($product->name, 0, 18);
        imagestring($img, 5, 40, 280, $text, $fg);
        imagepng($img, $file);
        imagedestroy($img);
        \App\Models\ProductImage::create([
            'product_id' => $product->id,
            'path' => 'products/'.$product->id.'/cover.png',
            'original_name' => 'cover.png',
            'mime_type' => 'image/png',
            'size' => filesize($file),
            'is_primary' => true,
        ]);
    }
    public function run(): void
    {
        $this->call(RolesAndPermissionsSeeder::class);

        $admin = User::updateOrCreate(
            ['email' => 'admin@lounge.local'],
            [
                'name' => 'Administrador Demo',
                'password' => Hash::make('password'),
                'is_active' => true,
            ]
        );
        $admin->assignRole('admin');

        $attendant = User::updateOrCreate(
            ['email' => 'atendente@lounge.local'],
            [
                'name' => 'Atendente Demo',
                'password' => Hash::make('password'),
                'is_active' => true,
            ]
        );
        $attendant->assignRole('attendant');

        $categories = [
            ['name' => 'Bebidas', 'sort_order' => 1],
            ['name' => 'Cervejas', 'sort_order' => 2],
            ['name' => 'Whisky', 'sort_order' => 3],
            ['name' => 'Drinks', 'sort_order' => 4],
            ['name' => 'Narguilé', 'sort_order' => 5],
            ['name' => 'Essências', 'sort_order' => 6],
            ['name' => 'Cigarros', 'sort_order' => 7],
            ['name' => 'Snacks', 'sort_order' => 8],
        ];

        $categoryModels = [];
        foreach ($categories as $cat) {
            $categoryModels[$cat['name']] = Category::updateOrCreate(
                ['slug' => \Illuminate\Support\Str::slug($cat['name'])],
                [
                    'name' => $cat['name'],
                    'description' => 'Categoria demo: '.$cat['name'],
                    'sort_order' => $cat['sort_order'],
                    'is_active' => true,
                ]
            );
        }

        $products = [
            ['cat' => 'Cervejas', 'name' => 'Balde Heineken', 'price' => 5800, 'stock' => 20, 'min' => 5, 'featured' => true],
            ['cat' => 'Cervejas', 'name' => 'Cerveja Heineken Long Neck', 'price' => 1200, 'stock' => 100, 'min' => 20],
            ['cat' => 'Cervejas', 'name' => 'Cerveja Budweiser Long Neck', 'price' => 1100, 'stock' => 80, 'min' => 15],
            ['cat' => 'Whisky', 'name' => 'Whisky Red Label Dose', 'price' => 2500, 'stock' => 40, 'min' => 8],
            ['cat' => 'Whisky', 'name' => 'Whisky Black Label Dose', 'price' => 3500, 'stock' => 30, 'min' => 5],
            ['cat' => 'Drinks', 'name' => 'Drink Gin Tônica', 'price' => 2800, 'stock' => 50, 'min' => 10],
            ['cat' => 'Drinks', 'name' => 'Caipirinha', 'price' => 2200, 'stock' => 50, 'min' => 10],
            ['cat' => 'Narguilé', 'name' => 'Narguilé Completo', 'price' => 7500, 'stock' => 15, 'min' => 3, 'featured' => true],
            ['cat' => 'Essências', 'name' => 'Essência Love 66', 'price' => 1500, 'stock' => 60, 'min' => 10],
            ['cat' => 'Essências', 'name' => 'Essência Zomo Strong Mint', 'price' => 1400, 'stock' => 55, 'min' => 10],
            ['cat' => 'Cigarros', 'name' => 'Marlboro Box', 'price' => 1800, 'stock' => 40, 'min' => 8],
            ['cat' => 'Snacks', 'name' => 'Amendoim Torrado', 'price' => 1200, 'stock' => 35, 'min' => 5],
            ['cat' => 'Bebidas', 'name' => 'Água Mineral 500ml', 'price' => 600, 'stock' => 100, 'min' => 20],
            ['cat' => 'Bebidas', 'name' => 'Refrigerante Lata', 'price' => 800, 'stock' => 80, 'min' => 15],
            ['cat' => 'Cervejas', 'name' => 'Produto Estoque Baixo Demo', 'price' => 9900, 'stock' => 2, 'min' => 10],
        ];

        foreach ($products as $p) {
            $product = $productModel = Product::updateOrCreate(
                ['slug' => \Illuminate\Support\Str::slug($p['name'])],
                [
                    'category_id' => $categoryModels[$p['cat']]->id,
                    'name' => $p['name'],
                    'description' => 'Produto de demonstração: '.$p['name'],
                    'price' => $p['price'],
                    'promotional_price' => null,
                    'stock_control_enabled' => true,
                    'current_stock' => $p['stock'],
                    'minimum_stock' => $p['min'],
                    'maximum_stock' => $p['stock'] * 5,
                    'is_active' => true,
                    'is_featured' => $p['featured'] ?? false,
                    'sort_order' => 0,
                ]
            );
            $this->ensureProductImage($productModel);
        }

        /** @var TableService $tableService */
        $tableService = app(TableService::class);

        for ($i = 1; $i <= 10; $i++) {
            $number = str_pad((string) $i, 2, '0', STR_PAD_LEFT);
            $existing = Table::where('number', $number)->first();
            if ($existing) {
                continue;
            }

            $tableService->create([
                'number' => $number,
                'name' => 'Mesa '.$number,
                'type' => $i > 8 ? TableType::Lounge->value : TableType::Table->value,
                'capacity' => $i > 8 ? 8 : 4,
                'location' => $i > 8 ? 'Área Lounge' : 'Salão Principal',
                'status' => TableStatus::Available->value,
                'is_active' => true,
            ]);
        }

        Setting::setValue('store_name', 'Lounge Demo', 'string', 'general');
        Setting::setValue('allow_negative_stock', false, 'boolean', 'stock');
        Setting::setValue('currency_prefix', 'R$', 'string', 'general');
        Setting::setValue('order_auto_confirm', false, 'boolean', 'orders');

        $this->command?->info('Seed concluído.');
        $this->command?->info('Admin: admin@lounge.local / password');
        $this->command?->info('Atendente: atendente@lounge.local / password');
    }
}
