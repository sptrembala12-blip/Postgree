<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Seeder;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            // Dashboard
            ['name' => 'Ver dashboard', 'slug' => 'dashboard.view', 'group' => 'dashboard'],
            // Orders
            ['name' => 'Ver pedidos', 'slug' => 'orders.view', 'group' => 'orders'],
            ['name' => 'Gerenciar pedidos', 'slug' => 'orders.manage', 'group' => 'orders'],
            ['name' => 'Cancelar pedidos', 'slug' => 'orders.cancel', 'group' => 'orders'],
            // Tables
            ['name' => 'Ver mesas', 'slug' => 'tables.view', 'group' => 'tables'],
            ['name' => 'Gerenciar mesas', 'slug' => 'tables.manage', 'group' => 'tables'],
            // Catalog
            ['name' => 'Ver categorias', 'slug' => 'categories.view', 'group' => 'catalog'],
            ['name' => 'Gerenciar categorias', 'slug' => 'categories.manage', 'group' => 'catalog'],
            ['name' => 'Ver produtos', 'slug' => 'products.view', 'group' => 'catalog'],
            ['name' => 'Gerenciar produtos', 'slug' => 'products.manage', 'group' => 'catalog'],
            // Stock
            ['name' => 'Ver estoque', 'slug' => 'stock.view', 'group' => 'stock'],
            ['name' => 'Gerenciar estoque', 'slug' => 'stock.manage', 'group' => 'stock'],
            // Cash
            ['name' => 'Ver caixa', 'slug' => 'cash.view', 'group' => 'cash'],
            ['name' => 'Gerenciar caixa', 'slug' => 'cash.manage', 'group' => 'cash'],
            // Reports
            ['name' => 'Ver relatórios', 'slug' => 'reports.view', 'group' => 'reports'],
            // Users
            ['name' => 'Ver usuários', 'slug' => 'users.view', 'group' => 'users'],
            ['name' => 'Gerenciar usuários', 'slug' => 'users.manage', 'group' => 'users'],
            // Audit
            ['name' => 'Ver auditoria', 'slug' => 'audit.view', 'group' => 'audit'],
            // Settings
            ['name' => 'Gerenciar configurações', 'slug' => 'settings.manage', 'group' => 'settings'],
            // Payments
            ['name' => 'Confirmar pagamentos', 'slug' => 'payments.confirm', 'group' => 'payments'],
        ];

        foreach ($permissions as $perm) {
            Permission::updateOrCreate(['slug' => $perm['slug']], $perm);
        }

        $admin = Role::updateOrCreate(
            ['slug' => 'admin'],
            ['name' => 'Administrador', 'description' => 'Acesso total ao sistema']
        );
        $admin->syncPermissions(Permission::pluck('slug')->all());

        $attendant = Role::updateOrCreate(
            ['slug' => 'attendant'],
            ['name' => 'Atendente', 'description' => 'Operação de pedidos e mesas']
        );
        $attendant->syncPermissions([
            'dashboard.view',
            'orders.view',
            'orders.manage',
            'orders.cancel',
            'tables.view',
            'products.view',
            'categories.view',
            'stock.view',
            'cash.view',
            'payments.confirm',
        ]);

        // Future roles prepared
        $manager = Role::updateOrCreate(
            ['slug' => 'manager'],
            ['name' => 'Gerente', 'description' => 'Gestão operacional e relatórios']
        );
        $manager->syncPermissions([
            'dashboard.view',
            'orders.view',
            'orders.manage',
            'orders.cancel',
            'tables.view',
            'tables.manage',
            'categories.view',
            'categories.manage',
            'products.view',
            'products.manage',
            'stock.view',
            'stock.manage',
            'cash.view',
            'cash.manage',
            'reports.view',
            'payments.confirm',
            'audit.view',
        ]);

        $cashier = Role::updateOrCreate(
            ['slug' => 'cashier'],
            ['name' => 'Caixa', 'description' => 'Operação de caixa e pagamentos']
        );
        $cashier->syncPermissions([
            'dashboard.view',
            'orders.view',
            'orders.manage',
            'cash.view',
            'cash.manage',
            'payments.confirm',
            'tables.view',
        ]);

        $stock = Role::updateOrCreate(
            ['slug' => 'stock_manager'],
            ['name' => 'Estoquista', 'description' => 'Controle de estoque']
        );
        $stock->syncPermissions([
            'dashboard.view',
            'stock.view',
            'stock.manage',
            'products.view',
            'categories.view',
        ]);
    }
}
